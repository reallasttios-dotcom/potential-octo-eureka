"""
config.py — Central configuration for Meridian bot.
All values can be overridden via environment variables or by editing this file.
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ─── Bot credentials ──────────────────────────────────────────────────────────
DISCORD_TOKEN: str = os.getenv("DISCORD_TOKEN", "")

# ─── Server / guild settings ──────────────────────────────────────────────────
GUILD_ID: int = int(os.getenv("GUILD_ID", "0"))

# ─── Role IDs ─────────────────────────────────────────────────────────────────
STAFF_ROLE_ID: int     = int(os.getenv("STAFF_ROLE_ID", "0"))
VERIFIED_ROLE_ID: int  = int(os.getenv("VERIFIED_ROLE_ID", "0"))
UNVERIFIED_ROLE_ID: int = int(os.getenv("UNVERIFIED_ROLE_ID", "0"))

# ─── Ticket system ────────────────────────────────────────────────────────────
TICKET_DB_PATH: str = os.getenv("TICKET_DB_PATH", "tickets.sqlite")
TICKET_LOG_CHANNEL_ID: int = int(os.getenv("TICKET_LOG_CHANNEL_ID", "0"))
TICKET_CATEGORY_ID: int = int(os.getenv("TICKET_CATEGORY_ID", "0"))

# Ticket categories dict: {key: {"label": str, "parent_id": int}}
TICKET_CATEGORIES: dict = {
    "general":  {"label": "General Support", "parent_id": TICKET_CATEGORY_ID},
    "billing":  {"label": "Billing & Payments", "parent_id": TICKET_CATEGORY_ID},
    "report":   {"label": "Report a User", "parent_id": TICKET_CATEGORY_ID},
    "appeal":   {"label": "Ban Appeal", "parent_id": TICKET_CATEGORY_ID},
    "other":    {"label": "Other", "parent_id": TICKET_CATEGORY_ID},
}

# ─── Branding ─────────────────────────────────────────────────────────────────
TIOSIA_ICON: str = os.getenv(
    "TIOSIA_ICON",
    "https://cdn.discordapp.com/embed/avatars/0.png"
)
