import discord
from discord.ext import commands
import os
from datetime import datetime

class ServerConfig(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='prefix', aliases=['set-prefix'])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def prefix(self, ctx, new_prefix: str = None):
        """Set server prefix"""
        async with self.bot.db.execute("SELECT serverprefix FROM prefix WHERE guild = ?", (str(ctx.guild.id),)) as cursor:
            current = await cursor.fetchone()
            
        current_prefix = current['serverprefix'] if current else os.getenv('DISCORD_PREFIX', 'lv')
        
        if not new_prefix:
            embed = discord.Embed(color=0x4169E1, title="Server Prefix", description=f"Current prefix: `{current_prefix}`")
            embed.add_field(name="Change Prefix", value=f"`{current_prefix}prefix <new prefix>`")
            return await ctx.send(embed=embed)
        
        if new_prefix == current_prefix:
            return await ctx.send(embed=discord.Embed(color=0xFF0000, title="Error", description="Please provide a different prefix!"))
        
        await self.bot.db.execute("INSERT OR REPLACE INTO prefix (serverprefix, guild) VALUES (?, ?)", (new_prefix, str(ctx.guild.id)))
        await self.bot.db.commit()
        
        embed = discord.Embed(color=0x00FF00, title="Prefix Updated", description=f"Server prefix has been changed to `{new_prefix}`")
        await ctx.send(embed=embed)

    @commands.command(name='channel-levelup', aliases=['setchannel'])
    @commands.has_permissions(manage_guild=True)
    async def channel_levelup(self, ctx, channel: str = None):
        """Set specific channel to send level up message"""
        if not channel:
            embed = discord.Embed(color=0x4169E1, title="Level-Up Channel Setup")
            embed.add_field(name="Default Mode", value="`lvchannel-levelup default`", inline=False)
            embed.add_field(name="Specific Channel", value="`lvchannel-levelup #channel`", inline=False)
            return await ctx.send(embed=embed)
        
        if channel.lower() == "default":
            await self.bot.db.execute("INSERT OR REPLACE INTO channel (guild, channel) VALUES (?, ?)", (str(ctx.guild.id), "Default"))
            await self.bot.db.commit()
            return await ctx.send(embed=discord.Embed(color=0x00FF00, description="Level-up messages will now be sent in the channel where the user leveled up."))
        
        target_channel = ctx.message.channel_mentions[0] if ctx.message.channel_mentions else discord.utils.get(ctx.guild.channels, name=channel)
        
        if not target_channel:
            return await ctx.send(embed=discord.Embed(color=0xFF0000, description="Please provide a valid channel or use `default`."))
        
        await self.bot.db.execute("INSERT OR REPLACE INTO channel (guild, channel) VALUES (?, ?)", (str(ctx.guild.id), str(target_channel.id)))
        await self.bot.db.commit()
        
        await ctx.send(embed=discord.Embed(color=0x00FF00, description=f"Level-up messages will now be sent to {target_channel.mention}"))

    @commands.command(name='xpsettings', aliases=['xpconfig'])
    @commands.has_permissions(manage_guild=True)
    async def xpsettings(self, ctx, xp: int = None, cooldown: int = None):
        """Set custom XP and Cooldown"""
        async with self.bot.db.execute("SELECT * FROM settings WHERE guild = ?", (str(ctx.guild.id),)) as cursor:
            settings = await cursor.fetchone()
        
        if xp is None or cooldown is None:
            current_xp = settings['customXP'] if settings and settings['customXP'] else 15
            current_cooldown = (settings['customCooldown'] / 1000) if settings and settings['customCooldown'] else 5
            embed = discord.Embed(color=0x4169E1, title="XP Settings")
            embed.add_field(name="Current", value=f"Base XP: **{current_xp}**\nCooldown: **{current_cooldown}**s")
            embed.add_field(name="Usage", value="`lvxpsettings <xp> <seconds>`")
            return await ctx.send(embed=embed)
        
        if xp < 0 or cooldown < 0:
            return await ctx.send(embed=discord.Embed(color=0xFF0000, description="Values cannot be negative!"))
        
        if settings:
            await self.bot.db.execute("UPDATE settings SET customXP = ?, customCooldown = ? WHERE guild = ?", (xp, cooldown * 1000, str(ctx.guild.id)))
        else:
            await self.bot.db.execute("INSERT OR REPLACE INTO settings (guild, levelUpMessage, customXP, customCooldown) VALUES (?, ?, ?, ?)",
                                      (str(ctx.guild.id), "**Congratulations** {member}! You have now leveled up to **level {level}**", xp, cooldown * 1000))
        
        await self.bot.db.commit()
        await ctx.send(embed=discord.Embed(color=0x00FF00, description="XP configuration has been saved!"))

    @commands.command(name='toggle-xp')
    @commands.has_permissions(administrator=True)
    async def toggle_xp(self, ctx, action: str = None):
        """Turn on/off XP earning for the server"""
        async with self.bot.db.execute("SELECT * FROM xp_toggle WHERE guild = ?", (str(ctx.guild.id),)) as cursor:
            current = await cursor.fetchone()
        
        if not current:
            await self.bot.db.execute("INSERT INTO xp_toggle (guild, enabled) VALUES (?, 1)", (str(ctx.guild.id),))
            await self.bot.db.commit()
            current = {'enabled': 1}
        
        if not action:
            status = "**enabled**" if current['enabled'] == 1 else "**disabled**"
            return await ctx.send(embed=discord.Embed(color=0x4169E1, description=f"XP earning is currently {status}."))
        
        if action.lower() in ['on', 'enable', 'true']:
            await self.bot.db.execute("UPDATE xp_toggle SET enabled = 1 WHERE guild = ?", (str(ctx.guild.id),))
            await self.bot.db.commit()
            return await ctx.send(embed=discord.Embed(color=0x00FF00, description="XP earning **enabled**!"))
            
        if action.lower() in ['off', 'disable', 'false']:
            await self.bot.db.execute("UPDATE xp_toggle SET enabled = 0 WHERE guild = ?", (str(ctx.guild.id),))
            await self.bot.db.commit()
            return await ctx.send(embed=discord.Embed(color=0xFF0000, description="XP earning **disabled**!"))

    @commands.command(name='blacklist')
    @commands.has_permissions(manage_guild=True)
    async def blacklist(self, ctx, type_: str = None, target: discord.Member | discord.TextChannel = None, action: str = None):
        """Blacklist user/channel from leveling up/gaining XP"""
        if not type_ or type_.lower() not in ['user', 'channel', 'list']:
            embed = discord.Embed(color=0x4169E1, title="Blacklist Command")
            embed.add_field(name="Usage", value="`lvblacklist user @user add/remove`\n`lvblacklist channel #channel add/remove`\n`lvblacklist list`")
            return await ctx.send(embed=embed)

        if type_.lower() == "list":
            async with self.bot.db.execute("SELECT * FROM blacklistTable WHERE guild = ?", (str(ctx.guild.id),)) as cursor:
                lists = await cursor.fetchall()
            
            if not lists:
                return await ctx.send(embed=discord.Embed(color=0x4169E1, description="The blacklist is currently empty."))
                
            desc = "\n".join([f"{item['type'].capitalize()}: <{'@' if item['type'] == 'user' else '#'}{item['typeId']}>" for item in lists])
            return await ctx.send(embed=discord.Embed(color=0x4169E1, title="Server Blacklist", description=desc))

        if not target or not action:
            return await ctx.send("Please provide a target and an action (`add` or `remove`).")

        bl_id = f"{ctx.guild.id}-{target.id}"
        
        if action.lower() == 'add':
            await self.bot.db.execute("INSERT OR REPLACE INTO blacklistTable (guild, typeId, type, id) VALUES (?, ?, ?, ?)",
                                      (str(ctx.guild.id), str(target.id), type_.lower(), bl_id))
            await self.bot.db.commit()
            await ctx.send(embed=discord.Embed(color=0x00FF00, description=f"Added {target.mention} to the blacklist."))
            
        elif action.lower() == 'remove':
            await self.bot.db.execute("DELETE FROM blacklistTable WHERE id = ?", (bl_id,))
            await self.bot.db.commit()
            await ctx.send(embed=discord.Embed(color=0x00FF00, description=f"Removed {target.mention} from the blacklist."))

async def setup(bot):
    await bot.add_cog(ServerConfig(bot))
