# emojihandler.py (extended)
import discord
from discord.ext import commands
from typing import Dict, Optional, Union

class EmojiManager(commands.Cog):
    """Manage custom emojis for different cogs"""
    
    def __init__(self, bot):
        self.bot = bot
        self.cog_emojis: Dict[str, Dict[str, str]] = {}
        
        self.available_emojis = {
            "add_music": "<:147501_addmusic:1491128952599740607>",
            "lock": "<:149949_lock:1491128772873949225>",
            "add": "<:154740_add:1491128822287044769>",
            "video": "<:169037_video:1491143797311012925>",
            "unadd": "<:179551_unadd:1491128838456086528>",
            "vinyl": "<:194927_vinyl:1491143829779124414>",
            "left": "<:205680_left:1491143721134198784>",
            "right": "<:233240_right:1491143870170402906>",
            "warning": "<:26203_warning:1491128755408736500>",
            "google": "<:283161_google:1491128988456976395>",
            "mute": "<:295558_mute:1491129093935071354>",
            "announcement": "<:305931_announcement:1491128644872044755>",
            "family": "<:322358_family:1491128739113996290>",
            "delivered": "<:333066_delivered:1491128715952918689>",
            "heartbreak": "<:361447_heartbreak:1491128920853188699>",
            "dnd": "<:379746_dnd:1491128797099982908>",
            "search": "<:393279_search:1491129470655135774>",
            "user": "<:398542_user:1491128764040614178>",
            "share1": "<:399358_share1:1491143853720473811>",
            "endcall": "<:401189_endcall:1491128690229248093>",
            "heart": "<:420694_heart:1491129045008646224>",
            "block": "<:424155_block:1491128747640885380>",
            "repeat": "<:43702_repeat:1491128976964587704>",
            "pin": "<:452133_pin:1491129461968732371>",
            "briefcase": "<:455049_briefcase:1491128723813171241>",
            "groupchat": "<:456423_groupchat:1491129037031215247>",
            "images": "<:45665_images:1491129012909772880>",
            "shopping": "<:484462_shopping:1491128944802402334>",
            "ftend": "<:489700_ftend:1491129076772114433>",
            "unlock": "<:499269_unlock:1491129004336611348>",
            "music": "<:509499_music:1491143761705566469>",
            "money": "<:521155_money:1491143770236915763>",
            "tinder": "<:52992_tinder:1491128968189972551>",
            "friends": "<:531419_friends:1491129085181689906>",
            "nosignal": "<:539045_nosignal:1491129053091074088>",
            "package": "<:570855_package:1491128960396824686>",
            "love": "<:617167_love:1491143729078341815>",
            "amazon": "<:624805_amazon:1491128699372965898>",
            "typing": "<:631835_typing:1491143837547237386>",
            "comment": "<:646385_comment:1491128619970334872>",
            "nocomment": "<:670043_nocomment:1491128805379670066>",
            "unlike": "<:672990_unlike:1491128813814288494>",
            "verified": "<:675739_verified:1491129487910244372>",
            "noreceipt": "<:683418_noreceipt:1491143787714576453>",
            "mic": "<:684414_mic:1491143737303236678>",
            "facetime": "<:723080_facetime:1491143861697904761>",
            "skull": "<:726053_skull:1491128830536978522>",
            "battery": "<:7496_battery:1491128653327892733>",
            "mermaid": "<:753922_mermaid:1491143845549969539>",
            "read": "<:760941_read:1491129021059039362>",
            "add2": "<:766026_add2:1491128707421569074>",
            "instagram": "<:774695_instagram:1491128928914505778>",
            "call": "<:793899_call:1491128936782893220>",
            "share2": "<:80963_share2:1491128996400730122>",
            "receipt": "<:82162_receipt:1491129479395938447>",
            "location": "<:825068_location:1491129068882624583>",
            "headphones": "<:8253_headphones:1491143778784776304>",
            "doordash": "<:825995_doordash:1491128628061143050>",
            "linkedin": "<:828557_linkedin:1491128912783347832>",
            "celeb": "<:849956_celeb:1491128781073547275>",
            "image": "<:863611_image:1491129061131419883>",
            "unmute": "<:870201_unmute:1491143813840900166>",
            "repost": "<:885930_repost:1491129029024153701>",
            "bookmark": "<:899726_bookmark:1491128789055570103>",
            "spotify": "<:900856_spotify:1491143822028312626>",
            "unblock": "<:917256_unblock:1491143805465002005>",
            "calendar": "<:956263_calendar:1491128636324057310>",
            "witch": "<:992246_witch:1491143753413431316>",
            "tick_no": "<:TickNo:1485824787879166113>",
            "channel": "<:channel:1485825657144475648>",
            "green_dot": "<:light_green_dot:1485825734193709189>",
            "rotating_logo": "<a:r_OtherReligion:1485824695247835246>",
            "question_mark": "<a:Question_Mark_3D_Animation_POVRa:1480755453301624882>",
            "zero": "<:42632zero:1489989423201259520>",
            "one": "<:99034one:1489989554118201577>",
            "two": "<:32475two:1489989353525477498>",
            "three": "<:17611three:1489989174529491055>",
            "four": "<:30268four:1489989287461257338>",
            "five": "<:30268five:1489989261917950136>",
            "six": "<:30268six:1489989314023526450>",
            "seven": "<:71193seven:1489989480365686984>",
            "eight": "<:86575eight:1489989511743148072>",
            "nine": "<:86575nine:1489989380788457533>",
            "leftempty": "<:leftempty:1488121665736020008>",
            "barempty": "<:barempty:1488121641459253328>",
            "rightempty": "<:rightempty:1488121739073421342>",
            "leftfull": "<:leftfull:1488121696115228764>",
            "barfull": "<:barfull:1488121619875495966>",
            "rightfull": "<:rightfull:1488121715979583662>",
            "r_other_religion": "<a:r_OtherReligion:1485824695247835246>",
            "ping_4": "<a:ping_4:1480403789058937015>",
            "ping_3": "<a:ping_3:1480403817735520297>",
            "emoji_62": "<a:emoji_62:1480409279755325632>",
            "boost_transparent": "<a:boost_transparent:1489911529527705631>",
            "check": "<:check:1485825673158332567>",
        }
        
        self.ui_emojis = {       
            "success": self.available_emojis["check"],
            "error": self.available_emojis["tick_no"],
            "info": "<:420694_heart:1491129045008646224>",
            "reset": "<:179551_unadd:1491128838456086528>",
            "list": "<:45665_images:1491129012909772880>",
            "key": "<:149949_lock:1491128772873949225>",
            "cog": "<:398542_user:1491128764040614178>",
            "settings": "<:424155_block:1491128747640885380>",
        }
        
    def get_emoji(self, cog_name: str, emoji_key: str) -> str:
        """Get a specific emoji for a cog"""
        if cog_name in self.cog_emojis:
            return self.cog_emojis[cog_name].get(emoji_key, self.available_emojis.get(emoji_key, ""))
        return self.available_emojis.get(emoji_key, "")
    
    def get_ui_emoji(self, key: str) -> str:
        """Get UI emoji by key (for logging system)"""
        return self.ui_emojis.get(key, self.available_emojis.get(key, ""))
    
    def get_all_emojis(self, cog_name: str) -> Dict[str, str]:
        """Get all emojis for a cog"""
        if cog_name in self.cog_emojis:
            return {**self.available_emojis, **self.cog_emojis[cog_name]}
        return self.available_emojis.copy()

async def setup(bot):
    await bot.add_cog(EmojiManager(bot))