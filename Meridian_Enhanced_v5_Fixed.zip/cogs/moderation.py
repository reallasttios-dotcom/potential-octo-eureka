import discord
from discord.ext import commands
import re
import uuid
import asyncio
from datetime import timedelta, datetime
from typing import Union, Optional
from fuzzywuzzy import process

APPEAL_LINK = "https://discord.gg/tyEExt8WCk"


def parse_time(time_str: str):
    match = re.match(r"^(\d+)([smhd])$", time_str.lower())
    if not match:
        return None
    val, unit = int(match.group(1)), match.group(2)
    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    return timedelta(seconds=val * multipliers[unit])


def can_moderate(ctx, member: discord.Member) -> bool:
    if ctx.author == member:
        return False
    if member == ctx.guild.owner:
        return False
    if ctx.author != ctx.guild.owner and ctx.author.top_role <= member.top_role:
        return False
    if ctx.guild.me.top_role <= member.top_role:
        return False
    return True


class WarnSelect(discord.ui.Select):
    def __init__(self, target_user, warns_list, cog, ctx):
        self.target_user = target_user
        self.cog = cog
        self.ctx = ctx
        options = []
        for w in warns_list[:25]:
            short_reason = w["reason"][:50] + "..." if len(w["reason"]) > 50 else w["reason"]
            options.append(discord.SelectOption(label=f"ID: {w['id']}", description=short_reason, value=w['id'], emoji="🗑️"))
        super().__init__(placeholder="Select a warning to remove...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Only the command runner can use this.", ephemeral=True)
        warn_id = self.values[0]
        await self.cog.bot.db.execute(
            "DELETE FROM warns WHERE id = ? AND guild = ?", (warn_id, str(self.ctx.guild.id))
        )
        await self.cog.bot.db.commit()
        await interaction.response.send_message(
            embed=self.cog.check_embed(f"Removed warning `{warn_id}` from {self.target_user.mention}."), ephemeral=True
        )
        self.disabled = True
        await interaction.message.edit(view=self.view)


class WarnView(discord.ui.View):
    def __init__(self, target_user, warns_list, cog, ctx):
        super().__init__(timeout=120)
        self.add_item(WarnSelect(target_user, warns_list, cog, ctx))


class Moderation(commands.Cog):
    """Server moderation — warns, mutes, bans, notes, cases, and mod log."""

    def __init__(self, bot):
        self.bot = bot

    def check_embed(self, text, color=discord.Color.dark_theme()):
        return discord.Embed(description=f"✅ {text}", color=color)

    async def _send_card(self, ctx_or_target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = ctx_or_target if hasattr(ctx_or_target, 'send') else getattr(ctx_or_target, 'channel', ctx_or_target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        
        if hasattr(self.bot, 'imaging'):
            try:
                template_name = kwargs.pop("_template", "general")
                return await self.bot.imaging.render_and_send(
                    ctx_or_channel=reply_to or send_to,
                    template_name=template_name,
                    filename=f"{kwargs.get('card_type', kwargs.get('action', 'mod'))}.png",
                    reply=(reply_to is not None),
                    embed_title=fallback_embed.title if fallback_embed else f"Moderation: {kwargs.get('action', 'Action').title()}",
                    embed_description=fallback_embed.description if fallback_embed else None,
                    embed_color=fallback_embed.color.value if fallback_embed else 0x5865F2,
                    **kwargs
                )
            except Exception as exc:
                print(f"[Moderation imaging] {exc}")
        
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    async def log_action(self, guild_id: str, user_id: str, action_type: str,
                         reason: str, moderator_id: str, duration: str = None):
        action_id = str(uuid.uuid4())[:8]
        await self.bot.db.execute(
            """INSERT INTO mod_actions (id, guild, user_id, type, reason, duration, moderator_id, timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (action_id, guild_id, user_id, action_type, reason, duration,
             moderator_id, datetime.utcnow().isoformat()),
        )
        await self.bot.db.commit()
        return action_id

    # ─── Punishment Sub-Cog ──────────────────────────────────────────────

    @commands.group(name="punish", invoke_without_command=True)
    @commands.has_permissions(moderate_members=True)
    async def punish_group(self, ctx):
        """Commands for punishing members."""
        await ctx.send_help(ctx.command)

    @punish_group.command(name="mute", aliases=["timeout"])
    async def mute(self, ctx, member: discord.Member, time: str, *, reason: str = "No reason provided"):
        """Timeout a member. Example: !punish mute @user 10m Spamming"""
        if not can_moderate(ctx, member): return await ctx.send("Hierarchy check failed.")
        duration = parse_time(time)
        if not duration: return await ctx.send("Invalid time format (10m, 1h, 1d).")
        await member.timeout(duration, reason=reason)
        await self.log_action(str(ctx.guild.id), str(member.id), "timeout", reason, str(ctx.author.id), time)
        await self._send_card(ctx, self.check_embed(f"{member.mention} timed out for {time}."),
            _template="moderation", action="timeout", target=member, moderator=ctx.author, reason=reason, duration=time)

    @punish_group.command(name="ban")
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, user: Union[discord.Member, discord.User], *, reason: str = "No reason provided"):
        """Ban a user from the server."""
        if isinstance(user, discord.Member) and not can_moderate(ctx, user): return await ctx.send("Hierarchy check failed.")
        await ctx.guild.ban(user, reason=reason)
        await self.log_action(str(ctx.guild.id), str(user.id), "ban", reason, str(ctx.author.id))
        await self._send_card(ctx, self.check_embed(f"{user.mention} has been banned."),
            _template="moderation", action="ban", target=user, moderator=ctx.author, reason=reason)

    @punish_group.command(name="kick")
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Kick a member from the server."""
        if not can_moderate(ctx, member): return await ctx.send("Hierarchy check failed.")
        await member.kick(reason=reason)
        await self.log_action(str(ctx.guild.id), str(member.id), "kick", reason, str(ctx.author.id))
        await self._send_card(ctx, self.check_embed(f"{member.mention} has been kicked."),
            _template="moderation", action="kick", target=member, moderator=ctx.author, reason=reason)

    @punish_group.command(name="warn")
    async def warn(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Give a formal warning to a member."""
        if not can_moderate(ctx, member): return await ctx.send("Hierarchy check failed.")
        action_id = await self.log_action(str(ctx.guild.id), str(member.id), "warn", reason, str(ctx.author.id))
        await self.bot.db.execute(
            "INSERT INTO warns (id, guild, user_id, reason, moderator_id, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
            (action_id, str(ctx.guild.id), str(member.id), reason, str(ctx.author.id), datetime.utcnow().isoformat())
        )
        await self.bot.db.commit()
        await self._send_card(ctx, self.check_embed(f"Warned {member.mention}. Reason: {reason}"),
            _template="moderation", action="warn", target=member, moderator=ctx.author, reason=reason)

    # ─── Management Sub-Cog ──────────────────────────────────────────────

    @commands.group(name="manage", invoke_without_command=True)
    @commands.has_permissions(manage_messages=True)
    async def manage_group(self, ctx):
        """Commands for managing server content and roles."""
        await ctx.send_help(ctx.command)

    @manage_group.command(name="purge", aliases=["clear"])
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx, amount: int, user: Optional[discord.Member] = None, reason: Optional[str] = None, *, purge_keyword: Optional[str] = None):
        """
        Delete a specified number of messages with optional filters.
        Usage: !manage purge 10 @user (optional) reason (optional) purge_keyword (optional)
        """
        def check(m):
            if user and m.author != user:
                return False
            if purge_keyword and purge_keyword.lower() not in m.content.lower():
                return False
            return True

        # We delete the command message itself first
        try:
            await ctx.message.delete()
        except discord.HTTPException:
            pass

        deleted = await ctx.channel.purge(limit=amount, check=check)
        
        # Log the purge action to server logging
        logging_cog = self.bot.get_cog("LoggingCog")
        if logging_cog:
            message_logs = self.bot.get_cog("MessageLogsCog")
            if message_logs and hasattr(message_logs, 'log_purge_action'):
                await message_logs.log_purge_action(ctx.channel, ctx.author, len(deleted), user, reason)

        msg_text = f"✅ Purged {len(deleted)} messages"
        if user:
            msg_text += f" from {user.mention}"
        if purge_keyword:
            msg_text += f" containing `{purge_keyword}`"
        if reason:
            msg_text += f". Reason: {reason}"
        
        await ctx.send(msg_text, delete_after=5)

    @manage_group.command(name="slowmode")
    async def slowmode(self, ctx, seconds: int):
        """Set the slowmode for the current channel."""
        await ctx.channel.edit(slowmode_delay=seconds)
        await ctx.send(f"✅ Slowmode set to {seconds}s.")

    @manage_group.command(name="lock")
    @commands.has_permissions(manage_channels=True)
    async def lock(self, ctx, channel: discord.TextChannel = None):
        """Lock a channel so members cannot send messages."""
        channel = channel or ctx.channel
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ctx.send(f"🔒 {channel.mention} has been locked.")

    @manage_group.command(name="unlock")
    @commands.has_permissions(manage_channels=True)
    async def unlock(self, ctx, channel: discord.TextChannel = None):
        """Unlock a previously locked channel."""
        channel = channel or ctx.channel
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = None
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ctx.send(f"🔓 {channel.mention} has been unlocked.")

    @manage_group.command(name="role")
    @commands.has_permissions(manage_roles=True)
    async def role_cmd(self, ctx, member: discord.Member, *, role: discord.Role):
        """Toggle a role for a member."""
        if ctx.author.top_role <= role and ctx.author != ctx.guild.owner:
            return await ctx.send("You cannot manage roles higher than yours.")
        if role in member.roles:
            await member.remove_roles(role)
            await ctx.send(f"✅ Removed {role.name} from {member.mention}.")
        else:
            await member.add_roles(role)
            await ctx.send(f"✅ Added {role.name} to {member.mention}.")

    @commands.command(name="purge", aliases=["clear"])
    @commands.has_permissions(manage_messages=True)
    async def top_level_purge(self, ctx, amount: int, user: Optional[discord.Member] = None, reason: Optional[str] = None, *, purge_keyword: Optional[str] = None):
        """
        Delete a specified number of messages with optional filters.
        Usage: !purge 10 @user (optional) reason (optional) purge_keyword (optional)
        """
        await self.purge(ctx, amount, user, reason, purge_keyword=purge_keyword)

    # ─── Information Sub-Cog ──────────────────────────────────────────────

    @commands.group(name="modinfo", invoke_without_command=True)
    async def modinfo_group(self, ctx):
        """Commands for viewing moderation history."""
        await ctx.send_help(ctx.command)

    @modinfo_group.command(name="warns")
    async def warns(self, ctx, member: discord.Member = None):
        """View warnings for a member."""
        member = member or ctx.author
        async with self.bot.db.execute(
            "SELECT * FROM warns WHERE user_id = ? AND guild = ? ORDER BY timestamp DESC",
            (str(member.id), str(ctx.guild.id))
        ) as cursor:
            warns = await cursor.fetchall()
        if not warns: return await ctx.send(f"{member.mention} has no warnings.")
        embed = discord.Embed(title=f"Warnings for {member}", color=0xFFA500)
        for w in warns[:10]:
            embed.add_field(name=f"ID: {w['id']}", value=f"Reason: {w['reason']}\nBy: <@{w['moderator_id']}>", inline=False)
        await ctx.send(embed=embed, view=WarnView(member, warns, self, ctx) if ctx.author.guild_permissions.manage_messages else None)

    @modinfo_group.command(name="cases")
    async def cases(self, ctx, member: discord.Member):
        """View all moderation actions taken against a member."""
        async with self.bot.db.execute(
            "SELECT * FROM mod_actions WHERE user_id = ? AND guild = ? ORDER BY timestamp DESC LIMIT 10",
            (str(member.id), str(ctx.guild.id))
        ) as cursor:
            actions = await cursor.fetchall()
        if not actions: return await ctx.send(f"No cases found for {member.mention}.")
        embed = discord.Embed(title=f"Cases for {member}", color=0x5865F2)
        for a in actions:
            embed.add_field(name=f"{a['type'].upper()} (ID: {a['id']})", value=f"Reason: {a['reason']}\nMod: <@{a['moderator_id']}>", inline=False)
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Moderation(bot))
