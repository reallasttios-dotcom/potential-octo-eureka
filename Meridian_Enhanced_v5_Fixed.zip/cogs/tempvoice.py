import discord
from discord.ext import commands
import json

TRIGGER_CHANNELS = [
    1478285650020139111,
    1478285423888433152,
    1485643481475977387,
    1478270270837100633,
    1485642019241201854,
]


class TempVoice(commands.Cog):
    """Temporary voice channels with owner controls."""

    def __init__(self, bot):
        self.bot = bot
        self.counters: dict[int, int] = {}
        self._owners: dict[int, int] = {}

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[TempVoice imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    async def cog_load(self):
        """Restore owner map from DB."""
        async with self.bot.db.execute(
            "SELECT channel_id, owner_id FROM tempvoice_channels"
        ) as cursor:
            rows = await cursor.fetchall()
        for row in rows:
            self._owners[int(row["channel_id"])] = int(row["owner_id"])

    def _is_owner(self, channel: discord.VoiceChannel, member: discord.Member) -> bool:
        return self._owners.get(channel.id) == member.id

    def _is_temp(self, channel_id: int) -> bool:
        return channel_id in self._owners

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        # User joined a trigger channel → create temp VC
        if after.channel and after.channel.id in TRIGGER_CHANNELS:
            channel_id = after.channel.id
            if channel_id not in self.counters:
                self.counters[channel_id] = 1

            new_channel = await member.guild.create_voice_channel(
                name=f"{after.channel.name} {self.counters[channel_id]}",
                category=after.channel.category,
                bitrate=after.channel.bitrate,
                user_limit=after.channel.user_limit,
            )
            self.counters[channel_id] += 1
            self._owners[new_channel.id] = member.id

            await self.bot.db.execute(
                "INSERT OR REPLACE INTO tempvoice_channels (channel_id, owner_id, guild_id) VALUES (?, ?, ?)",
                (str(new_channel.id), str(member.id), str(member.guild.id)),
            )
            await self.bot.db.commit()
            await member.move_to(new_channel)

        # User left a temp channel → delete if empty
        if before.channel and self._is_temp(before.channel.id):
            if len(before.channel.members) == 0:
                try:
                    await before.channel.delete()
                except Exception:
                    pass
                self._owners.pop(before.channel.id, None)
                await self.bot.db.execute(
                    "DELETE FROM tempvoice_channels WHERE channel_id = ?",
                    (str(before.channel.id),),
                )
                await self.bot.db.commit()

    # ─── Owner control commands ────────────────────────────────────────────

    def _get_member_vc(self, member: discord.Member) -> discord.VoiceChannel | None:
        if member.voice and member.voice.channel and self._is_temp(member.voice.channel.id):
            return member.voice.channel
        return None

    @commands.command(name="vc")
    async def vc(self, ctx, action: str = None, *, value: str = None):
        """Temp voice channel owner controls.
        !vc rename <name> — rename your VC
        !vc limit <n>    — set user limit (0 = unlimited)
        !vc lock         — lock to current members only
        !vc unlock       — open to everyone
        !vc kick @user   — kick someone from your VC"""
        if not action:
            return await ctx.send(embed=discord.Embed(
                description="Usage: `!vc rename/limit/lock/unlock/kick`",
                color=0xED4245,
            ))

        channel = self._get_member_vc(ctx.author)
        if not channel:
            return await ctx.send(embed=discord.Embed(
                description="You must be in a temporary voice channel you own.",
                color=0xED4245,
            ))
        if not self._is_owner(channel, ctx.author):
            return await ctx.send(embed=discord.Embed(
                description="Only the channel owner can modify this channel.",
                color=0xED4245,
            ))

        action = action.lower()

        if action == "rename":
            if not value:
                return await ctx.send(embed=discord.Embed(description="Provide a new name.", color=0xED4245))
            await channel.edit(name=value[:100])
            await ctx.send(embed=discord.Embed(description=f"✅ Channel renamed to **{value}**.", color=0x57F287))

        elif action == "limit":
            try:
                limit = int(value) if value else 0
                if limit < 0 or limit > 99:
                    raise ValueError
            except ValueError:
                return await ctx.send(embed=discord.Embed(description="Limit must be 0–99 (0 = unlimited).", color=0xED4245))
            await channel.edit(user_limit=limit)
            msg = f"✅ User limit set to **{limit}**." if limit > 0 else "✅ User limit removed (unlimited)."
            await ctx.send(embed=discord.Embed(description=msg, color=0x57F287))

        elif action == "lock":
            overwrite = channel.overwrites_for(ctx.guild.default_role)
            overwrite.connect = False
            await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            await ctx.send(embed=discord.Embed(description="🔒 Channel locked — only current members can stay.", color=0x57F287))

        elif action == "unlock":
            overwrite = channel.overwrites_for(ctx.guild.default_role)
            overwrite.connect = None
            await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
            await ctx.send(embed=discord.Embed(description="🔓 Channel unlocked — anyone can join.", color=0x57F287))

        elif action == "kick":
            if not ctx.message.mentions:
                return await ctx.send(embed=discord.Embed(description="Mention the user to kick.", color=0xED4245))
            target = ctx.message.mentions[0]
            if target.voice and target.voice.channel == channel:
                try:
                    await target.move_to(None)
                    await ctx.send(embed=discord.Embed(description=f"✅ Kicked {target.mention} from the channel.", color=0x57F287))
                except discord.Forbidden:
                    await ctx.send(embed=discord.Embed(description="I don't have permission to move that user.", color=0xED4245))
            else:
                await ctx.send(embed=discord.Embed(description=f"{target.mention} is not in your channel.", color=0xED4245))

        else:
            await ctx.send(embed=discord.Embed(description="Unknown action. Use `rename`, `limit`, `lock`, `unlock`, or `kick`.", color=0xED4245))


async def setup(bot):
    await bot.add_cog(TempVoice(bot))
