import io
import aiohttp
import discord
from discord.ext import commands
from PIL import Image, ImageFilter, ImageEnhance, ImageDraw, ImageFont, ImageOps

# ----- Flag Configuration -----
COUNTRIES = {
    "canada": "ca", "usa": "us", "unitedstates": "us", "uk": "gb", "unitedkingdom": "gb",
    "australia": "au", "germany": "de", "france": "fr", "japan": "jp", "brazil": "br",
    "india": "in", "italy": "it", "spain": "es", "mexico": "mx", "netherlands": "nl",
    "sweden": "se", "norway": "no", "denmark": "dk", "finland": "fi", "southafrica": "za",
    "russia": "ru", "china": "cn", "southkorea": "kr", "argentina": "ar", "egypt": "eg",
    "turkey": "tr", "poland": "pl", "portugal": "pt", "greece": "gr", "ireland": "ie",
    "belgium": "be", "switzerland": "ch", "austria": "at", "hungary": "hu", "czechia": "cz",
    "romania": "ro", "ukraine": "ua", "israel": "il", "saudiarabia": "sa", "nigeria": "ng",
    "kenya": "ke", "indonesia": "id", "malaysia": "my", "singapore": "sg", "philippines": "ph",
    "vietnam": "vn", "thailand": "th", "newzealand": "nz", "iceland": "is"
}

ALIASES = {
    "ca": "canada", "us": "usa", "gb": "uk", "au": "australia",
    "de": "germany", "fr": "france", "jp": "japan", "br": "brazil", "in": "india",
    "it": "italy", "es": "spain", "mx": "mexico", "nl": "netherlands", "se": "sweden",
    "no": "norway", "dk": "denmark", "fi": "finland", "za": "southafrica", "ru": "russia",
    "cn": "china", "kr": "southkorea", "ar": "argentina", "eg": "egypt", "tr": "turkey",
    "pl": "poland", "pt": "portugal", "gr": "greece", "ie": "ireland", "be": "belgium",
    "ch": "switzerland", "at": "austria", "hu": "hungary", "cz": "czechia", "ro": "romania",
    "ua": "ukraine", "il": "israel", "sa": "saudiarabia", "ng": "nigeria", "ke": "kenya",
    "id": "indonesia", "my": "malaysia", "sg": "singapore", "ph": "philippines", "vn": "vietnam",
    "th": "thailand", "nz": "newzealand", "is": "iceland"
}

FLAG_URL = "https://flagcdn.com/w640/{code}.png"


class ImageManipulation(commands.Cog):
    """All image manipulation commands, including flag overlays – reply‑aware."""

    def __init__(self, bot):
        self.bot = bot
        self.flag_cache = {}
        # Try to load fonts
        try:
            self.font_path = "arial.ttf"
            self.impact_path = "impact.ttf"
            ImageFont.truetype(self.font_path, 20)
            ImageFont.truetype(self.impact_path, 20)
        except Exception:
            self.font_path = None
            self.impact_path = None

    # ------------------------------------------------------------------
    # Helper methods – reply aware
    # ------------------------------------------------------------------
    async def get_image(self, ctx):
        """Extract image from:
        1. Attached file in the command message
        2. If replying to a message, that message's first attachment
        3. Otherwise fail.
        """
        # Case 1: direct attachment
        if ctx.message.attachments:
            attachment = ctx.message.attachments[0]
            if not attachment.content_type.startswith("image/"):
                await ctx.send("That file is not an image.")
                return None
            img_data = await attachment.read()
            return Image.open(io.BytesIO(img_data))

        # Case 2: reply to a message with attachment
        if ctx.message.reference:
            referenced = ctx.message.reference.resolved
            if referenced and referenced.attachments:
                attachment = referenced.attachments[0]
                if not attachment.content_type.startswith("image/"):
                    await ctx.send("The replied message's file is not an image.")
                    return None
                img_data = await attachment.read()
                return Image.open(io.BytesIO(img_data))

        # No image found
        await ctx.send("Please attach an image or reply to a message that contains an image.")
        return None

    def to_bytes(self, image: Image.Image, format="PNG"):
        """Convert PIL image to bytes for Discord."""
        with io.BytesIO() as buf:
            if format.upper() == "JPEG" and image.mode in ("RGBA", "LA", "P"):
                bg = Image.new("RGB", image.size, (255, 255, 255))
                if image.mode == "P":
                    image = image.convert("RGBA")
                bg.paste(image, mask=image.split()[-1] if image.mode == "RGBA" else None)
                image = bg
            elif image.mode != "RGB" and format.upper() == "JPEG":
                image = image.convert("RGB")
            image.save(buf, format=format)
            buf.seek(0)
            return buf.getvalue()

    async def get_flag_image(self, code: str) -> Image.Image:
        """Download flag from cache or web."""
        if code in self.flag_cache:
            return self.flag_cache[code].copy()
        url = FLAG_URL.format(code=code)
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    raise Exception(f"Flag not found for {code}")
                data = await resp.read()
        flag = Image.open(io.BytesIO(data)).convert("RGBA")
        self.flag_cache[code] = flag.copy()
        return flag

    async def overlay_flag(self, user_img: Image.Image, flag: Image.Image, opacity: float = 0.5) -> io.BytesIO:
        """Overlay flag on user image with given opacity (0-1)."""
        flag_resized = flag.resize(user_img.size, Image.Resampling.LANCZOS)
        alpha = flag_resized.split()[3]
        new_alpha = alpha.point(lambda p: int(p * opacity))
        flag_resized.putalpha(new_alpha)
        if user_img.mode != "RGBA":
            user_img = user_img.convert("RGBA")
        result = Image.alpha_composite(user_img, flag_resized)
        output = io.BytesIO()
        result.save(output, format="PNG")
        output.seek(0)
        return output

    async def flag_command_logic(self, ctx, country_key: str, opacity: float = 0.5):
        """Core flag overlay logic."""
        img = await self.get_image(ctx)
        if img is None:
            return
        code = COUNTRIES.get(country_key)
        if not code:
            return await ctx.send(f"Unknown country: {country_key}")
        try:
            flag = await self.get_flag_image(code)
        except Exception as e:
            return await ctx.send(f"Error fetching flag: {e}")
        async with ctx.typing():
            result_bytes = await self.overlay_flag(img, flag, opacity)
            await ctx.send(file=discord.File(result_bytes, filename=f"flag_{country_key}.png"))

    # ------------------------------------------------------------------
    # Dynamic flag commands (created on load) – reply aware
    # ------------------------------------------------------------------
    async def setup_dynamic_commands(self):
        """Create !canada, !usa, !uk, etc. with optional opacity."""
        for name, code in COUNTRIES.items():
            async def command_callback(ctx, opacity: float = 0.5, *, name=name):
                await self.flag_command_logic(ctx, name, opacity)
            cmd = commands.Command(command_callback, name=name, help=f"Overlay the {name.title()} flag on an attached image (or reply to an image). Usage: `!{name} [opacity]`")
            self.bot.add_command(cmd)

        # Add aliases (skip if already a country command)
        for alias, target in ALIASES.items():
            if alias in COUNTRIES:
                continue
            async def alias_callback(ctx, opacity: float = 0.5, target=target):
                await self.flag_command_logic(ctx, target, opacity)
            alias_cmd = commands.Command(alias_callback, name=alias, help=f"Alias for `!{target}` flag overlay.")
            self.bot.add_command(alias_cmd)
        print(f"Loaded {len(COUNTRIES)} flag commands + {len(ALIASES) - sum(1 for a in ALIASES if a in COUNTRIES)} aliases.")

    # ------------------------------------------------------------------
    # General !flag command
    # ------------------------------------------------------------------
    @commands.command(name="flag")
    async def flag_general(self, ctx, country: str, opacity: float = 0.5):
        """Overlay a country flag. Example: `!flag canada 0.3` (reply to an image or attach one)"""
        country_lower = country.lower()
        if country_lower in COUNTRIES:
            key = country_lower
        elif country_lower in ALIASES:
            key = ALIASES[country_lower]
        else:
            return await ctx.send(f"Country '{country}' not found. Try `!flags`.")
        await self.flag_command_logic(ctx, key, opacity)

    @commands.command(name="flags")
    async def list_flags(self, ctx):
        """List all available flag commands."""
        flag_list = sorted(COUNTRIES.keys())
        chunks = [flag_list[i:i+20] for i in range(0, len(flag_list), 20)]
        for chunk in chunks:
            await ctx.send("`" + "`, `".join(chunk) + "`")

    # ------------------------------------------------------------------
    # Existing image manipulation commands – all reply aware
    # ------------------------------------------------------------------
    @commands.command(name="caption")
    async def caption(self, ctx, *, text: str):
        """Add a caption. Reply to an image or attach one. Usage: `!caption Hello`"""
        img = await self.get_image(ctx)
        if not img:
            return
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype(self.font_path or "arial.ttf", 40)
        except Exception:
            font = ImageFont.load_default()
        bbox = draw.textbbox((0, 0), text, font=font)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        x = (img.width - tw) // 2
        y = img.height - th - 20
        draw.text((x, y), text, fill="white", font=font)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(img)), "caption.png"))

    @commands.command(name="blur")
    async def blur(self, ctx, radius: int = 2):
        img = await self.get_image(ctx)
        if not img: return
        blurred = img.filter(ImageFilter.GaussianBlur(radius=radius))
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(blurred)), "blur.png"))

    @commands.command(name="resize")
    async def resize(self, ctx, width: int, height: int):
        img = await self.get_image(ctx)
        if not img: return
        resized = img.resize((width, height), Image.Resampling.LANCZOS)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(resized)), "resized.png"))

    @commands.command(name="rotate")
    async def rotate(self, ctx, degrees: float, expand: bool = False):
        img = await self.get_image(ctx)
        if not img: return
        rotated = img.rotate(degrees, expand=expand)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(rotated)), "rotated.png"))

    @commands.command(name="flip")
    async def flip(self, ctx, direction: str):
        img = await self.get_image(ctx)
        if not img: return
        if direction.lower() == "horizontal":
            flipped = img.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        elif direction.lower() == "vertical":
            flipped = img.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        else:
            return await ctx.send("Direction must be 'horizontal' or 'vertical'")
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(flipped)), "flipped.png"))

    @commands.command(name="grayscale")
    async def grayscale(self, ctx):
        img = await self.get_image(ctx)
        if not img: return
        gray = img.convert("L")
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(gray)), "grayscale.png"))

    @commands.command(name="invert")
    async def invert(self, ctx):
        img = await self.get_image(ctx)
        if not img: return
        inverted = ImageOps.invert(img.convert("RGB"))
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(inverted)), "inverted.png"))

    @commands.command(name="contrast")
    async def contrast(self, ctx, factor: float = 1.5):
        img = await self.get_image(ctx)
        if not img: return
        enhancer = ImageEnhance.Contrast(img)
        adjusted = enhancer.enhance(factor)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(adjusted)), "contrast.png"))

    @commands.command(name="brightness")
    async def brightness(self, ctx, factor: float = 1.5):
        img = await self.get_image(ctx)
        if not img: return
        enhancer = ImageEnhance.Brightness(img)
        adjusted = enhancer.enhance(factor)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(adjusted)), "brightness.png"))

    @commands.command(name="sharpen")
    async def sharpen(self, ctx):
        img = await self.get_image(ctx)
        if not img: return
        sharpened = img.filter(ImageFilter.SHARPEN)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(sharpened)), "sharpened.png"))

    @commands.command(name="edge")
    async def edge(self, ctx):
        img = await self.get_image(ctx)
        if not img: return
        edges = img.filter(ImageFilter.FIND_EDGES)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(edges)), "edge.png"))

    @commands.command(name="circle")
    async def circle(self, ctx):
        img = await self.get_image(ctx)
        if not img: return
        if img.mode != "RGBA":
            img = img.convert("RGBA")
        mask = Image.new("L", img.size, 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, img.width, img.height), fill=255)
        result = Image.new("RGBA", img.size, (0, 0, 0, 0))
        result.paste(img, mask=mask)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(result)), "circle.png"))

    @commands.command(name="sticker")
    async def sticker(self, ctx, border_size: int = 10):
        img = await self.get_image(ctx)
        if not img: return
        bordered = ImageOps.expand(img, border=border_size, fill="white")
        shadow = bordered.copy()
        shadow = ImageOps.expand(shadow, border=border_size, fill=(0, 0, 0, 100))
        shadow = shadow.filter(ImageFilter.GaussianBlur(radius=border_size // 2))
        result = Image.new("RGBA", shadow.size, (0, 0, 0, 0))
        result.paste(shadow, (border_size, border_size))
        result.paste(bordered, (0, 0), bordered if bordered.mode == "RGBA" else None)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(result)), "sticker.png"))

    @commands.command(name="makememe")
    async def makememe(self, ctx, top_text: str, bottom_text: str):
        img = await self.get_image(ctx)
        if not img: return
        draw = ImageDraw.Draw(img)
        try:
            font_size = int(img.height * 0.05)
            font = ImageFont.truetype(self.impact_path or "impact.ttf", font_size)
        except Exception:
            font = ImageFont.load_default()

        def outline(draw, text, font, x, y, fill, outline_color):
            for dx, dy in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
                draw.text((x + dx, y + dy), text, font=font, fill=outline_color)
            draw.text((x, y), text, font=font, fill=fill)

        bbox = draw.textbbox((0, 0), top_text, font=font)
        top_x = (img.width - (bbox[2] - bbox[0])) // 2
        outline(draw, top_text, font, top_x, 10, "white", "black")

        bbox = draw.textbbox((0, 0), bottom_text, font=font)
        bottom_x = (img.width - (bbox[2] - bbox[0])) // 2
        bottom_y = img.height - (bbox[3] - bbox[1]) - 10
        outline(draw, bottom_text, font, bottom_x, bottom_y, "white", "black")

        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(img)), "meme.png"))

    @commands.command(name="jpeg")
    async def jpeg(self, ctx, quality: int = 10):
        img = await self.get_image(ctx)
        if not img: return
        if img.mode in ("RGBA", "P"):
            rgb = Image.new("RGB", img.size, (255, 255, 255))
            rgb.paste(img, mask=img.split()[-1] if img.mode == "RGBA" else None)
            img = rgb
        with io.BytesIO() as buf:
            img.save(buf, format="JPEG", quality=quality)
            buf.seek(0)
            compressed = Image.open(buf)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(compressed, "JPEG")), "jpeg.jpg"))

    @commands.command(name="sepia")
    async def sepia(self, ctx):
        img = await self.get_image(ctx)
        if not img: return
        if img.mode != "RGB":
            img = img.convert("RGB")
        width, height = img.size
        pixels = img.load()
        for x in range(width):
            for y in range(height):
                r, g, b = pixels[x, y]
                tr = int(0.393 * r + 0.769 * g + 0.189 * b)
                tg = int(0.349 * r + 0.686 * g + 0.168 * b)
                tb = int(0.272 * r + 0.534 * g + 0.131 * b)
                pixels[x, y] = (min(tr, 255), min(tg, 255), min(tb, 255))
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(img)), "sepia.png"))

    @commands.command(name="pixelate")
    async def pixelate(self, ctx, block_size: int = 10):
        img = await self.get_image(ctx)
        if not img: return
        small = img.resize((img.width // block_size, img.height // block_size), Image.Resampling.NEAREST)
        pixelated = small.resize(img.size, Image.Resampling.NEAREST)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(pixelated)), "pixelated.png"))

    @commands.command(name="crop")
    async def crop(self, ctx, left: int, top: int, right: int, bottom: int):
        img = await self.get_image(ctx)
        if not img: return
        try:
            cropped = img.crop((left, top, right, bottom))
        except Exception as e:
            return await ctx.send(f"Crop failed: {e}")
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(cropped)), "cropped.png"))

    @commands.command(name="watermark")
    async def watermark(self, ctx, text: str, opacity: int = 128):
        img = await self.get_image(ctx)
        if not img: return
        overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        try:
            font = ImageFont.truetype(self.font_path or "arial.ttf", int(img.height * 0.05))
        except Exception:
            font = ImageFont.load_default()
        bbox = draw.textbbox((0, 0), text, font=font)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        x = img.width - tw - 20
        y = img.height - th - 20
        draw.text((x, y), text, fill=(255, 255, 255, opacity), font=font)
        if img.mode != "RGBA":
            img = img.convert("RGBA")
        watermarked = Image.alpha_composite(img, overlay)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(watermarked)), "watermarked.png"))

    @commands.command(name="border")
    async def border(self, ctx, width: int, color: str = "#000000"):
        img = await self.get_image(ctx)
        if not img: return
        bordered = ImageOps.expand(img, border=width, fill=color)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(bordered)), "bordered.png"))

    @commands.command(name="mirror")
    async def mirror(self, ctx):
        img = await self.get_image(ctx)
        if not img: return
        mirrored = img.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(mirrored)), "mirror.png"))

    @commands.command(name="sketch")
    async def sketch(self, ctx):
        img = await self.get_image(ctx)
        if not img: return
        gray = img.convert("L")
        inverted = ImageOps.invert(gray)
        blur = inverted.filter(ImageFilter.GaussianBlur(radius=3))
        sketch = Image.blend(gray, blur, alpha=0.5)
        await ctx.send(file=discord.File(io.BytesIO(self.to_bytes(sketch)), "sketch.png"))


async def setup(bot):
    cog = ImageManipulation(bot)
    await bot.add_cog(cog)
    await cog.setup_dynamic_commands()