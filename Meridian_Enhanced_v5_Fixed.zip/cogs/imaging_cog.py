"""
imaging_cog.py — Cog that initialises and manages the ImageRenderer,
making it available bot-wide as bot.imaging.
"""
from __future__ import annotations
import asyncio
import discord
from discord.ext import commands

from .imaging.renderer import ImageRenderer


class ImagingCog(commands.Cog, name="Imaging"):
    """Manages the imaging module lifecycle and exposes bot.imaging."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        emoji_manager = getattr(bot, "_emoji_manager_cog", None)
        self.renderer = ImageRenderer(bot, emoji_manager=emoji_manager)
        bot.imaging = self.renderer

    async def cog_load(self):
        self.renderer.start()

    async def cog_unload(self):
        await self.renderer.stop()
        if hasattr(self.bot, "imaging"):
            del self.bot.imaging

    @commands.command(name="imgtest", hidden=True)
    @commands.is_owner()
    async def img_test(self, ctx: commands.Context):
        """Quick smoke-test for the imaging module (owner only)."""
        async with ctx.typing():
            try:
                image_bytes = await self.bot.imaging.render(
                    "rank_card",
                    user=ctx.author,
                    level=1,
                    total_xp=100,
                    progress_xp=50,
                    needed_xp=100,
                    rank_pos=1,
                    theme="dark",
                )
                file = self.bot.imaging.make_file(image_bytes, "test_rank_card.png")
                await ctx.reply(content="✅ Imaging module is working!", file=file)
            except Exception as e:
                await ctx.reply(f"❌ Imaging error: {e}")

    @commands.command(name="imgstats", hidden=True)
    @commands.is_owner()
    async def img_stats(self, ctx: commands.Context):
        """Display imaging module statistics (owner only)."""
        renderer = self.bot.imaging
        queue_size = renderer._queue.qsize()
        cache_size = len(renderer._avatar_cache._cache)
        embed = discord.Embed(title="🖼️ Imaging Module Stats", color=0x5865F2)
        embed.add_field(name="Queue Size", value=str(queue_size), inline=True)
        embed.add_field(name="Avatar Cache", value=f"{cache_size} items", inline=True)
        embed.add_field(name="Concurrency Limit", value=str(renderer.MAX_CONCURRENT), inline=True)
        await ctx.reply(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(ImagingCog(bot))
