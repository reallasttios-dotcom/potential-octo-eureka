import discord
from discord.ext import commands
from deep_translator import GoogleTranslator
import asyncio

class Translate(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _send_card(self, target, fallback_embed, reply_to=None, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False)
                return await send_to.send(file=f)
            except Exception as exc:
                print(f"[Translate imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False)
        return await send_to.send(embed=fallback_embed)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        if self.bot.user.mentioned_in(message) and message.reference:
            origin_msg = await message.channel.fetch_message(message.reference.message_id)

            if not origin_msg.content:
                return

            try:
                translator = GoogleTranslator(source='auto', target='en')
                result = await asyncio.to_thread(translator.translate, origin_msg.content)

                if result.strip().lower() == origin_msg.content.strip().lower():
                    return await message.reply("Looks like this is already in English.")

                fallback = discord.Embed(
                    description=result,
                    color=0xFF8C00,
                )
                fallback.set_footer(text=f"Translated • Requested by {message.author.display_name}")

                await self._send_card(
                    message.channel, fallback,
                    reply_to=message,
                    card_type="translate",
                    original_text=origin_msg.content,
                    translated_text=result,
                    source_lang="auto",
                    target_lang="en",
                    requested_by=message.author.display_name,
                )
            except Exception as e:
                print(f"Translation Error: {e}")

async def setup(bot):
    await bot.add_cog(Translate(bot))
