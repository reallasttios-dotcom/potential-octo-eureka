import discord
from discord.ext import commands

class PrefixManager(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[PrefixManager imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    @commands.group(invoke_without_command=True)
    async def cprefix(self, ctx):
        """Show current server prefix."""
        async with self.bot.db.execute("SELECT serverprefix FROM prefix WHERE guild = ?", (str(ctx.guild.id),)) as cursor:
            row = await cursor.fetchone()
        current = row["serverprefix"] if row else "None (using default)"
        embed = discord.Embed(title="Current Server Prefix", description=f"`{current}`", color=0x2b2d31)
        await self._send_card(
            ctx, embed,
            card_type="info",
            title="Current Server Prefix",
            description=f"`{current}`",
        )

    @cprefix.command(name="set")
    @commands.has_permissions(administrator=True)
    async def set_prefix(self, ctx, new_prefix: str):
        if len(new_prefix) > 5:
            return await ctx.send("Prefix too long! Max 5 characters.")
        await self.bot.db.execute(
            "INSERT INTO prefix (guild, serverprefix) VALUES (?, ?) ON CONFLICT(guild) DO UPDATE SET serverprefix = ?",
            (str(ctx.guild.id), new_prefix, new_prefix)
        )
        await self.bot.db.commit()
        embed = discord.Embed(description=f"Prefix changed to `{new_prefix}`", color=0x57F287)
        await self._send_card(
            ctx, embed,
            card_type="info",
            title="Prefix Updated",
            description=f"Server prefix changed to `{new_prefix}`",
        )

    @cprefix.command(name="reset")
    @commands.has_permissions(administrator=True)
    async def reset_prefix(self, ctx):
        await self.bot.db.execute("DELETE FROM prefix WHERE guild = ?", (str(ctx.guild.id),))
        await self.bot.db.commit()
        embed = discord.Embed(description="Prefix reset to defaults: `!`, `?`, `m`", color=0x57F287)
        await self._send_card(
            ctx, embed,
            card_type="info",
            title="Prefix Reset",
            description="Prefix reset to defaults: `!`, `?`, `m`",
        )

async def setup(bot):
    await bot.add_cog(PrefixManager(bot))