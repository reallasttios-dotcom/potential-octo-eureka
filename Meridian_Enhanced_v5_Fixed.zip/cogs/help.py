import discord
from discord.ext import commands
from typing import Optional, Dict, List
from io import BytesIO

COG_EMOJIS_DEFAULTS = {
    "Moderation": "🛡️",
    "Utility": "🔧",
    "Fun": "🎮",
    "Leveling": "📊",
    "Admin": "⚙️",
    "AFK": "💤",
    "Anon": "🕵️",
    "Bump": "📣",
    "BumpReminder": "📣",
    "Channel": "📁",
    "ChannelTools": "📁",
    "Embed": "📝",
    "EmbedManager": "📝",
    "Help": "❓",
    "Snipe": "👻",
    "Starboard": "⭐",
    "TempVoice": "🎤",
    "ReactionRoles": "🎭",
    "ServerLogging": "📜",
    "Verification": "✅",
    "Tickets": "🎟️",
    "UtilitiesCog": "🎭",
    "ServerConfig": "🔩",
    "Translation": "🌐",
    "Translate": "🌐",
    "Boost": "💎",
    "BoostTracker": "💎",
    "InviteLogger": "📩",
    "RoleCounter": "🏷️",
    "AntiNuke": "🛡️",
    "AntiBot": "🤖",
    "Appeal": "📨",
    "Debate": "💬",
    "Emoji": "😀",
    "EmojiManager": "😀",
    "TikTok": "🎵",
    "Activity": "🎯",
    "Image": "🖼️",
    "ImageManipulation": "🖼️",
}


class HelpDropdown(discord.ui.Select):
    def __init__(self, bot: commands.Bot, cog_mapping: Dict[str, List], author: discord.User, cog, prefix: str):
        self.bot = bot
        self.parent_cog = cog
        self.cog_mapping = cog_mapping
        self.author = author
        self.prefix = prefix

        options = [
            discord.SelectOption(label="Home", description="Overview of all categories", emoji="🏠", value="home")
        ]
        for cog_name, cmds in sorted(cog_mapping.items()):
            if not cmds:
                continue
            display = self._display_name(cog_name)
            emoji = COG_EMOJIS_DEFAULTS.get(cog_name, COG_EMOJIS_DEFAULTS.get(display, "📂"))
            options.append(discord.SelectOption(
                label=display[:90],
                description=f"{len(cmds)} command{'s' if len(cmds) != 1 else ''}",
                emoji=emoji,
                value=cog_name,
            ))

        super().__init__(
            placeholder="Select a category…",
            min_values=1,
            max_values=1,
            options=options[:25],
        )

    @staticmethod
    def _display_name(cog_name: str) -> str:
        return cog_name.replace("Cog", "").replace("_", " ").strip()

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.author:
            return await interaction.response.send_message("This help menu isn't yours. Use `!help` to get your own.", ephemeral=True)
        selected = self.values[0]
        if selected == "home":
            embed = self._create_home_embed()
        else:
            embed = self._create_cog_embed(selected)
        await interaction.response.edit_message(embed=embed, view=self.view)

    def _create_home_embed(self) -> discord.Embed:
        total_cmds = sum(len(v) for v in self.cog_mapping.values())
        embed = discord.Embed(
            title="🤖 Meridian — Command Help",
            description=(
                f"Welcome to **Meridian**! Use the dropdown to browse **{len(self.cog_mapping)} categories** "
                f"and **{total_cmds} commands**.\n\n"
                f"**Prefix:** `{self.prefix}` | **Specific help:** `{self.prefix}help <command>`"
            ),
            color=discord.Color.orange(),
        )
        lines = []
        for cog_name, cmds in sorted(self.cog_mapping.items()):
            if not cmds:
                continue
            display = self._display_name(cog_name)
            emoji = COG_EMOJIS_DEFAULTS.get(cog_name, "📂")
            lines.append(f"{emoji} **{display}** — {len(cmds)} commands")
        embed.add_field(name="Categories", value="\n".join(lines[:25]) or "None", inline=False)
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.set_footer(text="<required>  [optional] — brackets not included in command")
        return embed

    def _create_cog_embed(self, cog_name: str) -> discord.Embed:
        cmds = self.cog_mapping.get(cog_name, [])
        display = self._display_name(cog_name)
        emoji = COG_EMOJIS_DEFAULTS.get(cog_name, "📂")
        embed = discord.Embed(title=f"{emoji} {display} Commands", color=discord.Color.orange())

        cog_obj = self.bot.get_cog(cog_name)
        if cog_obj and cog_obj.__doc__:
            embed.description = cog_obj.__doc__[:250]

        cmd_lines = []
        for cmd in sorted(cmds, key=lambda c: c.name):
            sig = f"`{self.prefix}{cmd.qualified_name}"
            if cmd.signature:
                sig += f" {cmd.signature}"
            sig += "`"
            desc = cmd.short_doc[:60] if cmd.short_doc else "No description"

            # Permission indicator
            perms = []
            for check in cmd.checks:
                qn = getattr(check, "__qualname__", "")
                if "has_permissions" in qn:
                    perms.append("🔒")
                elif "is_owner" in qn:
                    perms.append("👑")
            perm_str = " ".join(set(perms))

            cmd_lines.append(f"{perm_str} {sig} — {desc}")

        # Chunk into fields if too long
        chunk = ""
        for line in cmd_lines:
            if len(chunk) + len(line) + 1 > 1000:
                embed.add_field(name="Commands", value=chunk, inline=False)
                chunk = line + "\n"
            else:
                chunk += line + "\n"
        if chunk:
            embed.add_field(name="Commands" if not embed.fields else "Continued", value=chunk, inline=False)

        if not cmds:
            embed.description = "No commands available in this category."

        embed.set_footer(text="🔒 = requires permissions  👑 = bot owner only")
        return embed


class HelpView(discord.ui.View):
    def __init__(self, bot, cog_mapping, author, cog, prefix, timeout=300):
        super().__init__(timeout=timeout)
        self.message: discord.Message | None = None
        self.add_item(HelpDropdown(bot, cog_mapping, author, cog, prefix))

    async def on_timeout(self):
        for child in self.children:
            child.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except Exception:
                pass


class Help(commands.Cog):
    """Help and command browser."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[Help imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    @staticmethod
    def _display_name(cog_name: str) -> str:
        return cog_name.replace("Cog", "").replace("_", " ").strip()

    def get_command_categories(self) -> Dict[str, List]:
        """Build {cog_name: [top-level commands]} — no double-counting."""
        categories = {}
        for cog_name, cog in self.bot.cogs.items():
            if cog_name == "Help":
                continue
            # Use get_commands() for top-level only (avoids double-counting subcommands)
            cmds = [
                cmd for cmd in cog.get_commands()
                if not cmd.hidden and not any(
                    "is_owner" in getattr(c, "__qualname__", "") for c in cmd.checks
                )
            ]
            if cmds:
                categories[cog_name] = cmds
        return categories

    async def get_prefix_display(self, ctx) -> str:
        return ctx.prefix or "!"

    async def get_command_info(self, ctx, command_name: str, prefix: str) -> Optional[discord.Embed]:
        cmd = self.bot.get_command(command_name.lower())
        if not cmd:
            return None
        embed = discord.Embed(
            title=f"❓ `{prefix}{cmd.qualified_name}`",
            color=discord.Color.orange(),
        )
        embed.description = cmd.help or cmd.short_doc or "No description available."

        sig = f"`{prefix}{cmd.qualified_name}"
        if cmd.signature:
            sig += f" {cmd.signature}"
        sig += "`"
        embed.add_field(name="Usage", value=sig, inline=False)

        if cmd.aliases:
            embed.add_field(name="Aliases", value=", ".join(f"`{prefix}{a}`" for a in cmd.aliases), inline=False)

        # Cooldown
        if cmd._buckets and cmd._buckets._cooldown:
            cd = cmd._buckets._cooldown
            embed.add_field(name="Cooldown", value=f"{cd.rate} use{'s' if cd.rate > 1 else ''} / {cd.per:.0f}s", inline=True)

        # Permissions
        for check in cmd.checks:
            qn = getattr(check, "__qualname__", "")
            if "has_permissions" in qn:
                embed.add_field(name="Requires", value="Specific permissions", inline=True)
            elif "is_owner" in qn:
                embed.add_field(name="Requires", value="Bot owner", inline=True)

        if cmd.cog:
            embed.add_field(name="Category", value=self._display_name(cmd.cog.qualified_name), inline=True)

        if isinstance(cmd, commands.Group):
            subcmds = ", ".join(f"`{prefix}{cmd.name} {s.name}`" for s in cmd.commands)
            embed.add_field(name="Subcommands", value=subcmds, inline=False)

        embed.set_footer(text="<required>  [optional] — brackets not included in command")
        return embed

    @commands.command(name="help", aliases=["h", "command"])
    async def help_command(self, ctx, *, command_name: Optional[str] = None):
        """Interactive help browser. Use !help <command> for details, !help search <term> to search."""
        prefix = await self.get_prefix_display(ctx)

        if command_name:
            # Search mode
            if command_name.lower().startswith("search "):
                query = command_name[7:].lower()
                results = []
                for cmd in self.bot.walk_commands():
                    if cmd.hidden:
                        continue
                    if query in cmd.name.lower() or (cmd.short_doc and query in cmd.short_doc.lower()):
                        results.append(cmd)
                if not results:
                    return await ctx.send(embed=discord.Embed(
                        description=f"No commands found matching `{query}`.", color=0xED4245
                    ))
                embed = discord.Embed(
                    title=f"🔍 Search: `{query}`",
                    description="\n".join(
                        f"`{prefix}{cmd.qualified_name}` — {cmd.short_doc[:60] or 'No description'}"
                        for cmd in results[:20]
                    ),
                    color=discord.Color.orange(),
                )
                return await ctx.send(embed=embed)

            embed = await self.get_command_info(ctx, command_name, prefix)
            if embed:
                fields = [(f.name, f.value, f.inline) for f in embed.fields]
                return await self._send_card(
                    ctx, embed,
                    card_type="info",
                    title=embed.title or f"Help: {command_name}",
                    description=embed.description,
                    fields=fields,
                    footer=embed.footer.text if embed.footer else None,
                )
            else:
                return await ctx.send(embed=discord.Embed(
                    description=f"Command `{command_name}` not found. Try `{prefix}help` to browse all commands.",
                    color=discord.Color.red(),
                ))

        # Full help menu
        categories = self.get_command_categories()
        total_cmds = sum(len(v) for v in categories.values())

        embed = discord.Embed(
            title="🤖 Meridian — Command Help",
            description=(
                f"Browse **{len(categories)} categories** and **{total_cmds} commands** using the dropdown below.\n\n"
                f"**Prefix:** `{prefix}` | Tip: `{prefix}help <command>` for details | `{prefix}help search <term>` to search"
            ),
            color=discord.Color.orange(),
        )
        lines = []
        for cog_name, cmds in sorted(categories.items()):
            display = self._display_name(cog_name)
            emoji = COG_EMOJIS_DEFAULTS.get(cog_name, "📂")
            lines.append(f"{emoji} **{display}** — {len(cmds)} commands")
        embed.add_field(name="Categories", value="\n".join(lines[:25]) or "None", inline=False)
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.set_footer(text="🔒 = requires permissions  |  Select a category below")

        view = HelpView(self.bot, categories, ctx.author, self, prefix)
        message = await ctx.send(embed=embed, view=view)
        view.message = message

    @commands.command(name="commands")
    @commands.is_owner()
    async def list_all_commands(self, ctx):
        """Owner: list all commands across all cogs."""
        prefix = await self.get_prefix_display(ctx)
        all_cmds = [cmd for cmd in self.bot.walk_commands() if not cmd.parent]
        chunks = [all_cmds[i:i + 20] for i in range(0, len(all_cmds), 20)]
        for i, chunk in enumerate(chunks, 1):
            lines = [
                f"**`{prefix}{cmd.name}`** — {cmd.short_doc or 'No desc'}"
                + (" *(hidden)*" if cmd.hidden else "")
                for cmd in chunk
            ]
            embed = discord.Embed(
                title=f"All Commands (Page {i}/{len(chunks)})",
                description="\n".join(lines),
                color=discord.Color.blue(),
            )
            embed.set_footer(text=f"Total top-level commands: {len(all_cmds)}")
            await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Help(bot))
