import discord
from discord.ext import commands
import asyncio
import re


def ok(text, color=discord.Color.green()):
    return discord.Embed(description=text, color=color)


def err(text):
    return discord.Embed(description=text, color=discord.Color.red())


def parse_slowmode(value: str):
    """Parse a slowmode string like '10s', '2m', 'off' into seconds."""
    if value.lower() in ("off", "0", "none"):
        return 0
    match = re.match(r"^(\d+)([smh]?)$", value.lower())
    if not match:
        return None
    n, unit = int(match.group(1)), match.group(2) or "s"
    multipliers = {"s": 1, "m": 60, "h": 3600}
    result = n * multipliers[unit]
    return result if result <= 21600 else None  # Discord max is 6h


class ConfirmView(discord.ui.View):
    def __init__(self, ctx, timeout=60):
        super().__init__(timeout=timeout)
        self.ctx = ctx
        self.value = None

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.danger, emoji="⚠️")
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.value = True
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(
            embed=discord.Embed(description="Action confirmed. Working...", color=discord.Color.red()), view=self
        )
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.value = False
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(
            embed=discord.Embed(description="Action aborted.", color=discord.Color.green()), view=self
        )
        self.stop()

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.ctx.author:
            await interaction.response.send_message("This isn't your button.", ephemeral=True)
            return False
        return True


class ChannelTools(commands.Cog):
    """Channel management tools."""

    def __init__(self, bot):
        self.bot = bot
        self.stickies = {}

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[Channel imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    def check_embed(self, text, color=discord.Color.dark_theme()):
        return discord.Embed(description=f"✅ {text}", color=color)

    # ─── Original commands ────────────────────────────────────────────────

    @commands.command(name="nuke")
    @commands.has_permissions(manage_channels=True)
    async def nuke(self, ctx):
        """Clone the channel and delete the original, wiping its history."""
        view = ConfirmView(ctx)
        msg = await ctx.send(
            embed=self.check_embed(
                f"Woah there, {ctx.author.mention}. Are you SURE you want to nuke this channel?",
                discord.Color.orange(),
            ),
            view=view,
        )
        await view.wait()
        if not view.value:
            return
        channel = ctx.channel
        pos = channel.position
        new_channel = await channel.clone(reason=f"Nuked by {ctx.author}")
        await new_channel.edit(position=pos)
        await channel.delete()
        nuke_embed = self.check_embed("Channel successfully nuked and recreated.", discord.Color.green())
        await self._send_card(
            new_channel, nuke_embed,
            card_type="info",
            title="Channel Nuked",
            description="Channel successfully nuked and recreated.",
        )

    @commands.command(name="createchan", aliases=["newchan", "ccreate"])
    @commands.has_permissions(manage_channels=True)
    async def createchan(self, ctx, channel_type: str, *, name: str):
        """Create a text, voice, or category channel."""
        channel_type = channel_type.lower()
        try:
            if channel_type in ["text", "t"]:
                new_channel = await ctx.guild.create_text_channel(name, reason=f"Created by {ctx.author}")
            elif channel_type in ["voice", "v"]:
                new_channel = await ctx.guild.create_voice_channel(name, reason=f"Created by {ctx.author}")
            elif channel_type in ["category", "c"]:
                new_channel = await ctx.guild.create_category(name, reason=f"Created by {ctx.author}")
            else:
                return await ctx.send(embed=err("Invalid type. Use `text`, `voice`, or `category`."))
            display = new_channel.mention if channel_type not in ["category", "c"] else f"`{new_channel.name}`"
            await ctx.send(embed=self.check_embed(f"Successfully created {display}!", discord.Color.green()))
        except discord.Forbidden:
            await ctx.send(embed=err("I don't have permission to create channels."))

    @commands.command(name="delchan", aliases=["cdelete", "rmchan"])
    @commands.has_permissions(manage_channels=True)
    async def delchan(self, ctx, channel: discord.abc.GuildChannel = None):
        """Delete a channel (with confirmation)."""
        channel = channel or ctx.channel
        view = ConfirmView(ctx)
        msg = await ctx.send(
            embed=self.check_embed(f"Are you sure you want to delete {channel.mention}?", discord.Color.orange()),
            view=view,
        )
        await view.wait()
        if not view.value:
            return
        try:
            name = channel.name
            await channel.delete(reason=f"Deleted by {ctx.author}")
            if channel.id != ctx.channel.id:
                await ctx.send(embed=self.check_embed(f"Channel `{name}` deleted.", discord.Color.green()))
        except discord.Forbidden:
            await msg.edit(embed=err("I don't have permission to delete that channel."), view=None)

    @commands.command(name="stick")
    @commands.has_permissions(manage_messages=True)
    async def stick(self, ctx, *, text: str):
        """Pin a sticky message that re-posts itself on new messages."""
        msg = await ctx.send(text)
        self.stickies[ctx.channel.id] = {"text": text, "msg_id": msg.id}
        await ctx.message.delete()

    @commands.command(name="unstick")
    @commands.has_permissions(manage_messages=True)
    async def unstick(self, ctx):
        """Remove the sticky message from this channel."""
        if ctx.channel.id in self.stickies:
            del self.stickies[ctx.channel.id]
            await ctx.send("Sticky message removed.", delete_after=3)
            await ctx.message.delete()
        else:
            await ctx.send("No sticky message active here.", delete_after=3)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return
        channel_id = message.channel.id
        if channel_id in self.stickies:
            sticky_data = self.stickies[channel_id]
            try:
                old_msg = await message.channel.fetch_message(sticky_data["msg_id"])
                await old_msg.delete()
            except discord.NotFound:
                pass
            await asyncio.sleep(0.5)
            new_msg = await message.channel.send(sticky_data["text"])
            self.stickies[channel_id]["msg_id"] = new_msg.id

    # ─── New Commands ─────────────────────────────────────────────────────

    @commands.command(name="lock")
    @commands.has_permissions(manage_channels=True)
    async def lock(self, ctx, channel: discord.TextChannel = None):
        """Lock a channel so @everyone cannot send messages."""
        channel = channel or ctx.channel
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite, reason=f"Locked by {ctx.author}")
        lock_embed = self.check_embed(f"🔒 {channel.mention} is now **locked**.")
        await self._send_card(
            ctx, lock_embed,
            card_type="info",
            title="Channel Locked",
            description=f"🔒 {channel.name} is now locked.",
        )

    @commands.command(name="unlock")
    @commands.has_permissions(manage_channels=True)
    async def unlock(self, ctx, channel: discord.TextChannel = None):
        """Unlock a channel, restoring @everyone send permissions."""
        channel = channel or ctx.channel
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = None
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite, reason=f"Unlocked by {ctx.author}")
        unlock_embed = self.check_embed(f"🔓 {channel.mention} is now **unlocked**.")
        await self._send_card(
            ctx, unlock_embed,
            card_type="info",
            title="Channel Unlocked",
            description=f"🔓 {channel.name} is now unlocked.",
        )

    @commands.command(name="slowmode")
    @commands.has_permissions(manage_channels=True)
    async def slowmode(self, ctx, value: str = None):
        """Set slowmode on this channel (e.g. !slowmode 10s, !slowmode 2m, !slowmode off)."""
        if not value:
            current = ctx.channel.slowmode_delay
            if current == 0:
                return await ctx.send(embed=self.check_embed("Slowmode is currently **off**."))
            return await ctx.send(embed=self.check_embed(f"Slowmode is set to **{current}s**."))
        seconds = parse_slowmode(value)
        if seconds is None:
            return await ctx.send(embed=err("Invalid value. Use e.g. `10s`, `2m`, `1h`, or `off`. Max is `6h`."))
        await ctx.channel.edit(slowmode_delay=seconds)
        if seconds == 0:
            await ctx.send(embed=self.check_embed("🐇 Slowmode **disabled**."))
        else:
            await ctx.send(embed=self.check_embed(f"🐢 Slowmode set to **{value}**."))

    @commands.command(name="hide")
    @commands.has_permissions(manage_channels=True)
    async def hide(self, ctx, channel: discord.TextChannel = None):
        """Hide a channel from @everyone."""
        channel = channel or ctx.channel
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.view_channel = False
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite, reason=f"Hidden by {ctx.author}")
        await ctx.send(embed=self.check_embed(f"👁️ {channel.mention} is now **hidden** from @everyone."))

    @commands.command(name="show")
    @commands.has_permissions(manage_channels=True)
    async def show(self, ctx, channel: discord.TextChannel = None):
        """Make a channel visible to @everyone again."""
        channel = channel or ctx.channel
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.view_channel = None
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite, reason=f"Shown by {ctx.author}")
        await ctx.send(embed=self.check_embed(f"👁️ {channel.mention} is now **visible** to @everyone."))

    @commands.command(name="topic")
    @commands.has_permissions(manage_channels=True)
    async def topic(self, ctx, *, text: str = None):
        """Set or clear the channel topic."""
        await ctx.channel.edit(topic=text)
        if text:
            await ctx.send(embed=self.check_embed(f"Topic set to: *{text}*"))
        else:
            await ctx.send(embed=self.check_embed("Channel topic cleared."))

    @commands.command(name="clone")
    @commands.has_permissions(manage_channels=True)
    async def clone_channel(self, ctx, channel: discord.abc.GuildChannel = None):
        """Clone a channel (keeps permissions, topic, etc.)."""
        channel = channel or ctx.channel
        try:
            new_channel = await channel.clone(reason=f"Cloned by {ctx.author}")
            await new_channel.edit(name=f"{channel.name}-copy", position=channel.position + 1)
            mention = new_channel.mention if hasattr(new_channel, "mention") else f"`{new_channel.name}`"
            await ctx.send(embed=self.check_embed(f"Cloned to {mention}."))
        except discord.Forbidden:
            await ctx.send(embed=err("I don't have permission to clone that channel."))


async def setup(bot):
    await bot.add_cog(ChannelTools(bot))
