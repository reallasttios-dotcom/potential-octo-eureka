import discord
from discord.ext import commands
import time
from collections import defaultdict
import config
import datetime

class VerifyView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(label="Verify", style=discord.ButtonStyle.success, custom_id="verify_button", emoji="🛡️")
    async def verify(self, interaction: discord.Interaction, button: discord.ui.Button):
        member = interaction.user
        if not isinstance(member, discord.Member):
            return await interaction.response.send_message("Server-only command.", ephemeral=True)

        if member.id not in self.cog.user_data:
            unverified_role = member.guild.get_role(config.UNVERIFIED_ROLE_ID)
            if unverified_role and unverified_role in member.roles:
                self.cog.user_data[member.id] = {
                    "joined_at": member.joined_at.timestamp(),
                    "score": 0,
                    "reasons": [],
                    "locked": False,
                    "verify_prompt_at": time.time(),
                    "attempted": False
                }
            else:
                return await interaction.response.send_message("You are already verified or don't need to verify!", ephemeral=True)

        data = self.cog.user_data[member.id]
        if data.get("attempted"):
            return await interaction.response.send_message("Verification already attempted. Please wait for staff review.", ephemeral=True)

        data["attempted"] = True
        data["verify_prompt_at"] = time.time()

        await interaction.response.defer(ephemeral=True)
        await self.cog.handle_verify_attempt(member, interaction)

class Verification(commands.Cog):
    """Advanced verification system with anti-raid and logging."""
    def __init__(self, bot):
        self.bot = bot
        self.user_data = defaultdict(dict)
        self.join_batches = defaultdict(list)
        self.raid_mode = False

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        if hasattr(self.bot, 'imaging'):
            try:
                template = kwargs.pop("_template", "general")
                return await self.bot.imaging.render_and_send(
                    ctx_or_channel=reply_to or send_to,
                    template_name=template,
                    filename=f"{kwargs.get('card_type', template)}.png",
                    reply=(reply_to is not None),
                    embed_title=fallback_embed.title if fallback_embed else f"Verification: {template.replace('_', ' ').title()}",
                    embed_description=fallback_embed.description if fallback_embed else None,
                    embed_color=fallback_embed.color.value if fallback_embed else 0x5865F2,
                    **kwargs
                )
            except Exception as exc:
                print(f"[Verification imaging] {exc}")
        if reply_to: return await reply_to.reply(embed=fallback_embed)
        return await send_to.send(embed=fallback_embed)

    async def cog_load(self):
        self.bot.add_view(VerifyView(self))

    async def handle_verify_attempt(self, member, interaction=None):
        unverified = member.guild.get_role(config.UNVERIFIED_ROLE_ID)
        verified = member.guild.get_role(config.VERIFIED_ROLE_ID)
        try:
            if unverified and unverified in member.roles:
                await member.remove_roles(unverified, reason="Passed verification")
            if verified:
                await member.add_roles(verified, reason="Passed verification")
                if interaction:
                    await interaction.followup.send("✅ Verification successful! Welcome to the server.", ephemeral=True)
        except discord.Forbidden:
            if interaction:
                await interaction.followup.send("❌ Error: I don't have permission to manage your roles.", ephemeral=True)

        self.user_data.pop(member.id, None)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.guild.id != config.GUILD_ID: return
        
        # Anti-Raid check
        if self.raid_mode:
            try:
                await member.send("The server is currently in Raid Mode. Please try joining later.")
                await member.kick(reason="Raid Mode active")
                return
            except: pass

        unverified = member.guild.get_role(config.UNVERIFIED_ROLE_ID)
        if unverified:
            try: await member.add_roles(unverified, reason="Auto-assign unverified role")
            except: pass

        self.user_data[member.id] = {
            "joined_at": time.time(), "score": 0, "reasons": [],
            "locked": False, "verify_prompt_at": None, "attempted": False
        }

    # ─── Verification Sub-Cog ──────────────────────────────────────────────

    @commands.group(name="verify", invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    async def verify_group(self, ctx):
        """Verification system management."""
        await ctx.send_help(ctx.command)

    @verify_group.command(name="setup")
    async def setup_verify(self, ctx):
        """Post the verification panel."""
        embed = discord.Embed(title="🛡️ Server Verification", description="Click the button below to verify your account and gain access to the server.", color=0x5865F2)
        if hasattr(self.bot, 'imaging'):
            await self.bot.imaging.render_and_send(
                ctx_or_channel=ctx.channel,
                template_name="verification",
                filename="verify_panel.png",
                embed_title="Server Verification",
                embed_description="Click the button below to verify your account.",
                view=VerifyView(self),
                user=ctx.author, status="pending",
                steps=["Click verify button", "Wait for system check"],
                completed_steps=0, notes="Welcome to the server!"
            )
        else:
            await ctx.send(embed=embed, view=VerifyView(self))

    @verify_group.command(name="approve")
    @commands.has_role(config.STAFF_ROLE_ID)
    async def approve_user(self, ctx, member: discord.Member):
        """Manually approve a user's verification."""
        unverified = ctx.guild.get_role(config.UNVERIFIED_ROLE_ID)
        verified = ctx.guild.get_role(config.VERIFIED_ROLE_ID)
        if unverified: await member.remove_roles(unverified)
        if verified: await member.add_roles(verified)
        self.user_data.pop(member.id, None)
        
        embed = discord.Embed(title="Verification Approved", description=f"✅ {member.mention} has been manually verified.", color=0x57F287)
        await self._send_card(ctx, embed, _template="verification", user=member, status="approved", steps=["Staff review", "Manual approval"], completed_steps=2, notes=f"Approved by {ctx.author}")

    @verify_group.command(name="deny")
    @commands.has_role(config.STAFF_ROLE_ID)
    async def deny_user(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        """Deny a user's verification and kick them."""
        await member.kick(reason=f"Verification denied: {reason}")
        self.user_data.pop(member.id, None)
        await ctx.send(f"❌ {member.mention}'s verification was denied.")

    @verify_group.command(name="raidmode")
    @commands.has_permissions(administrator=True)
    async def toggle_raidmode(self, ctx):
        """Toggle raid mode (auto-kick new joins)."""
        self.raid_mode = not self.raid_mode
        status = "ENABLED" if self.raid_mode else "DISABLED"
        color = discord.Color.red() if self.raid_mode else discord.Color.green()
        embed = discord.Embed(title="🚨 Raid Mode", description=f"Raid mode has been **{status}**.", color=color)
        await ctx.send(embed=embed)

    @verify_group.command(name="stats")
    async def verify_stats(self, ctx):
        """Show verification statistics."""
        pending = len(self.user_data)
        embed = discord.Embed(title="📊 Verification Stats", color=0x5865F2)
        embed.add_field(name="Pending Users", value=str(pending))
        embed.add_field(name="Raid Mode", value="Active" if self.raid_mode else "Inactive")
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Verification(bot))
