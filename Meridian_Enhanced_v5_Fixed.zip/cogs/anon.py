import discord
from discord.ext import commands, tasks
from discord import app_commands
import json
import os
import time

ANON_CONFIG = {
    "target_channel_id": 1489880335582761000
}
CAPSULE_CONFIG = {
    "target_channel_id": 1478270270090379347,
    "file_path": "time_capsules.json",
    "check_loop_seconds": 60,
}
ANON_RATE_LIMIT = 600  # 10 minutes


def load_capsules():
    if not os.path.exists(CAPSULE_CONFIG["file_path"]):
        return []
    with open(CAPSULE_CONFIG["file_path"], "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []


def save_capsules(data):
    with open(CAPSULE_CONFIG["file_path"], "w") as f:
        json.dump(data, f, indent=4)


class SecretInputModal(discord.ui.Modal, title="Send a Secret Message"):
    message_input = discord.ui.TextInput(
        label="Your Message",
        style=discord.TextStyle.paragraph,
        placeholder="Type your message here...",
        required=True,
        max_length=1000,
    )

    def __init__(self, cog):
        super().__init__()
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        guild_id = str(interaction.guild.id)
        user_id = str(interaction.user.id)

        # Check if banned from anon
        async with self.cog.bot.db.execute(
            "SELECT 1 FROM anon_bans WHERE guild = ? AND user_id = ?", (guild_id, user_id)
        ) as cursor:
            if await cursor.fetchone():
                return await interaction.response.send_message(
                    "You are unable to use the anonymous system.", ephemeral=True
                )

        # Rate limit check
        now = time.time()
        async with self.cog.bot.db.execute(
            "SELECT last_post FROM anon_cooldowns WHERE guild = ? AND user_id = ?", (guild_id, user_id)
        ) as cursor:
            row = await cursor.fetchone()
        if row and now - row["last_post"] < ANON_RATE_LIMIT:
            remaining = round(ANON_RATE_LIMIT - (now - row["last_post"]))
            return await interaction.response.send_message(
                f"You can post again in **{remaining}s**.", ephemeral=True
            )

        target_channel = interaction.guild.get_channel(ANON_CONFIG["target_channel_id"])
        if not target_channel:
            return await interaction.response.send_message(
                "The anonymous channel isn't configured correctly.", ephemeral=True
            )

        content = self.message_input.value
        sent_msg = await target_channel.send(f"**Anonymous Delivery:**\n{content}")

        # Log the sender privately
        await self.cog.bot.db.execute(
            "INSERT INTO anon_log (guild, message_id, user_id, content, timestamp) VALUES (?, ?, ?, ?, ?)",
            (guild_id, str(sent_msg.id), user_id, content, discord.utils.utcnow().isoformat()),
        )
        # Update rate limit
        await self.cog.bot.db.execute(
            "INSERT OR REPLACE INTO anon_cooldowns (guild, user_id, last_post) VALUES (?, ?, ?)",
            (guild_id, user_id, now),
        )
        await self.cog.bot.db.commit()

        await interaction.response.send_message("Your message was sent into the void.", ephemeral=True)


class SecretButtonView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(label="Input Message", style=discord.ButtonStyle.blurple, custom_id="secret_button")
    async def send_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SecretInputModal(self.cog))


class UtilitiesCog(commands.Cog):
    """Anonymous messaging and time capsule system."""

    def __init__(self, bot):
        self.bot = bot
        self.check_capsules.start()

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[Anon imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    async def cog_load(self):
        self.bot.add_view(SecretButtonView(self))

    def cog_unload(self):
        self.check_capsules.cancel()

    @app_commands.command(name="setup_dropbox", description="Create a button for users to send private messages.")
    @app_commands.describe(text="The prompt text above the button")
    @app_commands.default_permissions(administrator=True)
    async def setup_dropbox(self, interaction: discord.Interaction, text: str):
        embed = discord.Embed(title="Drop Box", description=text, color=discord.Color.orange())
        view = SecretButtonView(self)
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general",
                    card_type="alert", alert_type="anon",
                    title="Drop Box", description=text, severity="info")
                f = self.bot.imaging.make_file(b, "alert.png")
                await interaction.channel.send(file=f, view=view)
                return await interaction.response.send_message("Drop box set up successfully!", ephemeral=True)
            except Exception as exc:
                print(f"[Anon imaging] {exc}")
        await interaction.channel.send(embed=embed, view=view)
        await interaction.response.send_message("Drop box set up successfully!", ephemeral=True)

    @app_commands.command(name="timecapsule", description="Send a message into the future.")
    @app_commands.describe(message="What do you want to say?", minutes="How many minutes until it sends?")
    async def timecapsule(self, interaction: discord.Interaction, message: str, minutes: int):
        if minutes <= 0:
            return await interaction.response.send_message(
                "Pick a positive number of minutes.", ephemeral=True
            )
        unlock_time = time.time() + (minutes * 60)
        capsules = load_capsules()
        capsules.append({"author_id": interaction.user.id, "message": message, "unlock_time": unlock_time})
        save_capsules(capsules)
        await interaction.response.send_message(
            f"Capsule buried! It will open in the designated channel in **{minutes} minute(s)**.", ephemeral=True
        )

    @tasks.loop(seconds=CAPSULE_CONFIG["check_loop_seconds"])
    async def check_capsules(self):
        await self.bot.wait_until_ready()
        capsules = load_capsules()
        if not capsules:
            return
        now = time.time()
        remaining = []
        for capsule in capsules:
            if now >= capsule["unlock_time"]:
                channel = self.bot.get_channel(CAPSULE_CONFIG["target_channel_id"])
                if channel:
                    await channel.send(f"**Time Capsule from <@{capsule['author_id']}>:**\n{capsule['message']}")
            else:
                remaining.append(capsule)
        if len(capsules) != len(remaining):
            save_capsules(remaining)

    # ─── Staff commands ────────────────────────────────────────────────────

    @commands.command(name="anon-ban")
    @commands.has_permissions(manage_messages=True)
    async def anon_ban(self, ctx, member: discord.Member):
        """Silently block a user from using the anonymous message system."""
        guild_id = str(ctx.guild.id)
        user_id = str(member.id)
        async with self.bot.db.execute(
            "SELECT 1 FROM anon_bans WHERE guild = ? AND user_id = ?", (guild_id, user_id)
        ) as cursor:
            exists = await cursor.fetchone()
        if exists:
            await self.bot.db.execute(
                "DELETE FROM anon_bans WHERE guild = ? AND user_id = ?", (guild_id, user_id)
            )
            await self.bot.db.commit()
            await ctx.send(embed=discord.Embed(
                description=f"✅ Removed anon ban for {member.mention}.", color=0x57F287
            ), delete_after=10)
        else:
            await self.bot.db.execute(
                "INSERT OR IGNORE INTO anon_bans (guild, user_id) VALUES (?, ?)", (guild_id, user_id)
            )
            await self.bot.db.commit()
            await ctx.send(embed=discord.Embed(
                description=f"🚫 {member.mention} is now banned from the anon system.", color=0xFFA500
            ), delete_after=10)
        try:
            await ctx.message.delete()
        except discord.Forbidden:
            pass

    @commands.command(name="anon-reveal")
    @commands.is_owner()
    async def anon_reveal(self, ctx, message_id: int):
        """Owner-only: reveal who sent an anonymous message by its ID."""
        guild_id = str(ctx.guild.id)
        async with self.bot.db.execute(
            "SELECT user_id, content, timestamp FROM anon_log WHERE guild = ? AND message_id = ?",
            (guild_id, str(message_id)),
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return await ctx.author.send("No anon log found for that message ID.")
        user = self.bot.get_user(int(row["user_id"])) or await self.bot.fetch_user(int(row["user_id"]))
        embed = discord.Embed(
            title="🔍 Anon Reveal (confidential)",
            description=f"**Sender:** {user.mention} (`{user}` · `{user.id}`)\n**Content:** {row['content']}\n**Sent:** {row['timestamp'][:19]}",
            color=0xED4245,
        )
        try:
            await ctx.message.delete()
        except discord.Forbidden:
            pass
        await self._send_card(ctx.author, embed,
            card_type="alert", alert_type="anon",
            title="Anon Reveal (confidential)",
            description=f"Sender: {user} ({user.id})\nContent: {row['content']}\nSent: {row['timestamp'][:19]}",
            severity="critical",
            user_name=str(user), user_id=user.id,
        )


async def setup(bot):
    await bot.add_cog(UtilitiesCog(bot))
