import discord
from discord.ext import commands
from collections import defaultdict, deque
import asyncio
import time


MAX_SNIPES = 20
MAX_ATTACHMENTS = 50
SNIPE_AUTO_DELETE = 300  # 5 minutes


class Snipe(commands.Cog):
    """Message sniping — deleted, edited, and reacted messages."""

    def __init__(self, bot):
        self.bot = bot
        # {channel_id: deque of dicts}
        self.snipes:  dict[int, deque] = defaultdict(lambda: deque(maxlen=MAX_SNIPES))
        self.esnipes: dict[int, deque] = defaultdict(lambda: deque(maxlen=MAX_SNIPES))
        self.rsnipes: dict[int, deque] = defaultdict(lambda: deque(maxlen=MAX_SNIPES))
        # {channel_id: deque of attachment dicts}
        self.attachments: dict[int, deque] = defaultdict(lambda: deque(maxlen=MAX_ATTACHMENTS))

    # ─── Imaging helper ───────────────────────────────────────────────────

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        
        if hasattr(self.bot, 'imaging'):
            try:
                # Use the enhanced render_and_send method
                return await self.bot.imaging.render_and_send(
                    ctx_or_channel=reply_to or send_to,
                    template_name="general",
                    filename=f"{kwargs.get('card_type', 'card')}.png",
                    reply=(reply_to is not None),
                    embed_title=fallback_embed.title if fallback_embed else f"Snipe: {kwargs.get('snipe_type', 'Action').title()}",
                    embed_description=fallback_embed.description if fallback_embed else None,
                    embed_color=fallback_embed.color.value if fallback_embed else 0x5865F2,
                    embed_fields=[{"name": f.name, "value": f.value, "inline": f.inline} for f in fallback_embed.fields] if fallback_embed else None,
                    **kwargs
                )
            except Exception as exc:
                print(f"[Snipe imaging] {exc}")
        
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    # ─── Cooldown helper ──────────────────────────────────────────────────
    _snipe_cooldowns: dict[int, float] = {}

    async def _check_cooldown(self, ctx) -> bool:
        """Returns True if user is NOT on cooldown (allowed to proceed)."""
        now = time.time()
        last = self._snipe_cooldowns.get(ctx.author.id, 0)
        if now - last < 5:
            remaining = round(5 - (now - last))
            await ctx.send(
                embed=discord.Embed(
                    description=f"⏱ Snipe cooldown. Try again in **{remaining}s**.",
                    color=0xED4245,
                ),
                delete_after=5,
            )
            return False
        self._snipe_cooldowns[ctx.author.id] = now
        return True

    async def _is_opted_out(self, guild_id: int, user_id: int) -> bool:
        async with self.bot.db.execute(
            "SELECT 1 FROM snipe_optout WHERE guild = ? AND user_id = ?",
            (str(guild_id), str(user_id)),
        ) as cursor:
            return bool(await cursor.fetchone())

    # ─── Listeners ────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.author.bot or not message.guild:
            return
        if await self._is_opted_out(message.guild.id, message.author.id):
            return
        entry = {
            "content": message.content or "",
            "author": message.author,
            "time": message.created_at,
            "attachments": [
                {"url": a.url, "filename": a.filename, "content_type": a.content_type or ""}
                for a in message.attachments
            ],
        }
        self.snipes[message.channel.id].appendleft(entry)
        for a in message.attachments:
            self.attachments[message.channel.id].appendleft({
                "url": a.url,
                "filename": a.filename,
                "content_type": a.content_type or "",
                "author": message.author,
                "time": message.created_at,
            })

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if before.author.bot or not before.guild:
            return
        if before.content == after.content:
            return
        if await self._is_opted_out(before.guild.id, before.author.id):
            return
        self.esnipes[before.channel.id].appendleft({
            "before": before.content,
            "after": after.content,
            "author": before.author,
            "time": before.created_at,
            "jump_url": after.jump_url,
        })

    @commands.Cog.listener()
    async def on_reaction_add(self, reaction, user):
        if user.bot or not reaction.message.guild:
            return
        self.rsnipes[reaction.message.channel.id].appendleft({
            "emoji": str(reaction.emoji),
            "user": user,
            "message_content": reaction.message.content or "*[no text content]*",
            "message_author": reaction.message.author,
            "time": discord.utils.utcnow(),
            "jump_url": reaction.message.jump_url,
        })

    # ─── Commands ─────────────────────────────────────────────────────────

    @commands.command(name="snipe")
    async def snipe(self, ctx, index: int = 1):
        """Snipe a recently deleted message. !snipe 2 for 2nd most recent."""
        if not await self._check_cooldown(ctx):
            return
        cache = self.snipes[ctx.channel.id]
        if not cache:
            return await ctx.send(embed=discord.Embed(description="Nothing to snipe.", color=0xED4245))
        index -= 1
        if index < 0 or index >= len(cache):
            return await ctx.send(embed=discord.Embed(description=f"Only **{len(cache)}** sniped message(s) available.", color=0xED4245))

        s = cache[index]

        # Build fallback embed
        fallback = discord.Embed(
            description=s["content"] or "*[no text content]*",
            color=0xED4245,
            timestamp=s["time"],
        )
        fallback.set_author(name=str(s["author"]), icon_url=s["author"].display_avatar.url)
        fallback.set_footer(text=f"Snipe #{index + 1} of {len(cache)}")
        for att in s.get("attachments", []):
            if att["content_type"].startswith("image/"):
                fallback.set_image(url=att["url"])
                break

        msg = await self._send_card(
            ctx, fallback,
            card_type="snipe", snipe_type="delete",
            author_name=s["author"].display_name,
            author_id=s["author"].id,
            content=s["content"] or None,
            channel_name=ctx.channel.name,
            sniped_at=s["time"],
            user=s["author"],
        )
        await asyncio.sleep(SNIPE_AUTO_DELETE)
        try:
            await msg.delete()
        except (discord.NotFound, AttributeError):
            pass

    @commands.command(name="esnipe")
    async def esnipe(self, ctx, index: int = 1):
        """Snipe a recently edited message, showing before and after."""
        if not await self._check_cooldown(ctx):
            return
        cache = self.esnipes[ctx.channel.id]
        if not cache:
            return await ctx.send(embed=discord.Embed(description="Nothing to edit-snipe.", color=0xFFA500))
        index -= 1
        if index < 0 or index >= len(cache):
            return await ctx.send(embed=discord.Embed(description=f"Only **{len(cache)}** edit-sniped message(s) available.", color=0xED4245))

        s = cache[index]

        fallback = discord.Embed(color=0xFFA500, timestamp=s["time"])
        fallback.set_author(name=str(s["author"]), icon_url=s["author"].display_avatar.url)
        fallback.add_field(name="Before", value=s["before"][:1024] or "*[empty]*", inline=False)
        fallback.add_field(name="After", value=s["after"][:1024] or "*[empty]*", inline=False)
        fallback.set_footer(text=f"Edit snipe #{index + 1} of {len(cache)}")
        if s.get("jump_url"):
            fallback.description = f"[Jump to message]({s['jump_url']})"

        msg = await self._send_card(
            ctx, fallback,
            card_type="snipe", snipe_type="edit",
            author_name=s["author"].display_name,
            author_id=s["author"].id,
            content=s["after"] or None,
            before_content=s["before"] or None,
            channel_name=ctx.channel.name,
            sniped_at=s["time"],
            user=s["author"],
        )
        await asyncio.sleep(SNIPE_AUTO_DELETE)
        try:
            await msg.delete()
        except (discord.NotFound, AttributeError):
            pass

    @commands.command(name="rsnipe")
    async def rsnipe(self, ctx, index: int = 1):
        """Snipe a recent reaction added in this channel."""
        if not await self._check_cooldown(ctx):
            return
        cache = self.rsnipes[ctx.channel.id]
        if not cache:
            return await ctx.send(embed=discord.Embed(description="Nothing to reaction-snipe.", color=0x57F287))
        index -= 1
        if index < 0 or index >= len(cache):
            return await ctx.send(embed=discord.Embed(description=f"Only **{len(cache)}** reaction-sniped event(s) available.", color=0xED4245))

        s = cache[index]

        fallback = discord.Embed(
            description=f"{s['user'].mention} reacted with **{s['emoji']}** to a message by **{s['message_author']}**",
            color=0x57F287,
            timestamp=s["time"],
        )
        fallback.add_field(name="Message Preview", value=s["message_content"][:512], inline=False)
        if s.get("jump_url"):
            fallback.add_field(name="Jump", value=f"[View message]({s['jump_url']})", inline=False)
        fallback.set_footer(text=f"Reaction snipe #{index + 1} of {len(cache)}")

        msg = await self._send_card(
            ctx, fallback,
            card_type="snipe", snipe_type="react",
            author_name=s["user"].display_name,
            author_id=s["user"].id,
            content=s["message_content"],
            reactions=s["emoji"],
            channel_name=ctx.channel.name,
            sniped_at=s["time"],
            user=s["user"],
        )
        await asyncio.sleep(SNIPE_AUTO_DELETE)
        try:
            await msg.delete()
        except (discord.NotFound, AttributeError):
            pass

    @commands.command(name="snipeclear")
    @commands.has_permissions(manage_messages=True)
    async def snipeclear(self, ctx, mode: str = "all"):
        """Clear the snipe cache for this channel.
        !snipeclear — clear deleted messages
        !snipeclear edits — clear edit snipes
        !snipeclear reactions — clear reaction snipes
        !snipeclear all — clear everything"""
        mode = mode.lower()
        cleared = []
        if mode in ("all", "deleted", "snipe"):
            self.snipes[ctx.channel.id].clear()
            self.attachments[ctx.channel.id].clear()
            cleared.append("deleted messages")
        if mode in ("all", "edits", "edit", "esnipe"):
            self.esnipes[ctx.channel.id].clear()
            cleared.append("edited messages")
        if mode in ("all", "reactions", "reaction", "rsnipe"):
            self.rsnipes[ctx.channel.id].clear()
            cleared.append("reactions")
        if not cleared:
            return await ctx.send(embed=discord.Embed(description="Unknown mode. Use `all`, `edits`, or `reactions`.", color=0xED4245))
        await ctx.send(embed=discord.Embed(
            description=f"🗑️ Cleared snipe cache: {', '.join(cleared)} in {ctx.channel.mention}.",
            color=0x57F287,
        ))

    @commands.command(name="snipeme")
    async def snipeme(self, ctx, setting: str = None):
        """Opt out of (or back into) being sniped.
        !snipeme off — opt out (your deleted messages won't be cached)
        !snipeme on  — opt back in"""
        guild_id = str(ctx.guild.id)
        user_id = str(ctx.author.id)
        async with self.bot.db.execute(
            "SELECT 1 FROM snipe_optout WHERE guild = ? AND user_id = ?", (guild_id, user_id)
        ) as cursor:
            is_opted_out = bool(await cursor.fetchone())

        if setting is None:
            status = "opted **out**" if is_opted_out else "opted **in**"
            return await ctx.send(embed=discord.Embed(
                description=f"You are currently {status} of snipe tracking. Use `!snipeme on/off` to change.",
                color=0x5865F2,
            ))

        if setting.lower() == "off":
            if is_opted_out:
                return await ctx.send(embed=discord.Embed(description="You're already opted out.", color=0xFFA500))
            await self.bot.db.execute(
                "INSERT OR IGNORE INTO snipe_optout (guild, user_id) VALUES (?, ?)", (guild_id, user_id)
            )
            await self.bot.db.commit()
            await ctx.send(embed=discord.Embed(description="✅ You've opted **out** of snipe tracking. Your deleted messages won't be cached.", color=0x57F287))
        elif setting.lower() == "on":
            if not is_opted_out:
                return await ctx.send(embed=discord.Embed(description="You're already opted in.", color=0xFFA500))
            await self.bot.db.execute(
                "DELETE FROM snipe_optout WHERE guild = ? AND user_id = ?", (guild_id, user_id)
            )
            await self.bot.db.commit()
            await ctx.send(embed=discord.Embed(description="✅ You've opted **in** to snipe tracking.", color=0x57F287))
        else:
            await ctx.send(embed=discord.Embed(description="Use `!snipeme on` or `!snipeme off`.", color=0xED4245))


async def setup(bot):
    await bot.add_cog(Snipe(bot))
