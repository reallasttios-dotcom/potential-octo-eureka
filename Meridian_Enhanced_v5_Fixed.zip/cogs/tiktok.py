import discord
from discord.ext import commands
import re
import aiohttp
import io
import asyncio

TIKTOK_REGEX = r"(https?://(www\.)?(vm|vt|tiktok)\.com/[^\s]+)"

class TikTok(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.session = None

    async def cog_load(self):
        # Create the session inside an async context!
        # Adding a User-Agent so APIs don't block the bot
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
        }
        self.session = aiohttp.ClientSession(headers=headers)

    async def cog_unload(self):
        # Clean up the session when the cog is removed
        if self.session:
            await self.session.close()

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        match = re.search(TIKTOK_REGEX, message.content)
        if not match:
            return

        url = match.group(0)

        # Wait 2 seconds for Discord to generate the embed, THEN suppress it
        async def suppress_embed():
            await asyncio.sleep(2)
            try:
                await message.edit(suppress=True)
            except discord.Forbidden:
                pass # Bot lacks manage_messages permission
                
        self.bot.loop.create_task(suppress_embed())

        api_url = f"https://tikwm.com/api/?url={url}"

        try:
            # Trip 1: Get data
            async with self.session.get(api_url) as resp:
                if resp.status != 200:
                    print(f"TikWM API Error: {resp.status}")
                    return
                data = await resp.json()

            if data.get("code") != 0 or "play" not in data.get("data", {}):
                print(f"TikWM returned error code: {data.get('code')}")
                return

            video_url = data["data"]["play"]

            # Trip 2: Download video
            async with self.session.get(video_url) as resp:
                if resp.status != 200:
                    return
                video_bytes = await resp.read()

            # Discord's file size check (Standard is 25MB)
            if len(video_bytes) > 25 * 1024 * 1024:
                await message.channel.send("TikTok too chunky for Discord (Over 25MB).", delete_after=5)
                return

            await message.reply(
                file=discord.File(fp=io.BytesIO(video_bytes), filename="tiktok.mp4"),
                mention_author=False
            )
        except Exception as e:
            print(f"Internal error processing TikTok: {e}")

async def setup(bot):
    await bot.add_cog(TikTok(bot))
