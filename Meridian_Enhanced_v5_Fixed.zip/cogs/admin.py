import discord
from discord.ext import commands
import math
from datetime import datetime


def calculate_level(xp):
    return int(math.sqrt(xp) * 0.15)


def xp_for_level(level):
    return math.ceil((level / 0.15) ** 2)


def ok(text, color=0x57F287):
    return discord.Embed(description=text, color=color)


def err(text):
    return discord.Embed(description=text, color=0xED4245)


class Admin(commands.Cog):
    """XP and leveling administration commands."""

    def __init__(self, bot):
        self.bot = bot

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[Admin imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    async def get_or_create_user(self, guild_id, user_id):
        async with self.bot.db.execute(
            "SELECT * FROM levels WHERE user = ? AND guild = ?",
            (str(user_id), str(guild_id)),
        ) as cursor:
            score = await cursor.fetchone()

        if not score:
            return {
                "id": f"{user_id}-{guild_id}",
                "user": str(user_id),
                "guild": str(guild_id),
                "xp": 0, "level": 0, "totalXP": 0,
                "streakDays": 0, "lastMessageDate": None,
                "globalMultiplier": 1.0,
            }
        return dict(score)

    async def update_user_db(self, score):
        await self.bot.db.execute(
            """INSERT OR REPLACE INTO levels
               (id, user, guild, xp, level, totalXP, streakDays, lastMessageDate, globalMultiplier)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                score["id"], score["user"], score["guild"],
                score["xp"], score["level"], score["totalXP"],
                score.get("streakDays", 0), score.get("lastMessageDate"),
                score.get("globalMultiplier", 1.0),
            ),
        )
        await self.bot.db.commit()

    async def log_xp(self, guild_id, user_id, delta, reason):
        await self.bot.db.execute(
            "INSERT INTO xp_log (guild, user_id, delta, reason, timestamp) VALUES (?, ?, ?, ?, ?)",
            (str(guild_id), str(user_id), delta, reason, datetime.utcnow().isoformat()),
        )
        await self.bot.db.commit()

    # ─── Original commands ────────────────────────────────────────────────

    @commands.command(name="add-level", aliases=["give-level"])
    @commands.has_permissions(manage_guild=True)
    async def add_level(self, ctx, member: discord.Member = None, levels: int = None):
        """Give levels to a user."""
        if not member or not levels or levels < 1:
            return await ctx.send(embed=err("Usage: `!add-level @user <amount>`"))
        score = await self.get_or_create_user(ctx.guild.id, member.id)
        current_level = calculate_level(score.get("totalXP", 0))
        new_level = current_level + levels
        score["totalXP"] = xp_for_level(new_level)
        score["level"] = new_level
        score["xp"] = score["totalXP"]
        await self.update_user_db(score)
        await ctx.send(embed=ok(f"Added **{levels}** level(s) to {member.mention}. They are now level **{new_level}**."))

    @commands.command(name="remove-level")
    @commands.has_permissions(manage_guild=True)
    async def remove_level(self, ctx, member: discord.Member = None, levels: int = None):
        """Remove levels from a user."""
        if not member or not levels or levels < 1:
            return await ctx.send(embed=err("Usage: `!remove-level @user <amount>`"))
        score = await self.get_or_create_user(ctx.guild.id, member.id)
        current_level = calculate_level(score.get("totalXP", 0))
        new_level = max(0, current_level - levels)
        score["totalXP"] = xp_for_level(new_level)
        score["level"] = new_level
        score["xp"] = score["totalXP"]
        await self.update_user_db(score)
        await ctx.send(embed=ok(f"Removed **{levels}** level(s) from {member.mention}. Now level **{new_level}**.", 0xFFA500))

    @commands.command(name="set-level")
    @commands.has_permissions(manage_guild=True)
    async def set_level(self, ctx, member: discord.Member = None, level: int = None):
        """Set a user's level directly."""
        if not member or level is None or level < 0:
            return await ctx.send(embed=err("Usage: `!set-level @user <level>`"))
        score = await self.get_or_create_user(ctx.guild.id, member.id)
        score["level"] = level
        score["totalXP"] = xp_for_level(level)
        score["xp"] = score["totalXP"]
        await self.update_user_db(score)
        await ctx.send(embed=ok(f"Set {member.mention}'s level to **{level}**."))

    @commands.command(name="give-xp")
    @commands.has_permissions(manage_guild=True)
    async def give_xp(self, ctx, member: discord.Member = None, amount: int = None):
        """Give XP to a user."""
        if not member or not amount or amount < 1:
            return await ctx.send(embed=err("Usage: `!give-xp @user <amount>`"))
        score = await self.get_or_create_user(ctx.guild.id, member.id)
        score["totalXP"] += amount
        score["xp"] = score["totalXP"]
        score["level"] = calculate_level(score["totalXP"])
        await self.update_user_db(score)
        await self.log_xp(ctx.guild.id, member.id, amount, f"Manual grant by {ctx.author}")
        await ctx.send(embed=ok(f"Gave **{amount:,} XP** to {member.mention}."))

    @commands.command(name="set-xp")
    @commands.has_permissions(manage_guild=True)
    async def set_xp(self, ctx, member: discord.Member = None, amount: int = None):
        """Set a user's XP to a specific amount."""
        if not member or amount is None or amount < 0:
            return await ctx.send(embed=err("Usage: `!set-xp @user <amount>`"))
        score = await self.get_or_create_user(ctx.guild.id, member.id)
        old = score["totalXP"]
        score["totalXP"] = amount
        score["xp"] = amount
        score["level"] = calculate_level(amount)
        await self.update_user_db(score)
        await self.log_xp(ctx.guild.id, member.id, amount - old, f"Manual set by {ctx.author}")
        await ctx.send(embed=ok(f"Set {member.mention}'s XP to **{amount:,}**."))

    @commands.command(name="reset-xp")
    @commands.has_permissions(manage_guild=True)
    async def reset_xp(self, ctx, member: discord.Member = None):
        """Reset a user's XP and level to 0."""
        if not member:
            return await ctx.send(embed=err("Usage: `!reset-xp @user`"))
        score = await self.get_or_create_user(ctx.guild.id, member.id)
        old = score["totalXP"]
        score["totalXP"] = 0
        score["xp"] = 0
        score["level"] = 0
        score["streakDays"] = 0
        await self.update_user_db(score)
        await self.log_xp(ctx.guild.id, member.id, -old, f"Reset by {ctx.author}")
        await ctx.send(embed=ok(f"Reset all XP data for {member.mention}.", 0xED4245))

    @commands.command(name="reset-leaderboard")
    async def reset_leaderboard(self, ctx, confirm: str = None):
        """Reset the entire server leaderboard. Server owner only."""
        if ctx.author.id != ctx.guild.owner_id:
            return await ctx.reply(embed=err("Only the server owner can use this command."))
        if confirm != "confirm":
            embed = discord.Embed(
                color=0xFFA500,
                title="⚠️ Warning: Reset Leaderboard",
                description="This will **permanently delete** all XP data for this server.\nType `!reset-leaderboard confirm` to proceed.",
            )
            return await self._send_card(ctx, embed,
                card_type="alert",
                alert_type="admin",
                title="Warning: Reset Leaderboard",
                description="This will permanently delete all XP data for this server. Type !reset-leaderboard confirm to proceed.",
                severity="warning",
            )
        await self.bot.db.execute("DELETE FROM levels WHERE guild = ?", (str(ctx.guild.id),))
        await self.bot.db.commit()
        await ctx.send(embed=ok("The leaderboard has been completely wiped.", 0xED4245))

    # ─── New XP Management Commands ───────────────────────────────────────

    @commands.command(name="xp-multiplier")
    @commands.has_permissions(manage_guild=True)
    async def xp_multiplier(self, ctx, member: discord.Member = None, multiplier: float = None):
        """Set a per-user XP multiplier (e.g. !xp-multiplier @user 1.5).
        Use 'reset' to remove it: !xp-multiplier @user reset"""
        if not member:
            return await ctx.send(embed=err("Usage: `!xp-multiplier @user <multiplier|reset>`"))
        if multiplier is None:
            # Show current
            async with self.bot.db.execute(
                "SELECT multiplier FROM xp_user_multipliers WHERE guild = ? AND user_id = ?",
                (str(ctx.guild.id), str(member.id)),
            ) as cursor:
                row = await cursor.fetchone()
            val = row["multiplier"] if row else 1.0
            return await ctx.send(embed=ok(f"{member.mention} has a **{val}×** XP multiplier."))
        if multiplier < 0.1 or multiplier > 10.0:
            return await ctx.send(embed=err("Multiplier must be between **0.1** and **10.0**."))
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO xp_user_multipliers (guild, user_id, multiplier) VALUES (?, ?, ?)",
            (str(ctx.guild.id), str(member.id), multiplier),
        )
        await self.bot.db.commit()
        await ctx.send(embed=ok(f"Set {member.mention}'s XP multiplier to **{multiplier}×**."))

    @commands.command(name="server-multiplier")
    @commands.has_permissions(manage_guild=True)
    async def server_multiplier(self, ctx, multiplier: str = None):
        """Set a server-wide XP multiplier (e.g. !server-multiplier 2.0 for double XP).
        Use 'reset' to restore to 1.0."""
        if not multiplier:
            async with self.bot.db.execute(
                "SELECT globalMultiplier FROM settings WHERE guild = ?",
                (str(ctx.guild.id),),
            ) as cursor:
                row = await cursor.fetchone()
            val = row["globalMultiplier"] if row else 1.0
            return await ctx.send(embed=ok(f"Current server XP multiplier: **{val}×**."))
        if multiplier.lower() == "reset":
            mult = 1.0
        else:
            try:
                mult = float(multiplier)
            except ValueError:
                return await ctx.send(embed=err("Usage: `!server-multiplier <number|reset>`"))
            if mult < 0.1 or mult > 10.0:
                return await ctx.send(embed=err("Multiplier must be between **0.1** and **10.0**."))
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO settings (guild, globalMultiplier) VALUES (?, ?)"
            " ON CONFLICT(guild) DO UPDATE SET globalMultiplier = excluded.globalMultiplier",
            (str(ctx.guild.id), mult),
        )
        await self.bot.db.commit()
        if mult == 1.0:
            await ctx.send(embed=ok("Server XP multiplier reset to **1.0×**."))
        else:
            await ctx.send(embed=ok(f"🎉 Server XP multiplier set to **{mult}×**! Event active."))

    @commands.command(name="transfer-xp")
    @commands.has_permissions(manage_guild=True)
    async def transfer_xp(self, ctx, source: discord.Member = None, target: discord.Member = None, amount: int = None):
        """Transfer XP from one user to another."""
        if not source or not target or not amount or amount < 1:
            return await ctx.send(embed=err("Usage: `!transfer-xp @from @to <amount>`"))
        if source == target:
            return await ctx.send(embed=err("Source and target must be different users."))
        src = await self.get_or_create_user(ctx.guild.id, source.id)
        if src["totalXP"] < amount:
            return await ctx.send(embed=err(f"{source.mention} only has **{src['totalXP']:,} XP**. Can't transfer more than they have."))
        tgt = await self.get_or_create_user(ctx.guild.id, target.id)
        src["totalXP"] -= amount
        src["xp"] = src["totalXP"]
        src["level"] = calculate_level(src["totalXP"])
        tgt["totalXP"] += amount
        tgt["xp"] = tgt["totalXP"]
        tgt["level"] = calculate_level(tgt["totalXP"])
        await self.update_user_db(src)
        await self.update_user_db(tgt)
        await self.log_xp(ctx.guild.id, source.id, -amount, f"Transfer to {target} by {ctx.author}")
        await self.log_xp(ctx.guild.id, target.id, amount, f"Transfer from {source} by {ctx.author}")
        await ctx.send(embed=ok(f"Transferred **{amount:,} XP** from {source.mention} → {target.mention}."))

    @commands.command(name="xp-history")
    @commands.has_permissions(manage_guild=True)
    async def xp_history(self, ctx, member: discord.Member = None):
        """Show the last 10 XP changes for a user."""
        if not member:
            return await ctx.send(embed=err("Usage: `!xp-history @user`"))
        async with self.bot.db.execute(
            "SELECT delta, reason, timestamp FROM xp_log WHERE guild = ? AND user_id = ? ORDER BY id DESC LIMIT 10",
            (str(ctx.guild.id), str(member.id)),
        ) as cursor:
            rows = await cursor.fetchall()
        if not rows:
            return await ctx.send(embed=ok(f"No XP history found for {member.mention}."))
        lines = []
        for row in rows:
            sign = "+" if row["delta"] >= 0 else ""
            ts = row["timestamp"][:10] if row["timestamp"] else "?"
            lines.append(f"`[{ts}]` **{sign}{row['delta']:,} XP** — {row['reason']}")
        embed = discord.Embed(
            title=f"XP History for {member.display_name}",
            description="\n".join(lines),
            color=0x5865F2,
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        await self._send_card(ctx, embed,
            card_type="info",
            title=f"XP History for {member.display_name}",
            description="\n".join(lines),
            fields=[("Total Entries", str(len(rows)), True)],
        )

    @commands.command(name="xp-blacklist")
    @commands.has_permissions(manage_guild=True)
    async def xp_blacklist(self, ctx, member: discord.Member = None):
        """Block a user from earning XP (without resetting their existing XP).
        Use again to unblacklist."""
        if not member:
            return await ctx.send(embed=err("Usage: `!xp-blacklist @user`"))
        async with self.bot.db.execute(
            "SELECT 1 FROM xp_user_blacklist WHERE guild = ? AND user_id = ?",
            (str(ctx.guild.id), str(member.id)),
        ) as cursor:
            exists = await cursor.fetchone()
        if exists:
            await self.bot.db.execute(
                "DELETE FROM xp_user_blacklist WHERE guild = ? AND user_id = ?",
                (str(ctx.guild.id), str(member.id)),
            )
            await self.bot.db.commit()
            await ctx.send(embed=ok(f"Removed {member.mention} from the XP blacklist. They can earn XP again."))
        else:
            await self.bot.db.execute(
                "INSERT OR IGNORE INTO xp_user_blacklist (guild, user_id) VALUES (?, ?)",
                (str(ctx.guild.id), str(member.id)),
            )
            await self.bot.db.commit()
            await ctx.send(embed=ok(f"Added {member.mention} to the XP blacklist. Their existing XP is kept.", 0xFFA500))


async def setup(bot):
    await bot.add_cog(Admin(bot))
