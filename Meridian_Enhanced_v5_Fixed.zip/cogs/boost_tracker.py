import discord
from discord.ext import commands
import json
import os
from typing import Dict, Optional

# ---------- Data handling ----------
def load_data() -> dict:
    """Load boost data from JSON file, initializing default structure."""
    if not os.path.exists("boost_data.json"):
        return {
            "spawn_role_id": None,
            "booster_roles": {},          # user_id -> custom_role_id
            "boost_counts": {},           # user_id -> total boost count
            "boost_channel_id": 1491687751441973258  # target channel for boost announcements
        }
    with open("boost_data.json", "r") as f:
        data = json.load(f)
    # Ensure all required keys exist (for older data files)
    if "boost_counts" not in data:
        data["boost_counts"] = {}
    if "boost_channel_id" not in data:
        data["boost_channel_id"] = 1491687751441973258
    return data

def save_data(data: dict) -> None:
    """Save boost data to JSON file."""
    with open("boost_data.json", "w") as f:
        json.dump(data, f, indent=4)

# ---------- Emoji mapping for boost counts ----------
BOOST_EMOJI_MAP = {
    1: "<a:boost1:1491679739327549520>",
    2: "<a:boost2:1491679759183380592>",
    3: "<a:boost3:1491679749897195520>",
    6: "<a:boost6:1491679768280567839>",
    9: "<a:boost9:1491679777999028468>",
    12: "<a:boost12:1491679796332072970>",
    15: "<a:boost15:1491679786840621147>",
    18: "<a:boost18:1491679805719056514>"
}

def get_boost_emoji(count: int) -> str:
    """
    Return the appropriate animated emoji based on total boost count.
    If count exceeds the highest defined key (18), the 18-emoji is returned.
    For intermediate values, the nearest lower key is used.
    """
    if count <= 0:
        return BOOST_EMOJI_MAP[1]  # fallback
    # Find the largest key <= count
    chosen = max((k for k in BOOST_EMOJI_MAP.keys() if k <= count), default=1)
    return BOOST_EMOJI_MAP[chosen]

# ---------- Cog ----------
class BoostTracker(commands.Cog):
    """Tracks server boosts, announces them with a counter, and manages custom booster roles."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.data = load_data()
        self.em = bot.get_cog("EmojiManager")

    def e(self, key: str) -> str:
        """Helper to get emoji from EmojiManager if available."""
        return self.em.get_emoji("BoostTracker", key) if self.em else ""

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[BoostTracker imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    # ---------- Boost detection & announcement ----------
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        # Only act on official Discord boost messages
        if message.type not in (
            discord.MessageType.premium_guild_subscription,
            discord.MessageType.premium_guild_tier_1,
            discord.MessageType.premium_guild_tier_2,
            discord.MessageType.premium_guild_tier_3
        ):
            return

        # Delete the original system boost message
        try:
            await message.delete()
        except discord.Forbidden:
            pass  # Ignore if we lack permissions

        user = message.author
        guild = message.guild
        if not guild:
            return

        # --- Update boost counter for this user ---
        user_id_str = str(user.id)
        boost_counts = self.data["boost_counts"]
        new_count = boost_counts.get(user_id_str, 0) + 1
        boost_counts[user_id_str] = new_count
        save_data(self.data)

        # --- Send announcement to the configured channel ---
        channel_id = self.data.get("boost_channel_id")
        if not channel_id:
            # fallback: use the same channel as the boost message
            channel = message.channel
        else:
            channel = self.bot.get_channel(channel_id)
            if not channel:
                # If configured channel not found, fallback to message channel
                channel = message.channel

        boost_emoji = get_boost_emoji(new_count)
        embed = discord.Embed(
            title=f"{self.e('boost_transparent')} NEW SERVER BOOST! {self.e('boost_transparent')}",
            description=(
                f"Huge thanks to {user.mention} for boosting the server! {self.e('ping_4')}\n\n"
                f"You have now boosted **{new_count}** time{'s' if new_count != 1 else ''} {boost_emoji}\n"
                "Enjoy your premium perks, you legend."
            ),
            color=discord.Color.fuchsia()
        )
        embed.set_thumbnail(url=user.display_avatar.url)

        try:
            await self._send_card(channel, embed,
                card_type="boost",
                user_name=user.display_name, user_id=user.id,
                boost_count=new_count,
                total_guild_boosts=guild.premium_subscription_count or 0,
                boost_emoji=str(boost_emoji),
            )
        except discord.Forbidden:
            await message.channel.send(embed=embed, content="(Could not post to boost channel – check permissions)")

    # ---------- Commands for booster roles (original) ----------
    @commands.command(name="setspawn")
    @commands.has_permissions(administrator=True)
    async def setspawn(self, ctx, role: discord.Role):
        """Set the role above which custom booster roles will be created."""
        self.data["spawn_role_id"] = role.id
        save_data(self.data)
        await ctx.send(f"Booster roles will now spawn just above {role.mention}.")

    @commands.command(name="claimrole")
    async def claimrole(self, ctx, name: str, hex_color: str):
        """Create a custom role for a booster (one per user)."""
        if not ctx.author.premium_since:
            return await ctx.send("You need to be a server booster to use this!")

        if not self.data.get("spawn_role_id"):
            return await ctx.send("The admins haven't set a spawn role yet. Tell them to run `!setspawn`.")

        spawn_role = ctx.guild.get_role(self.data["spawn_role_id"])
        if not spawn_role:
            return await ctx.send("The spawn role is missing or was deleted.")

        user_id = str(ctx.author.id)
        if user_id in self.data["booster_roles"]:
            old_role = ctx.guild.get_role(self.data["booster_roles"][user_id])
            if old_role:
                await old_role.delete(reason="Updating booster role")

        try:
            color = discord.Color(int(hex_color.strip("#"), 16))
        except ValueError:
            return await ctx.send("Invalid hex color. Use something like `#FF0000`.")

        new_role = await ctx.guild.create_role(name=name, color=color, hoist=True, reason="Booster custom role")

        try:
            await ctx.guild.edit_role_positions({new_role: spawn_role.position + 1})
            await ctx.author.add_roles(new_role)

            self.data["booster_roles"][user_id] = new_role.id
            save_data(self.data)
            await ctx.send(f"Your custom role {new_role.mention} has been created and equipped!")
        except discord.Forbidden:
            await new_role.delete()
            await ctx.send("I don't have permission to move roles that high up. My bot role needs to be higher!")

    # ---------- New commands for boost counter management ----------
    @commands.command(name="setboostchannel")
    @commands.has_permissions(administrator=True)
    async def setboostchannel(self, ctx, channel: discord.TextChannel):
        """Set the channel where boost announcements (with counters) will be sent."""
        self.data["boost_channel_id"] = channel.id
        save_data(self.data)
        await ctx.send(f"Boost announcements will now be sent to {channel.mention}.")

    @commands.command(name="booststats")
    async def booststats(self, ctx, user: Optional[discord.User] = None):
        """Show how many times a user has boosted the server."""
        target = user or ctx.author
        user_id_str = str(target.id)
        count = self.data["boost_counts"].get(user_id_str, 0)
        emoji = get_boost_emoji(count) if count > 0 else ""
        await ctx.send(f"{target.mention} has boosted this server **{count}** time{'s' if count != 1 else ''} {emoji}")

    @commands.command(name="syncboosters")
    @commands.has_permissions(administrator=True)
    async def syncboosters(self, ctx):
        """
        Detect untracked boosters (members with premium_since not in boost_counts)
        and announce them once in the boost channel with count=1.
        Useful after the bot was offline or newly added.
        """
        guild = ctx.guild
        boost_channel = self.bot.get_channel(self.data.get("boost_channel_id"))
        if not boost_channel:
            await ctx.send("Boost channel not found. Please set it with `!setboostchannel`.")
            return

        untracked = []
        for member in guild.members:
            if member.premium_since and str(member.id) not in self.data["boost_counts"]:
                untracked.append(member)

        if not untracked:
            await ctx.send("All current boosters are already tracked.")
            return

        await ctx.send(f"Found {len(untracked)} untracked booster(s). Announcing them in {boost_channel.mention}...")

        for member in untracked:
            # Set initial boost count to 1 (we only know they are currently boosting)
            self.data["boost_counts"][str(member.id)] = 1
            # Send announcement
            boost_emoji = get_boost_emoji(1)
            embed = discord.Embed(
                title=f"{self.e('boost_transparent')} SERVER BOOST DETECTED (SYNC) {self.e('boost_transparent')}",
                description=(
                    f"Welcome {member.mention}! Your boost has been registered. {self.e('ping_4')}\n\n"
                    f"You have now boosted **1** time {boost_emoji}\n"
                    "Enjoy your premium perks!"
                ),
                color=discord.Color.fuchsia()
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            await self._send_card(boost_channel, embed,
                card_type="boost",
                user_name=member.display_name, user_id=member.id,
                boost_count=1,
                total_guild_boosts=ctx.guild.premium_subscription_count or 0,
                boost_emoji=str(boost_emoji),
            )

        save_data(self.data)
        await ctx.send(f"✅ Successfully tracked and announced {len(untracked)} booster(s).")

# ---------- Setup ----------
async def setup(bot: commands.Bot):
    await bot.add_cog(BoostTracker(bot))