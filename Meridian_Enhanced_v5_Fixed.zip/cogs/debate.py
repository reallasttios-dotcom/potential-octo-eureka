import discord
from discord.ext import commands
import datetime
import time

class DebateHub(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.DEBATE_CHANNEL_ID = 1490941503105925161 
        self.DEBATE_ROLE_ID = 1490941991113199677     
        
        self.last_hint_time = 0
        self.user_cooldowns = {} 
        self.em = bot.get_cog("EmojiManager")
    def e(self, key):
        return self.em.get_emoji("DebateHub", key) if self.em else ""

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[DebateHub imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        role_pinged = any(role.id == self.DEBATE_ROLE_ID for role in message.role_mentions)
        if not role_pinged:
            return 

        current_time = time.time()

        # --- ADMIN DEBUG MODE ---
        if "debug" in message.content.lower() and message.author.guild_permissions.administrator:
            debate_channel = self.bot.get_channel(self.DEBATE_CHANNEL_ID)
            if not debate_channel:
                await message.channel.send("Debug fail: Bot can't see the debate channel. Check ID or perms.")
                return
            
            embed = discord.Embed(
                title="Debate Spotlight! [DEBUG TEST]",
                description="This is a dummy message to test the embed formatting and channel routing. If you're reading this, the system is working perfectly.",
                color=discord.Color.red(),
                timestamp=datetime.datetime.now(datetime.timezone.utc)
            )
            embed.set_author(name=f"Admin: {message.author.display_name}", icon_url=message.author.display_avatar.url)
            embed.add_field(name="Escalated By", value=message.author.mention, inline=True)
            embed.add_field(name="Original Channel", value=message.channel.mention, inline=True)
            embed.add_field(name="Link", value=f"[Jump to Conversation]({message.jump_url})", inline=False)

            await self._send_card(debate_channel, embed,
                card_type="debate",
                topic="[DEBUG TEST] This is a dummy message to test the embed formatting.",
                participants=[message.author.display_name],
                status="active",
                started_at=datetime.datetime.now(datetime.timezone.utc),
            )
            await message.add_reaction(self.e('channel'))
            return

        # --- NORMAL ESCALATION ---
        if message.reference:
            try:
                replied_message = await message.channel.fetch_message(message.reference.message_id)
                
                if len(replied_message.content) >= 20:
                    
                    last_used = self.user_cooldowns.get(message.author.id, 0)
                    if current_time - last_used < 86400:
                        hours, remainder = divmod(int(86400 - (current_time - last_used)), 3600)
                        minutes, _ = divmod(remainder, 60)
                        await message.channel.send(f"{message.author.mention}, you've already spotlighted a debate today. Try again in {hours}h {minutes}m.", delete_after=15)
                        return
                    
                    debate_channel = self.bot.get_channel(self.DEBATE_CHANNEL_ID)
                    if not debate_channel:
                        return
                    
                    topic_text = f"{replied_message.content[:1024]}..." if len(replied_message.content) > 1024 else replied_message.content
                    embed = discord.Embed(
                        title="Debate Spotlight!",
                        description=topic_text,
                        color=discord.Color.orange(),
                        timestamp=datetime.datetime.now(datetime.timezone.utc)
                    )
                    embed.set_author(name=replied_message.author.display_name, icon_url=replied_message.author.display_avatar.url)
                    embed.add_field(name="Escalated By", value=message.author.mention, inline=True)
                    embed.add_field(name="Original Channel", value=message.channel.mention, inline=True)
                    embed.add_field(name="Link", value=f"[Jump to Conversation]({replied_message.jump_url})", inline=False)

                    await self._send_card(debate_channel, embed,
                        card_type="debate",
                        topic=topic_text,
                        participants=[replied_message.author.display_name, message.author.display_name],
                        status="active",
                        started_at=datetime.datetime.now(datetime.timezone.utc),
                    )
                    await message.add_reaction(self.e('check'))
                    
                    self.user_cooldowns[message.author.id] = current_time
                    await self.bot.process_commands(message)
                    return 

            except discord.NotFound:
                pass 

        # --- HINT TRIGGER ---
        if current_time - self.last_hint_time >= 60:
            self.last_hint_time = current_time
            hint_text = (
                f"Hey {message.author.mention}, that's not how you use the debate role!\n\n"
                "To spotlight a topic, **reply** to the message you want to debate "
                "\n-#(must be 20+ characters) and mention the role in your reply."
            )
            await message.channel.send(hint_text, delete_after=120)

        await self.bot.process_commands(message)

async def setup(bot):
    await bot.add_cog(DebateHub(bot))