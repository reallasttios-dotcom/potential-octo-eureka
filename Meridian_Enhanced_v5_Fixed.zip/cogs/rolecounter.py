import discord
from discord.ext import commands, tasks
from discord import app_commands
import json
import re
from pathlib import Path

CONFIG_FILE = Path("role_config.json")

class RoleCounter(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = {
            "roles": set(),
            "channel_id": None,
            "message_id": None,
            "template": "{role} ({count}+ members)",
            "autorename_template": "{role} ({owncount}+ members)",
            "panel_overrides": {},     
            "rename_overrides": {},    
            "exclude_bots": True,
            "autorename": False
        }
        self.load_role_config()
        self.role_counter_updater.start()
        self.daily_role_rename.start()

    def cog_unload(self):
        self.role_counter_updater.cancel()
        self.daily_role_rename.cancel()

    # --- Persistence Helpers ---
    def save_role_config(self):
        data = {
            "roles": list(self.config["roles"]),
            "channel_id": self.config["channel_id"],
            "message_id": self.config["message_id"],
            "template": self.config["template"],
            "autorename_template": self.config["autorename_template"],
            "panel_overrides": {str(k): v for k, v in self.config["panel_overrides"].items()},
            "rename_overrides": {str(k): v for k, v in self.config["rename_overrides"].items()},
            "exclude_bots": self.config["exclude_bots"],
            "autorename": self.config["autorename"],
        }
        try:
            CONFIG_FILE.write_text(json.dumps(data, indent=2))
        except Exception as e:
            print("⚠️ Failed to save role config:", e)

    def load_role_config(self):
        if not CONFIG_FILE.exists(): return
        try:
            data = json.loads(CONFIG_FILE.read_text())
            self.config["roles"] = set(data.get("roles", []))
            self.config["channel_id"] = data.get("channel_id")
            self.config["message_id"] = data.get("message_id")
            self.config["template"] = data.get("template", self.config["template"])
            self.config["autorename_template"] = data.get("autorename_template", self.config["autorename_template"])
            self.config["panel_overrides"] = {int(k): v for k, v in data.get("panel_overrides", {}).items()}
            self.config["rename_overrides"] = {int(k): v for k, v in data.get("rename_overrides", {}).items()}
            self.config["exclude_bots"] = data.get("exclude_bots", True)
            self.config["autorename"] = data.get("autorename", False)
            print("✅ Role config loaded")
        except Exception as e:
            print("⚠️ Failed to load role config:", e)

    # --- Core Logic Helpers ---
    def base_role_name(self, name: str):
        return re.sub(r"\s*\(.*?\)$", "", name).strip()

    def sorted_roles(self, guild: discord.Guild):
        roles = [guild.get_role(rid) for rid in self.config["roles"]]
        return sorted([r for r in roles if r], key=lambda r: r.position, reverse=True)

    def resolve_role_exact(self, guild: discord.Guild, raw: str):
        raw = raw.strip()
        if raw.isdigit(): return guild.get_role(int(raw))
        if raw.startswith("<@&") and raw.endswith(">"): return guild.get_role(int(raw[3:-1]))
        for r in guild.roles:
            if r.name.lower() == raw.lower(): return r
        return None

    def effective_panel_template(self, role_id: int):
        return self.config["rename_overrides"].get(
            role_id, self.config["panel_overrides"].get(role_id, self.config["template"])
        )

    def compute_highest_counts(self, guild: discord.Guild):
        counts = {}
        counted = set()
        for role in self.sorted_roles(guild):
            counts[role.id] = 0
            for m in role.members:
                if self.config["exclude_bots"] and m.bot: continue
                if m.id in counted: continue
                counts[role.id] += 1
                counted.add(m.id)
        return counts

    def build_role_embed(self, guild: discord.Guild):
        counts = self.compute_highest_counts(guild)
        total = len([m for m in guild.members if not (self.config["exclude_bots"] and m.bot)])

        embed = discord.Embed(title="Role Statistics", color=0x2B2D31)
        for role in self.sorted_roles(guild):
            owncount = len([m for m in role.members if not (self.config["exclude_bots"] and m.bot)])
            percent = round((owncount / total) * 100, 1) if total else 0

            template = self.effective_panel_template(role.id)
            line = template.format(role=self.base_role_name(role.name), count=counts.get(role.id, 0), owncount=owncount, percent=percent, id=role.id, position=role.position)
            embed.add_field(name="\u200b", value=line, inline=False)
        embed.set_footer(text="Updates every 5 minutes")
        return embed

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[RoleCounter imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    async def autorename_roles(self, guild: discord.Guild, preview=False):
        counts = self.compute_highest_counts(guild)
        total = len([m for m in guild.members if not (self.config["exclude_bots"] and m.bot)])
        results = []

        for role in self.sorted_roles(guild):
            owncount = len([m for m in role.members if not (self.config["exclude_bots"] and m.bot)])
            percent = round((owncount / total) * 100, 1) if total else 0
            template = self.config["rename_overrides"].get(role.id, self.config["autorename_template"])

            try:
                new_name = template.format(role=self.base_role_name(role.name), count=counts.get(role.id, 0), owncount=owncount, percent=percent, id=role.id, position=role.position)
            except KeyError as e:
                if preview: results.append((role.name, f"[TEMPLATE ERROR: missing {{{str(e).strip()}}}]"))
                continue

            if preview:
                results.append((role.name, new_name))
            else:
                if role.name != new_name:
                    try: await role.edit(name=new_name, reason="Role rename update")
                    except Exception: pass
        return results

    # --- Background Loops ---
    @tasks.loop(minutes=5)
    async def role_counter_updater(self):
        if not self.config["channel_id"] or not self.config["message_id"]: return
        for guild in self.bot.guilds:
            channel = guild.get_channel(self.config["channel_id"])
            if not channel: continue
            try:
                msg = await channel.fetch_message(self.config["message_id"])
                embed = self.build_role_embed(guild)
                if hasattr(self.bot, 'imaging'):
                    try:
                        fields_list = [(f.name, f.value) for f in embed.fields] if embed.fields else []
                        b = await self.bot.imaging.render("general",
                            card_type="stats", title="Role Statistics",
                            description="Live role member counts",
                            fields=fields_list,
                            footer="Updates every 5 minutes")
                        f = self.bot.imaging.make_file(b, "rolecounter.png")
                        await msg.delete()
                        await channel.send(file=f)
                        continue
                    except Exception:
                        pass
                await msg.edit(embed=embed)
            except Exception: pass

    @tasks.loop(hours=24)
    async def daily_role_rename(self):
        if not self.config["autorename"]: return
        for guild in self.bot.guilds:
            await self.autorename_roles(guild)

    @role_counter_updater.before_loop
    @daily_role_rename.before_loop
    async def before_tasks(self):
        await self.bot.wait_until_ready()

    # --- Prefix Commands ---
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def roleadd(self, ctx, *, role_name: str):
        role = self.resolve_role_exact(ctx.guild, role_name)
        if not role: return await ctx.send("Role not found.")
        self.config["roles"].add(role.id)
        self.save_role_config()
        await ctx.send(f"Added `{role.name}`.")

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def roleremove(self, ctx, *, role_name: str):
        role = self.resolve_role_exact(ctx.guild, role_name)
        if not role: return await ctx.send("Role not found.")
        self.config["roles"].discard(role.id)
        self.config["panel_overrides"].pop(role.id, None)
        self.config["rename_overrides"].pop(role.id, None)
        self.save_role_config()
        await ctx.send(f"Removed `{role.name}`.")

    @commands.command()
    async def rolelists(self, ctx):
        roles = self.sorted_roles(ctx.guild)
        if not roles: return await ctx.send("No roles configured.")
        await ctx.send("**Tracked roles:**\n" + "\n".join(f"- {r.name}" for r in roles))

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def rolesetchannel(self, ctx, channel: discord.TextChannel):
        embed = self.build_role_embed(ctx.guild)
        if hasattr(self.bot, 'imaging'):
            try:
                fields_list = [(f.name, f.value) for f in embed.fields] if embed.fields else []
                b = await self.bot.imaging.render("general",
                    card_type="stats", title="Role Statistics",
                    description="Live role member counts",
                    fields=fields_list,
                    footer="Updates every 5 minutes")
                f = self.bot.imaging.make_file(b, "rolecounter.png")
                msg = await channel.send(file=f)
            except Exception:
                msg = await channel.send(embed=embed)
        else:
            msg = await channel.send(embed=embed)
        self.config["channel_id"] = channel.id
        self.config["message_id"] = msg.id
        self.save_role_config()
        await ctx.send("Role counter initialized.")

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def roleupdate(self, ctx):
        await self.autorename_roles(ctx.guild)
        await ctx.send("Roles updated immediately.")

    # --- Slash Commands ---
    @app_commands.command(name="roleadd", description="Add a role to the role counter")
    @app_commands.checks.has_permissions(administrator=True)
    async def s_roleadd(self, interaction: discord.Interaction, role: discord.Role):
        self.config["roles"].add(role.id)
        self.save_role_config()
        await interaction.response.send_message(f"Added `{role.name}`.", ephemeral=True)

    @app_commands.command(name="roleupdate", description="Force update role renaming immediately")
    @app_commands.checks.has_permissions(administrator=True)
    async def s_roleupdate(self, interaction: discord.Interaction):
        await self.autorename_roles(interaction.guild)
        await interaction.response.send_message("Roles updated immediately.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(RoleCounter(bot))
