import discord
from discord.ext import commands

RESTRICTED_CHANNEL = 1485685602929344603
STAFF_LOG_CHANNEL = 1488593451359408241
APPEAL_LINK = "https://discord.gg/tyEExt8WCk"

class AntiBot(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _send_card(self, target, fallback_embed, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                return await send_to.send(file=f)
            except Exception as exc:
                print(f"[AntiBot imaging] {exc}")
        return await send_to.send(embed=fallback_embed)

    async def send_appeal_dm(self, member, action, reason):
        """Helper to DM users the appeal link"""
        embed = discord.Embed(
            title="Moderation Action Taken",
            description=f"You have been **{action}** from the server.",
            color=discord.Color.red()
        )
        embed.add_field(name="Reason", value=reason)
        embed.add_field(name="Appeal", value=f"[Click here to appeal]({APPEAL_LINK})")
        try:
            await member.send(embed=embed)
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        if message.channel.id == RESTRICTED_CHANNEL:
            user = message.author
            reason = "Posted in restricted trap channel"

            await self.send_appeal_dm(user, "Banned", reason)

            try:
                await user.ban(reason=reason, delete_message_seconds=86400)

                staff_ch = self.bot.get_channel(STAFF_LOG_CHANNEL)
                if staff_ch:
                    fallback = discord.Embed(
                        title="Trap Triggered",
                        description=f"**User:** {user.mention} ({user.id})\n**Action:** Banned\n**Reason:** {reason}",
                        color=0xff0000
                    )
                    await self._send_card(
                        staff_ch, fallback,
                        card_type="alert",
                        alert_type="antibot",
                        title="Trap Triggered — Auto Ban",
                        description=f"User posted in restricted trap channel and was immediately banned.",
                        severity="critical",
                        user_name=str(user),
                        user_id=user.id,
                        fields=[
                            ("Action", "Banned"),
                            ("Reason", reason),
                            ("Channel", f"#{message.channel.name}"),
                        ],
                        user=user,
                        perpetrator=self.bot.user,
                    )

            except discord.Forbidden:
                print(f"Failed to ban {user}. Check role hierarchy!")
            except Exception as e:
                print(f"AntiBot Error: {e}")

async def setup(bot):
    await bot.add_cog(AntiBot(bot))
