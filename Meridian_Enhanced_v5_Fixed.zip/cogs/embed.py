import discord
from discord.ext import commands
from datetime import datetime, timezone
import json


def err(text):
    return discord.Embed(description=f"❌ {text}", color=0xED4245)


def ok(text):
    return discord.Embed(description=f"✅ {text}", color=0x57F287)


def build_embed(item: dict) -> discord.Embed:
    """Build a discord.Embed from a JSON dict, supporting all common fields."""
    color_raw = item.get("color", "#2b2d31")
    try:
        color = discord.Color.from_str(color_raw)
    except Exception:
        color = discord.Color.dark_theme()

    timestamp = None
    if "timestamp" in item:
        ts = item["timestamp"]
        if ts == "now":
            timestamp = datetime.now(timezone.utc)
        else:
            try:
                timestamp = datetime.fromisoformat(ts)
            except Exception:
                pass

    embed = discord.Embed(
        title=item.get("title"),
        description=item.get("description"),
        color=color,
        url=item.get("url"),
        timestamp=timestamp,
    )

    if "author" in item:
        a = item["author"]
        embed.set_author(
            name=a.get("name", ""),
            url=a.get("url"),
            icon_url=a.get("icon_url"),
        )

    if "thumbnail" in item:
        embed.set_thumbnail(url=item["thumbnail"])

    if "image" in item:
        embed.set_image(url=item["image"])

    if "footer" in item:
        f = item["footer"]
        embed.set_footer(text=f.get("text", ""), icon_url=f.get("icon_url"))

    for field in item.get("fields", []):
        embed.add_field(
            name=field.get("name", "\u200b"),
            value=field.get("value", "\u200b"),
            inline=field.get("inline", False),
        )

    return embed


class EmbedManager(commands.Cog):
    """Embed builder and announcement tools."""

    def __init__(self, bot):
        self.bot = bot

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[Embed imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    @commands.command(name="embed")
    @commands.has_permissions(manage_messages=True)
    async def make_embed(self, ctx, *, json_data: str):
        """Build and send an embed from JSON. Supports title, description, color, author,
        footer, timestamp, image, thumbnail, fields, and url."""
        clean = json_data.strip("`").removeprefix("json\n").removeprefix("\n")
        try:
            data = json.loads(clean)
            if isinstance(data, dict):
                data = [data]
            embeds = [build_embed(item) for item in data]
            await ctx.send(embeds=embeds)
            await ctx.message.delete()
        except json.JSONDecodeError as e:
            await ctx.send(embed=err(f"Invalid JSON: `{e}`"))
        except Exception as e:
            await ctx.send(embed=err(f"Something went wrong: `{e}`"))

    @commands.command(name="embed-edit")
    @commands.has_permissions(manage_messages=True)
    async def embed_edit(self, ctx, message_id: int, *, json_data: str):
        """Edit an existing bot-sent embed by message ID in this channel."""
        try:
            target_msg = await ctx.channel.fetch_message(message_id)
        except discord.NotFound:
            return await ctx.send(embed=err("Message not found in this channel."))
        if target_msg.author != ctx.guild.me:
            return await ctx.send(embed=err("I can only edit my own messages."))
        if not target_msg.embeds:
            return await ctx.send(embed=err("That message has no embeds to edit."))
        clean = json_data.strip("`").removeprefix("json\n").removeprefix("\n")
        try:
            data = json.loads(clean)
            if isinstance(data, dict):
                data = [data]
            embeds = [build_embed(item) for item in data]
            await target_msg.edit(embeds=embeds)
            await ctx.message.delete()
            await ctx.send(embed=ok("Embed updated."), delete_after=4)
        except json.JSONDecodeError as e:
            await ctx.send(embed=err(f"Invalid JSON: `{e}`"))
        except Exception as e:
            await ctx.send(embed=err(f"Something went wrong: `{e}`"))

    @commands.command(name="announce")
    @commands.has_permissions(manage_messages=True)
    async def announce(self, ctx, channel: discord.TextChannel = None, *, message: str):
        """Send a styled announcement to a channel.
        Usage: !announce #channel Your announcement text"""
        channel = channel or ctx.channel
        embed = discord.Embed(
            title="📢 Announcement",
            description=message,
            color=0x5865F2,
            timestamp=datetime.now(timezone.utc),
        )
        embed.set_author(name=ctx.guild.name, icon_url=ctx.guild.icon.url if ctx.guild.icon else None)
        embed.set_footer(text=f"Posted by {ctx.author.display_name}")
        await self._send_card(
            channel, embed,
            card_type="info",
            title="📢 Announcement",
            description=message,
            footer=f"Posted by {ctx.author.display_name}",
        )
        if channel != ctx.channel:
            await ctx.message.delete()

    @commands.command(name="say")
    @commands.has_permissions(manage_messages=True)
    async def say(self, ctx, channel: discord.TextChannel = None, *, message: str):
        """Relay a plain-text message to a channel as the bot.
        Usage: !say #channel Your message"""
        channel = channel or ctx.channel
        await channel.send(message)
        try:
            await ctx.message.delete()
        except discord.Forbidden:
            pass


async def setup(bot):
    await bot.add_cog(EmbedManager(bot))
