import discord
from discord.ext import commands
import random
import json
import os
import asyncio
import aiohttp
import time
import html
from io import BytesIO
from PIL import Image
from datetime import datetime

MEMORY_FILE = "channel_memory.json"
MARRIAGE_FILE = "marriages.json"
ECONOMY_FILE = "economy.json"
PREFIX = "m"


# ─── RPS view ─────────────────────────────────────────────────────────────────


class RPSView(discord.ui.View):
    CHOICES = {"🪨": "rock", "📄": "paper", "✂️": "scissors"}
    BEATS = {"rock": "scissors", "paper": "rock", "scissors": "paper"}

    def __init__(self, challenger: discord.Member, opponent: discord.Member | None):
        super().__init__(timeout=60)
        self.challenger = challenger
        self.opponent = opponent
        self.challenger_choice = None
        self.opponent_choice = None

    def _resolve(self) -> str:
        c, o = self.challenger_choice, self.opponent_choice
        if c == o:
            return "tie"
        if self.BEATS[c] == o:
            return "challenger"
        return "opponent"

    async def _check_and_finish(self, interaction: discord.Interaction):
        if self.challenger_choice and self.opponent_choice:
            result = self._resolve()
            c_emoji = [k for k, v in self.CHOICES.items() if v == self.challenger_choice][0]
            o_emoji = [k for k, v in self.CHOICES.items() if v == self.opponent_choice][0]
            if result == "tie":
                desc = f"**Tie!** Both chose {c_emoji}"
            elif result == "challenger":
                desc = f"**{self.challenger.display_name} wins!** {c_emoji} beats {o_emoji}"
            else:
                opp = self.opponent or interaction.user
                desc = f"**{opp.display_name} wins!** {o_emoji} beats {c_emoji}"
            for child in self.children:
                child.disabled = True
            embed = discord.Embed(description=desc, color=0x57F287 if result != "tie" else 0xFFA500)
            await interaction.response.edit_message(embed=embed, view=self)
            self.stop()
        else:
            await interaction.response.defer()

    @discord.ui.button(emoji="🪨", label="Rock", style=discord.ButtonStyle.secondary)
    async def rock(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._handle(interaction, "rock")

    @discord.ui.button(emoji="📄", label="Paper", style=discord.ButtonStyle.secondary)
    async def paper(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._handle(interaction, "paper")

    @discord.ui.button(emoji="✂️", label="Scissors", style=discord.ButtonStyle.secondary)
    async def scissors(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._handle(interaction, "scissors")

    async def _handle(self, interaction: discord.Interaction, choice: str):
        user = interaction.user
        is_vs_bot = self.opponent is None

        if is_vs_bot:
            if user != self.challenger:
                return await interaction.response.send_message("This isn't your game!", ephemeral=True)
            self.challenger_choice = choice
            self.opponent_choice = random.choice(list(self.BEATS.keys()))
        else:
            if user == self.challenger:
                if self.challenger_choice:
                    return await interaction.response.send_message("You already chose!", ephemeral=True)
                self.challenger_choice = choice
            elif user == self.opponent:
                if self.opponent_choice:
                    return await interaction.response.send_message("You already chose!", ephemeral=True)
                self.opponent_choice = choice
            else:
                return await interaction.response.send_message("You're not in this game!", ephemeral=True)

        await self._check_and_finish(interaction)


# ─── Proposal view ─────────────────────────────────────────────────────────────


class ProposeView(discord.ui.View):
    def __init__(self, proposer, target):
        super().__init__(timeout=60)
        self.proposer = proposer
        self.target = target
        self.value = None

    @discord.ui.button(label="Accept", style=discord.ButtonStyle.success, emoji="💍")
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.target:
            return await interaction.response.send_message("They aren't proposing to you!", ephemeral=True)
        self.value = True
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()

    @discord.ui.button(label="Decline", style=discord.ButtonStyle.danger, emoji="💔")
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.target:
            return await interaction.response.send_message("Mind your own business!", ephemeral=True)
        self.value = False
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()


# ─── Trivia view ───────────────────────────────────────────────────────────────


class TriviaView(discord.ui.View):
    def __init__(self, question: str, correct: str, wrong: list[str], ctx):
        super().__init__(timeout=30)
        self.ctx = ctx
        self.correct = correct
        self.answered = False
        answers = [correct] + wrong
        random.shuffle(answers)
        for answer in answers:
            self.add_item(TriviaButton(answer, answer == correct, self))


class TriviaButton(discord.ui.Button):
    def __init__(self, label: str, is_correct: bool, view_ref):
        super().__init__(label=label[:80], style=discord.ButtonStyle.secondary)
        self.is_correct = is_correct
        self.view_ref = view_ref

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.view_ref.ctx.author:
            return await interaction.response.send_message("This isn't your trivia!", ephemeral=True)
        if self.view_ref.answered:
            return await interaction.response.defer()
        self.view_ref.answered = True
        for child in self.view_ref.children:
            child.disabled = True
            if isinstance(child, TriviaButton):
                if child.is_correct:
                    child.style = discord.ButtonStyle.success
                elif child == self:
                    child.style = discord.ButtonStyle.danger
        if self.is_correct:
            embed = discord.Embed(description="✅ **Correct!** Well done.", color=0x57F287)
        else:
            embed = discord.Embed(description=f"❌ **Wrong!** The correct answer was **{self.view_ref.correct}**.", color=0xED4245)
        await interaction.response.edit_message(embed=embed, view=self.view_ref)
        self.view_ref.stop()


# ─── Cog ───────────────────────────────────────────────────────────────────────


class Fun(commands.Cog):
    """Fun commands — games, roleplay, and silliness."""

    def __init__(self, bot):
        self.bot = bot
        self.channel_memory = {}
        self.is_scanning = set()
        self.marriages = {}
        self.economy = {}
        self.load_memory()
        self.load_marriages()
        self.load_economy()

    def save_memory(self):
        try:
            with open(MEMORY_FILE, "w") as f:
                json.dump({str(k): list(v) for k, v in self.channel_memory.items()}, f, indent=4)
        except Exception as e:
            print(f"Error saving memory: {e}")

    def load_memory(self):
        if os.path.exists(MEMORY_FILE):
            try:
                with open(MEMORY_FILE, "r") as f:
                    data = json.load(f)
                    self.channel_memory = {int(k): set(v) for k, v in data.items()}
            except Exception:
                self.channel_memory = {}

    def save_marriages(self):
        with open(MARRIAGE_FILE, "w") as f:
            json.dump(self.marriages, f, indent=4)

    def load_marriages(self):
        if not os.path.exists(MARRIAGE_FILE):
            self.save_marriages()
        else:
            with open(MARRIAGE_FILE, "r") as f:
                self.marriages = json.load(f)

    def save_economy(self):
        with open(ECONOMY_FILE, "w") as f:
            json.dump(self.economy, f, indent=4)

    def load_economy(self):
        if os.path.exists(ECONOMY_FILE):
            with open(ECONOMY_FILE, "r") as f:
                self.economy = json.load(f)

    def get_balance(self, user_id):
        return self.economy.get(str(user_id), 0)

    def update_balance(self, user_id, amount):
        uid = str(user_id)
        self.economy[uid] = self.economy.get(uid, 0) + amount
        self.save_economy()

    async def fetch_rp_gif(self, action: str):
        url = f"https://nekos.best/api/v2/{action}"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return data["results"][0]["url"]
        except Exception:
            pass
        return "https://media.giphy.com/media/kFgzrTt79Bg5LCpXg/giphy.gif"

    async def _send_card(self, target, fallback_embed, reply_to=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        if hasattr(self.bot, 'imaging'):
            try:
                template = kwargs.pop("_template", "general")
                return await self.bot.imaging.render_and_send(
                    ctx_or_channel=reply_to or send_to,
                    template_name=template,
                    filename=f"{kwargs.get('card_type', template)}.png",
                    reply=(reply_to is not None),
                    embed_title=fallback_embed.title if fallback_embed else None,
                    embed_description=fallback_embed.description if fallback_embed else None,
                    embed_color=fallback_embed.color.value if fallback_embed else 0x5865F2,
                    **kwargs
                )
            except Exception as exc:
                print(f"[Fun imaging] {exc}")
        if reply_to:
            return await reply_to.reply(embed=fallback_embed)
        return await send_to.send(embed=fallback_embed)

    # ─── Games Sub-Cog ──────────────────────────────────────────────

    @commands.group(name="game", invoke_without_command=True)
    async def game_group(self, ctx):
        """Fun games to play with friends or the bot."""
        await ctx.send_help(ctx.command)

    @game_group.command(name="rps")
    async def rps(self, ctx, target: discord.Member = None):
        """Play Rock Paper Scissors."""
        view = RPSView(ctx.author, target)
        target_str = target.mention if target else "the bot"
        embed = discord.Embed(title="Rock Paper Scissors", description=f"{ctx.author.mention} vs {target_str}!\nChoose your weapon below.", color=0x5865F2)
        await ctx.send(embed=embed, view=view)

    @game_group.command(name="trivia")
    async def trivia(self, ctx, category: str = None):
        """Test your knowledge with trivia questions."""
        url = "https://opentdb.com/api.php?amount=1&type=multiple"
        if category: url += f"&category={category}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                data = await resp.json()
        if not data["results"]:
            return await ctx.send("No questions found for that category.")
        q = data["results"][0]
        question = html.unescape(q["question"])
        correct = html.unescape(q["correct_answer"])
        wrong = [html.unescape(a) for a in q["incorrect_answers"]]
        embed = discord.Embed(title=f"Trivia: {q['category']}", description=f"**{question}**\n\nDifficulty: {q['difficulty'].title()}", color=0x5865F2)
        view = TriviaView(question, correct, wrong, ctx)
        await ctx.send(embed=embed, view=view)

    @game_group.command(name="coinflip", aliases=["cf"])
    async def coinflip(self, ctx):
        """Flip a coin."""
        result = random.choice(["Heads", "Tails"])
        embed = discord.Embed(description=f"🪙 The coin landed on: **{result}**!", color=0xFFA500)
        await ctx.send(embed=embed)

    @game_group.command(name="roll")
    async def roll(self, ctx, dice: str = "1d6"):
        """Roll some dice (e.g. 2d20)."""
        try:
            count, sides = map(int, dice.lower().split('d'))
            if count > 100 or sides > 1000: return await ctx.send("Too many dice/sides!")
            rolls = [random.randint(1, sides) for _ in range(count)]
            embed = discord.Embed(title=f"🎲 Rolling {dice}", description=f"Rolls: {', '.join(map(str, rolls))}\nTotal: **{sum(rolls)}**", color=0x5865F2)
            await ctx.send(embed=embed)
        except Exception:
            await ctx.send("Invalid format. Use `NdM` (e.g. 1d6).")

    # ─── Economy Sub-Cog ──────────────────────────────────────────────

    @commands.group(name="eco", aliases=["economy"], invoke_without_command=True)
    async def eco_group(self, ctx):
        """Meridian economy system."""
        await ctx.send_help(ctx.command)

    @eco_group.command(name="balance", aliases=["bal"])
    async def balance(self, ctx, member: discord.Member = None):
        """Check your or someone else's balance."""
        member = member or ctx.author
        bal = self.get_balance(member.id)
        embed = discord.Embed(title=f"{member.display_name}'s Balance", description=f"💰 **{bal:,}** credits", color=0x57F287)
        await ctx.send(embed=embed)

    @eco_group.command(name="beg")
    @commands.cooldown(1, 30, commands.BucketType.user)
    async def beg(self, ctx):
        """Beg for some credits."""
        amount = random.randint(10, 100)
        self.update_balance(ctx.author.id, amount)
        await ctx.send(f"Fine, take **{amount}** credits. Don't spend it all in one place!")

    @eco_group.command(name="daily")
    @commands.cooldown(1, 86400, commands.BucketType.user)
    async def daily(self, ctx):
        """Claim your daily credits."""
        amount = 500
        self.update_balance(ctx.author.id, amount)
        await ctx.send(f"💰 You claimed your daily **{amount}** credits!")

    @eco_group.command(name="pay")
    async def pay(self, ctx, target: discord.Member, amount: int):
        """Give some of your credits to someone else."""
        if amount <= 0: return await ctx.send("Amount must be positive.")
        if self.get_balance(ctx.author.id) < amount: return await ctx.send("You don't have enough credits!")
        self.update_balance(ctx.author.id, -amount)
        self.update_balance(target.id, amount)
        await ctx.send(f"✅ Transferred **{amount}** credits to {target.mention}.")

    # ─── Roleplay Sub-Cog ──────────────────────────────────────────────

    @commands.command()
    async def hug(self, ctx, target: discord.Member):
        """Give someone a warm hug."""
        gif = await self.fetch_rp_gif("hug")
        embed = discord.Embed(description=f"{ctx.author.mention} hugs {target.mention}! 🤗", color=0xFF69B4)
        embed.set_image(url=gif)
        await ctx.send(embed=embed)

    @commands.command()
    async def slap(self, ctx, target: discord.Member):
        """Slap someone!"""
        gif = await self.fetch_rp_gif("slap")
        embed = discord.Embed(description=f"{ctx.author.mention} slaps {target.mention}! Ouch.", color=0xFF0000)
        embed.set_image(url=gif)
        await ctx.send(embed=embed)

    @commands.command()
    async def kiss(self, ctx, target: discord.Member):
        """Give someone a kiss."""
        gif = await self.fetch_rp_gif("kiss")
        embed = discord.Embed(description=f"{ctx.author.mention} kisses {target.mention}! 💋", color=0xFF1493)
        embed.set_image(url=gif)
        await ctx.send(embed=embed)

    @commands.command()
    async def pat(self, ctx, target: discord.Member):
        """Pat someone on the head."""
        gif = await self.fetch_rp_gif("pat")
        embed = discord.Embed(description=f"{ctx.author.mention} pats {target.mention}! Good job.", color=0xFFD700)
        embed.set_image(url=gif)
        await ctx.send(embed=embed)

    # ─── Silly & Utility Fun ──────────────────────────────────────────────

    @commands.command(name="8ball")
    async def eightball(self, ctx, *, question: str):
        """Ask the magic 8-ball a question."""
        responses = [
            "It is certain.", "It is decidedly so.", "Without a doubt.", "Yes - definitely.",
            "You may rely on it.", "As I see it, yes.", "Most likely.", "Outlook good.",
            "Yes.", "Signs point to yes.", "Reply hazy, try again.", "Ask again later.",
            "Better not tell you now.", "Cannot predict now.", "Concentrate and ask again.",
            "Don't count on it.", "My reply is no.", "My sources say no.", "Outlook not so good.",
            "Very doubtful."
        ]
        embed = discord.Embed(title="🎱 Magic 8-Ball", description=f"**Question:** {question}\n**Answer:** {random.choice(responses)}", color=0x2F3136)
        await ctx.send(embed=embed)

    @commands.command()
    async def meme(self, ctx):
        """Get a random meme from Reddit."""
        async with aiohttp.ClientSession() as session:
            async with session.get("https://meme-api.com/gimme") as resp:
                data = await resp.json()
        embed = discord.Embed(title=data["title"], url=data["postLink"], color=0x5865F2)
        embed.set_image(url=data["url"])
        embed.set_footer(text=f"👍 {data['ups']} | r/{data['subreddit']}")
        await ctx.send(embed=embed)

    @commands.command()
    async def ship(self, ctx, user1: discord.Member, user2: discord.Member = None):
        """Check the compatibility between two users."""
        user2 = user2 or ctx.author
        percent = random.randint(0, 100)
        bar = "█" * (percent // 10) + "░" * (10 - (percent // 10))
        embed = discord.Embed(title="❤️ Matchmaking", description=f"**{user1.display_name}** & **{user2.display_name}**\n\n**{percent}%** compatibility\n`[{bar}]`", color=0xFF1493)
        await ctx.send(embed=embed)

    @commands.command(name="marry")
    async def marry(self, ctx, target: discord.Member = None):
        """Propose marriage to another user."""
        user_id = str(ctx.author.id)
        if not target:
            if user_id in self.marriages:
                return await ctx.send(f"You are married to <@{self.marriages[user_id]}>.")
            return await ctx.send("You are single. Tag someone to propose!")
        target_id = str(target.id)
        if target == ctx.author:
            return await ctx.send("You can't marry yourself.")
        if target.bot:
            return await ctx.send("I'm flattered, but bots can't marry.")
        if user_id in self.marriages:
            return await ctx.send("You're already married. Use `!divorce` first.")
        if target_id in self.marriages:
            return await ctx.send(f"{target.display_name} is already married.")
        view = ProposeView(ctx.author, target)
        msg = await ctx.send(f"{target.mention}, **{ctx.author.display_name}** is proposing! Do you accept?", view=view)
        await view.wait()
        if view.value is None:
            await msg.edit(content=f"The proposal expired. {target.display_name} left you on read.", view=None)
        elif view.value:
            self.marriages[user_id] = target_id
            self.marriages[target_id] = user_id
            self.save_marriages()
            await msg.edit(content=f"💍 {ctx.author.mention} and {target.mention} are now married!", view=None)
        else:
            await msg.edit(content=f"💔 {target.display_name} declined the proposal.", view=None)

    @commands.command(name="divorce")
    async def divorce(self, ctx):
        """Divorce your current partner."""
        user_id = str(ctx.author.id)
        if user_id not in self.marriages:
            return await ctx.send("You aren't married.")
        partner_id = self.marriages[user_id]
        del self.marriages[user_id]
        if partner_id in self.marriages:
            del self.marriages[partner_id]
        self.save_marriages()
        await ctx.send(f"💔 You and <@{partner_id}> are now divorced.")

async def setup(bot):
    await bot.add_cog(Fun(bot))
