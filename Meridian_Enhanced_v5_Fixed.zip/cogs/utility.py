import discord
from discord.ext import commands
import aiohttp
import asyncio
import re
import time
from datetime import timedelta, datetime
from io import BytesIO
from PIL import Image, ImageDraw

CHECK_EMOJI = "<:check:1485825673158332567>"


def check_embed(text, color=discord.Color.orange()):
    return discord.Embed(description=f"{CHECK_EMOJI} {text}", color=color)


def parse_time(time_str):
    time_regex = re.compile(r"(\d+)([smhd])")
    match = time_regex.match(time_str.lower())
    if not match:
        return None
    val, unit = int(match.group(1)), match.group(2)
    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    return timedelta(seconds=val * multipliers[unit])


def fmt_uptime(delta: timedelta) -> str:
    total = int(delta.total_seconds())
    d, r = divmod(total, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    parts = []
    if d: parts.append(f"{d}d")
    if h: parts.append(f"{h}h")
    if m: parts.append(f"{m}m")
    parts.append(f"{s}s")
    return " ".join(parts)


class Utility(commands.Cog):
    """Server utilities, stats, and quality-of-life tools."""

    def __init__(self, bot):
        self.bot = bot

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        
        if hasattr(self.bot, 'imaging'):
            try:
                template = kwargs.pop("_template", "general")
                return await self.bot.imaging.render_and_send(
                    ctx_or_channel=reply_to or send_to,
                    template_name=template,
                    filename=f"{kwargs.get('card_type', template)}.png",
                    reply=(reply_to is not None),
                    embed_title=fallback_embed.title if fallback_embed else f"Utility: {template.replace('_', ' ').title()}",
                    embed_description=fallback_embed.description if fallback_embed else None,
                    embed_color=fallback_embed.color.value if fallback_embed else 0x5865F2,
                    embed_fields=[{"name": f.name, "value": f.value, "inline": f.inline} for f in fallback_embed.fields] if fallback_embed else None,
                    **kwargs
                )
            except Exception as exc:
                print(f"[Utility imaging] {exc}")
        
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    # ─── Lookup Sub-Cog ───────────────────────────────────────────────────

    @commands.group(name="lookup", invoke_without_command=True)
    async def lookup_group(self, ctx):
        """Commands for looking up Discord information."""
        await ctx.send_help(ctx.command)

    @lookup_group.command(name="user", aliases=["userinf"])
    async def user_info(self, ctx, member: discord.Member = None):
        """Detailed stats about a user."""
        member = member or ctx.author
        roles = [r.mention for r in reversed(member.roles) if r.name != "@everyone"]
        embed = discord.Embed(title=f"{CHECK_EMOJI} User Information", color=member.color or discord.Color.orange())
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="User", value=str(member), inline=True)
        embed.add_field(name="ID", value=member.id, inline=True)
        embed.add_field(name="Joined Server", value=f"<t:{int(member.joined_at.timestamp())}:D>", inline=True)
        embed.add_field(name="Joined Discord", value=f"<t:{int(member.created_at.timestamp())}:D>", inline=True)
        embed.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles[:10]) + ("..." if len(roles) > 10 else ""), inline=False)
        
        ui_fields = [
            ("User", str(member)),
            ("ID", str(member.id)),
            ("Joined Server", member.joined_at.strftime("%Y-%m-%d")),
            ("Joined Discord", member.created_at.strftime("%Y-%m-%d")),
            ("Top Role", member.top_role.name),
        ]
        await self._send_card(ctx, embed, _template="userinfo", user=member, fields=ui_fields)

    @lookup_group.command(name="server", aliases=["serverinf"])
    async def server_info(self, ctx):
        """Detailed stats about the server."""
        guild = ctx.guild
        embed = discord.Embed(title=f"{CHECK_EMOJI} {guild.name} Information", color=discord.Color.orange())
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Owner", value=guild.owner.mention, inline=True)
        embed.add_field(name="Created On", value=f"<t:{int(guild.created_at.timestamp())}:D>", inline=True)
        embed.add_field(name="Members", value=f"Total: {guild.member_count}", inline=True)
        embed.add_field(name="Boosts", value=f"Level {guild.premium_tier} ({guild.premium_subscription_count} boosts)", inline=True)
        embed.add_field(name="Roles", value=str(len(guild.roles)), inline=True)
        embed.add_field(name="Emojis", value=str(len(guild.emojis)), inline=True)
        si_fields = [
            ("Owner", str(guild.owner)),
            ("Members", str(guild.member_count)),
            ("Boosts", f"Level {guild.premium_tier} ({guild.premium_subscription_count})"),
            ("Roles", str(len(guild.roles))),
            ("Emojis", str(len(guild.emojis))),
        ]
        await self._send_card(ctx, embed, _template="serverinfo", guild=guild, fields=si_fields)

    @lookup_group.command(name="avatar", aliases=["av"])
    async def avatar(self, ctx, member: discord.Member = None):
        """Get a high-res link to a user's profile picture."""
        member = member or ctx.author
        embed = discord.Embed(title=f"{member.name}'s Avatar", color=member.color or discord.Color.orange())
        embed.set_image(url=member.display_avatar.url)
        await ctx.send(embed=embed)

    @lookup_group.command(name="banner")
    async def banner(self, ctx, member: discord.Member = None):
        """Get a user's profile banner."""
        member = member or ctx.author
        user = await self.bot.fetch_user(member.id)
        if not user.banner:
            return await ctx.send(embed=check_embed(f"{member.name} doesn't have a banner set.", discord.Color.red()))
        embed = discord.Embed(title=f"{member.name}'s Banner", color=member.color or discord.Color.orange())
        embed.set_image(url=user.banner.url)
        await ctx.send(embed=embed)

    @lookup_group.command(name="snowflake")
    async def snowflake(self, ctx, discord_id: int):
        """Decode a Discord ID to see when it was created."""
        try:
            obj = discord.Object(id=discord_id)
            timestamp = int(obj.created_at.timestamp())
            await ctx.send(embed=check_embed(f"ID `{discord_id}` was created on <t:{timestamp}:F> (<t:{timestamp}:R>)."))
        except Exception:
            await ctx.send(embed=check_embed("That doesn't look like a valid Discord ID.", discord.Color.red()))

    # ─── Tool Sub-Cog ───────────────────────────────────────────────────

    @commands.group(name="tool", invoke_without_command=True)
    async def tool_group(self, ctx):
        """Useful tools for server management and personal use."""
        await ctx.send_help(ctx.command)

    @tool_group.command(name="remindme")
    async def remindme(self, ctx, time_str: str, *, reminder: str = "Something!"):
        """Set a reminder (e.g. !remindme 10m check logs)."""
        duration = parse_time(time_str)
        if not duration:
            return await ctx.send(embed=check_embed("Invalid time. Use things like `10m`, `2h`, `1d`.", discord.Color.red()))
        timestamp = int((discord.utils.utcnow() + duration).timestamp())
        await ctx.send(embed=check_embed(f"Got it. I'll remind you about **'{reminder}'** <t:{timestamp}:R>."))
        await asyncio.sleep(duration.total_seconds())
        try:
            await ctx.author.send(embed=check_embed(f"**Reminder:** {reminder}"))
        except discord.Forbidden:
            pass

    @tool_group.command(name="poll")
    async def poll(self, ctx, question: str, *options):
        """Create a simple poll with reactions."""
        if len(options) > 10: return await ctx.send("Max 10 options.")
        if len(options) < 2: return await ctx.send("At least 2 options required.")
        emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        desc = "\n".join([f"{emojis[i]} {options[i]}" for i in range(len(options))])
        embed = discord.Embed(title=f"📊 {question}", description=desc, color=0x5865F2)
        msg = await ctx.send(embed=embed)
        for i in range(len(options)): await msg.add_reaction(emojis[i])

    @tool_group.command(name="calc")
    async def calculate(self, ctx, *, expression: str):
        """Evaluate a mathematical expression."""
        # Note: This is a basic implementation. For production, use a safe evaluator.
        try:
            # Strip unsafe characters
            safe_expr = re.sub(r'[^0-9+\-*/().\s]', '', expression)
            result = eval(safe_expr, {"__builtins__": None}, {})
            await ctx.send(f"🔢 Result: **{result}**")
        except Exception:
            await ctx.send("❌ Invalid expression.")

    @tool_group.command(name="urban")
    async def urban(self, ctx, *, term: str):
        """Search the Urban Dictionary."""
        url = f"http://api.urbandictionary.com/v0/define?term={term}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                data = await resp.json()
        if not data["list"]:
            return await ctx.send(embed=check_embed(f"No results found for `{term}`.", discord.Color.red()))
        result = data["list"][0]
        definition = result["definition"].replace("[", "").replace("]", "")
        example = result["example"].replace("[", "").replace("]", "")
        if len(definition) > 2000: definition = definition[:2000] + "..."
        embed = discord.Embed(title=f"Urban Dictionary: {term}", description=definition, color=discord.Color.orange())
        if example: embed.add_field(name="Example", value=example[:1024], inline=False)
        embed.set_footer(text=f"👍 {result['thumbs_up']} | 👎 {result['thumbs_down']}")
        await ctx.send(embed=embed)

    # ─── Statistics Sub-Cog ──────────────────────────────────────────────

    @commands.group(name="stats", invoke_without_command=True)
    async def stats_group(self, ctx):
        """Server and member statistics."""
        await ctx.send_help(ctx.command)

    @stats_group.command(name="channels")
    async def channelstats(self, ctx):
        """Breakdown of server channels."""
        guild = ctx.guild
        desc = (
            f"**Categories:** {len(guild.categories)}\n"
            f"**Text Channels:** {len(guild.text_channels)}\n"
            f"**Voice Channels:** {len(guild.voice_channels)}\n"
            f"**Forum Channels:** {len(guild.forum_channels)}\n\n"
            f"**Total:** {len(guild.text_channels) + len(guild.voice_channels) + len(guild.forum_channels)} channels"
        )
        embed = discord.Embed(title=f"Channel Stats for {guild.name}", description=desc, color=discord.Color.orange())
        await ctx.send(embed=embed)

    @stats_group.command(name="boosters")
    async def boosters(self, ctx):
        """Lists everyone currently boosting the server."""
        boosters = ctx.guild.premium_subscribers
        if not boosters:
            return await ctx.send(embed=check_embed("No one is boosting the server right now.", discord.Color.red()))
        booster_list = "\n".join([f"💎 {m.mention} — Since <t:{int(m.premium_since.timestamp())}:R>" for m in boosters])
        embed = discord.Embed(title=f"Server Boosters ({len(boosters)})", description=booster_list, color=0xEB459E)
        await ctx.send(embed=embed)

    @stats_group.command(name="roles")
    async def rolels(self, ctx):
        """Lists all roles and their member counts."""
        roles = [r for r in reversed(ctx.guild.roles) if r.name != "@everyone"]
        role_text = ""
        for role in roles:
            line = f"{role.mention}: {len(role.members)} members\n"
            if len(role_text) + len(line) > 4000:
                role_text += "**...and more**"
                break
            role_text += line
        embed = discord.Embed(title=f"Server Roles ({len(roles)})", description=role_text, color=discord.Color.orange())
        await ctx.send(embed=embed)

    @stats_group.command(name="bot")
    async def stats_bot(self, ctx):
        """Shows statistics about the bot itself."""
        uptime = fmt_uptime(discord.utils.utcnow() - self.bot.start_time)
        embed = discord.Embed(title="🤖 Meridian v3 Statistics", color=0x5865F2)
        embed.add_field(name="Uptime", value=uptime, inline=True)
        embed.add_field(name="Guilds", value=str(len(self.bot.guilds)), inline=True)
        embed.add_field(name="Users", value=str(len(self.bot.users)), inline=True)
        embed.add_field(name="Commands", value=str(len(self.bot.commands)), inline=True)
        embed.set_footer(text=f"Powered by Meridian Core")
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Utility(bot))
