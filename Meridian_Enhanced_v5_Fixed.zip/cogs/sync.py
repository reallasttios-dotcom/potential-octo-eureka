# slash_sync.py
import discord
from discord.ext import commands
from discord import app_commands
import aiosqlite
import json
import asyncio
import io
from datetime import datetime
from typing import Optional, Dict, List, Any, Union
import inspect
import re

class SlashSync(commands.Cog):
    """
    Automatically generates slash commands from existing prefix commands.
    Saves command data to database and syncs with Discord.
    """
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.db_path = "slash_commands.db"
        self.synced_commands: Dict[str, Dict] = {}  # Cache for command data
        self.blacklisted_cogs = ["SlashSync", "Help"]  # Cogs to exclude
        self.blacklisted_commands = ["help", "commands"]  # Commands to exclude
        
    async def cog_load(self):
        """Initialize database and sync commands when cog loads"""
        await self.init_database()
        await self.sync_all_commands()
        
    async def init_database(self):
        """Create database tables for storing slash command data"""
        async with aiosqlite.connect(self.db_path) as db:
            # Main commands table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS slash_commands (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    command_name TEXT NOT NULL,
                    command_description TEXT NOT NULL,
                    cog_name TEXT NOT NULL,
                    parameters TEXT,  -- JSON array of parameters
                    is_enabled INTEGER DEFAULT 1,
                    cooldown INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL,
                    last_synced TEXT,
                    sync_count INTEGER DEFAULT 0,
                    UNIQUE(command_name, cog_name)
                )
            """)
            
            # Command usage logs
            await db.execute("""
                CREATE TABLE IF NOT EXISTS command_usage (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    command_name TEXT NOT NULL,
                    user_id INTEGER NOT NULL,
                    guild_id INTEGER,
                    channel_id INTEGER,
                    timestamp TEXT NOT NULL,
                    success INTEGER DEFAULT 1,
                    error_message TEXT
                )
            """)
            
            # Sync history
            await db.execute("""
                CREATE TABLE IF NOT EXISTS sync_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sync_time TEXT NOT NULL,
                    commands_synced INTEGER,
                    status TEXT,
                    error_details TEXT
                )
            """)
            
            await db.commit()
            
    async def extract_command_info(self, cmd: commands.Command) -> Optional[Dict]:
        """Extract information from a prefix command to create a slash command"""
        if cmd.name in self.blacklisted_commands:
            return None
            
        # Skip hidden commands
        if cmd.hidden:
            return None
            
        # Get the cog
        cog = cmd.cog
        if not cog or cog.qualified_name in self.blacklisted_cogs:
            return None
            
        # Extract parameters
        parameters = []
        params = list(cmd.clean_params.items())
        
        for idx, (param_name, param) in enumerate(params):
            # Skip self and ctx parameters
            if param_name in ['self', 'ctx']:
                continue
                
            param_info = {
                "name": param_name,
                "description": f"Parameter: {param_name}",
                "required": param.default == param.empty,
                "type": self.get_param_type(param.annotation),
                "position": idx
            }
            
            # Add example if available
            if param.default != param.empty and param.default is not None:
                param_info["default"] = str(param.default)
                
            parameters.append(param_info)
            
        # Generate description
        description = cmd.help or cmd.short_doc or f"Slash command version of !{cmd.name}"
        description = description[:100]  # Discord limit for slash command descriptions
        
        return {
            "command_name": cmd.name,
            "command_description": description,
            "cog_name": cog.qualified_name,
            "parameters": json.dumps(parameters),
            "is_enabled": 1,
            "cooldown": self.get_command_cooldown(cmd),
            "created_at": datetime.now().isoformat(),
            "last_synced": None,
            "sync_count": 0
        }
        
    def get_param_type(self, annotation) -> str:
        """Convert Python type annotations to Discord slash command types"""
        if annotation == str or annotation == inspect._empty:
            return "string"
        elif annotation == int:
            return "integer"
        elif annotation == bool:
            return "boolean"
        elif annotation == float:
            return "number"
        elif annotation == discord.Member:
            return "member"
        elif annotation == discord.User:
            return "user"
        elif annotation == discord.Role:
            return "role"
        elif annotation == discord.TextChannel:
            return "channel"
        else:
            return "string"
            
    def get_command_cooldown(self, cmd: commands.Command) -> int:
        """Extract cooldown from command if available"""
        if cmd._buckets and cmd._buckets._cooldown:
            return int(cmd._buckets._cooldown.rate)
        return 0
        
    async def sync_all_commands(self):
        """Sync all discovered commands to Discord and database"""
        synced_count = 0
        error_count = 0
        
        for cmd in self.bot.walk_commands():
            # Skip if it's a subcommand (will be handled by parent)
            if cmd.parent:
                continue
                
            try:
                cmd_info = await self.extract_command_info(cmd)
                if not cmd_info:
                    continue
                    
                # Save or update in database
                async with aiosqlite.connect(self.db_path) as db:
                    await db.execute("""
                        INSERT OR REPLACE INTO slash_commands 
                        (command_name, command_description, cog_name, parameters, is_enabled, cooldown, created_at, last_synced, sync_count)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, COALESCE((SELECT sync_count + 1 FROM slash_commands WHERE command_name = ? AND cog_name = ?), 1))
                    """, (
                        cmd_info["command_name"],
                        cmd_info["command_description"],
                        cmd_info["cog_name"],
                        cmd_info["parameters"],
                        cmd_info["is_enabled"],
                        cmd_info["cooldown"],
                        cmd_info["created_at"],
                        datetime.now().isoformat(),
                        cmd_info["command_name"],
                        cmd_info["cog_name"]
                    ))
                    await db.commit()
                    
                # Register the slash command
                await self.register_slash_command(cmd_info)
                synced_count += 1
                
            except Exception as e:
                print(f"Error syncing command {cmd.name}: {e}")
                error_count += 1
                
        # Log sync history
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO sync_history (sync_time, commands_synced, status)
                VALUES (?, ?, ?)
            """, (datetime.now().isoformat(), synced_count, "success" if error_count == 0 else "partial"))
            await db.commit()
            
        print(f"Synced {synced_count} slash commands ({error_count} errors)")
        
        # Sync the command tree to Discord (global sync)
        try:
            await self.bot.tree.sync()
            print("Command tree synced to Discord globally.")
        except Exception as e:
            print(f"Failed to sync command tree: {e}")
        
    async def register_slash_command(self, cmd_info: Dict):
        """Register a single slash command with Discord"""
        command_name = cmd_info["command_name"]
        
        # Get the original prefix command
        original_cmd = self.bot.get_command(command_name)
        if not original_cmd:
            return

        # Remove existing command if present to avoid conflicts
        existing = self.bot.tree.get_command(command_name)
        if existing:
            self.bot.tree.remove_command(command_name)

        # Create the slash command with the forged callback
        cmd = app_commands.Command(
            name=command_name,
            description=cmd_info["command_description"],
            callback=self.create_command_callback(command_name, original_cmd),
            nsfw=False
        )
        
        self.bot.tree.add_command(cmd)
        
    def create_command_callback(self, command_name: str, original_cmd: commands.Command):
        """Create a callback function with a forged signature matching the original command"""
        
        async def callback(interaction: discord.Interaction, **kwargs):
            # Create a context from the interaction
            ctx = await commands.Context.from_interaction(interaction)
            
            # Log usage
            await self.log_command_usage(interaction, command_name)
            
            try:
                # Invoke the original prefix command with the context and arguments
                await original_cmd(ctx, **kwargs)
                await self.update_command_usage(command_name, success=True)
            except Exception as e:
                await self.update_command_usage(command_name, success=False, error=str(e))
                raise  # Re-raise so Discord shows the error

        # --- Forge the signature ---
        # The signature must have an Interaction parameter followed by the original command's parameters
        new_params = [
            inspect.Parameter("interaction", inspect.Parameter.POSITIONAL_OR_KEYWORD, annotation=discord.Interaction)
        ]
        
        for param_name, param in original_cmd.clean_params.items():
            if param_name in ['self', 'ctx']:
                continue
            
            # Use the original annotation, default to str if missing
            annotation = param.annotation if param.annotation != inspect._empty else str
            
            # Handle defaults properly
            default = param.default if param.default != param.empty else inspect.Parameter.empty
            
            new_params.append(
                inspect.Parameter(
                    param_name,
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    annotation=annotation,
                    default=default
                )
            )
        
        callback.__signature__ = inspect.Signature(parameters=new_params)
        return callback
        
    async def log_command_usage(self, interaction: discord.Interaction, command_name: str):
        """Log command usage to database"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO command_usage (command_name, user_id, guild_id, channel_id, timestamp)
                VALUES (?, ?, ?, ?, ?)
            """, (
                command_name,
                interaction.user.id,
                interaction.guild_id,
                interaction.channel_id,
                datetime.now().isoformat()
            ))
            await db.commit()
            
    async def update_command_usage(self, command_name: str, success: bool, error: str = None):
        """Update command usage record with result"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                UPDATE command_usage 
                SET success = ?, error_message = ?
                WHERE command_name = ? AND timestamp = (
                    SELECT MAX(timestamp) FROM command_usage WHERE command_name = ?
                )
            """, (1 if success else 0, error, command_name, command_name))
            await db.commit()
            
    # --- Management Commands ---
    
    @app_commands.command(name="sync_commands", description="Manually sync all prefix commands to slash commands")
    @app_commands.checks.has_permissions(administrator=True)
    async def sync_commands_slash(self, interaction: discord.Interaction):
        """Manually trigger command sync (Admin only)"""
        await interaction.response.defer(ephemeral=True)
        
        try:
            await self.sync_all_commands()
            await interaction.followup.send("Successfully synced all commands to slash commands!", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Error syncing commands: {str(e)[:100]}", ephemeral=True)
            
    @app_commands.command(name="disable_command", description="Disable a slash command")
    @app_commands.checks.has_permissions(administrator=True)
    async def disable_command_slash(self, interaction: discord.Interaction, command_name: str):
        """Disable a specific slash command"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE slash_commands SET is_enabled = 0 WHERE command_name = ?",
                (command_name,)
            )
            await db.commit()
            
        await interaction.response.send_message(f"Disabled slash command `/{command_name}`", ephemeral=True)
        
    @app_commands.command(name="enable_command", description="Enable a slash command")
    @app_commands.checks.has_permissions(administrator=True)
    async def enable_command_slash(self, interaction: discord.Interaction, command_name: str):
        """Enable a specific slash command"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE slash_commands SET is_enabled = 1 WHERE command_name = ?",
                (command_name,)
            )
            await db.commit()
            
        await interaction.response.send_message(f"Enabled slash command `/{command_name}`", ephemeral=True)
        
    @app_commands.command(name="list_commands", description="List all synced slash commands")
    async def list_commands_slash(self, interaction: discord.Interaction):
        """List all available slash commands"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT command_name, is_enabled, cog_name FROM slash_commands ORDER BY command_name"
            )
            commands = await cursor.fetchall()
            
        if not commands:
            await interaction.response.send_message("No commands have been synced yet.", ephemeral=True)
            return
            
        embed = discord.Embed(
            title="Synced Slash Commands",
            description=f"Total commands: {len(commands)}",
            color=discord.Color.orange()
        )
        
        for cmd_name, is_enabled, cog_name in commands:
            status = "✅" if is_enabled else "❌"
            embed.add_field(
                name=f"{status} /{cmd_name}",
                value=f"*{cog_name}*",
                inline=True
            )
            
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    @app_commands.command(name="command_stats", description="View usage statistics for commands")
    @app_commands.checks.has_permissions(administrator=True)
    async def command_stats_slash(self, interaction: discord.Interaction, command_name: Optional[str] = None):
        """View command usage statistics"""
        async with aiosqlite.connect(self.db_path) as db:
            if command_name:
                cursor = await db.execute("""
                    SELECT command_name, COUNT(*) as total, 
                           SUM(success) as successful,
                           sync_count
                    FROM command_usage c
                    JOIN slash_commands s ON c.command_name = s.command_name
                    WHERE c.command_name = ?
                    GROUP BY c.command_name
                """, (command_name,))
                stats = await cursor.fetchone()
                
                if not stats:
                    await interaction.response.send_message(f"No usage data found for `/{command_name}`", ephemeral=True)
                    return
                    
                cmd_name, total, successful, sync_count = stats
                success_rate = (successful / total * 100) if total > 0 else 0
                
                embed = discord.Embed(
                    title=f"Statistics for /{cmd_name}",
                    color=discord.Color.green() if success_rate > 80 else discord.Color.orange()
                )
                embed.add_field(name="Total Uses", value=str(total), inline=True)
                embed.add_field(name="Success Rate", value=f"{success_rate:.1f}%", inline=True)
                embed.add_field(name="Times Synced", value=str(sync_count), inline=True)
                
                await interaction.response.send_message(embed=embed, ephemeral=True)
            else:
                cursor = await db.execute("""
                    SELECT command_name, COUNT(*) as uses
                    FROM command_usage
                    GROUP BY command_name
                    ORDER BY uses DESC
                    LIMIT 10
                """)
                top_commands = await cursor.fetchall()
                
                if not top_commands:
                    await interaction.response.send_message("No usage data available yet.", ephemeral=True)
                    return
                    
                embed = discord.Embed(
                    title="Top 10 Most Used Commands",
                    color=discord.Color.gold()
                )
                
                for idx, (cmd_name, uses) in enumerate(top_commands, 1):
                    embed.add_field(
                        name=f"{idx}. /{cmd_name}",
                        value=f"{uses} uses",
                        inline=False
                    )
                    
                await interaction.response.send_message(embed=embed, ephemeral=True)
                
    @app_commands.command(name="resync_cog", description="Resync commands from a specific cog")
    @app_commands.checks.has_permissions(administrator=True)
    async def resync_cog_slash(self, interaction: discord.Interaction, cog_name: str):
        """Resync only commands from a specific cog"""
        await interaction.response.defer(ephemeral=True)
        
        cog = self.bot.get_cog(cog_name)
        if not cog:
            await interaction.followup.send(f"Cog `{cog_name}` not found.", ephemeral=True)
            return
            
        synced = 0
        for cmd in cog.walk_commands():
            if cmd.parent:  # Skip subcommands
                continue
                
            cmd_info = await self.extract_command_info(cmd)
            if cmd_info:
                await self.register_slash_command(cmd_info)
                synced += 1
                
        await interaction.followup.send(f"Resynced {synced} commands from cog `{cog_name}`", ephemeral=True)
        
    @app_commands.command(name="export_commands", description="Export all command data to JSON")
    @app_commands.checks.has_permissions(administrator=True)
    async def export_commands_slash(self, interaction: discord.Interaction):
        """Export all command data as JSON"""
        await interaction.response.defer(ephemeral=True)
        
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute("SELECT * FROM slash_commands")
            commands = await cursor.fetchall()
            
            cursor = await db.execute("SELECT * FROM command_usage LIMIT 1000")
            usage = await cursor.fetchall()
            
        export_data = {
            "exported_at": datetime.now().isoformat(),
            "commands": [dict(cmd) for cmd in commands],
            "usage_stats": [dict(use) for use in usage]
        }
        
        # Create JSON file
        json_str = json.dumps(export_data, indent=2, default=str)
        file = discord.File(
            fp=io.BytesIO(json_str.encode()),
            filename=f"command_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        )
        
        await interaction.followup.send("Command data export:", file=file, ephemeral=True)
        
    @app_commands.command(name="clear_command_cache", description="Clear the command cache and resync")
    @app_commands.checks.has_permissions(administrator=True)
    async def clear_cache_slash(self, interaction: discord.Interaction):
        """Clear command cache and force full resync"""
        await interaction.response.defer(ephemeral=True)
        
        # Clear Discord's command tree for this guild
        self.bot.tree.clear_commands(guild=interaction.guild)
        
        # Resync all commands
        await self.sync_all_commands()
        
        # Sync to Discord
        await self.bot.tree.sync(guild=interaction.guild)
        
        await interaction.followup.send("Command cache cleared and resynced!", ephemeral=True)

# Required for loading the cog
async def setup(bot: commands.Bot):
    await bot.add_cog(SlashSync(bot))