import os
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from typing import Optional, Tuple


THEME_COLORS = {
    "dark": {
        "background": (18, 18, 30),
        "surface": (30, 30, 50),
        "accent": (114, 137, 218),
        "text_primary": (255, 255, 255),
        "text_secondary": (185, 187, 190),
        "bar_fill": (114, 137, 218),
        "bar_empty": (50, 50, 70),
        "success": (67, 181, 129),
        "error": (240, 71, 71),
        "warning": (250, 166, 26),
    },
    "neon": {
        "background": (10, 10, 20),
        "surface": (15, 15, 35),
        "accent": (0, 255, 200),
        "text_primary": (220, 255, 255),
        "text_secondary": (100, 200, 200),
        "bar_fill": (0, 255, 180),
        "bar_empty": (20, 50, 50),
        "success": (0, 255, 120),
        "error": (255, 60, 60),
        "warning": (255, 200, 0),
    },
    "light": {
        "background": (240, 242, 245),
        "surface": (255, 255, 255),
        "accent": (88, 101, 242),
        "text_primary": (35, 35, 35),
        "text_secondary": (100, 100, 120),
        "bar_fill": (88, 101, 242),
        "bar_empty": (200, 205, 215),
        "success": (35, 165, 90),
        "error": (200, 50, 50),
        "warning": (200, 140, 0),
    },
}


FONT_PATHS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    "/usr/share/fonts/noto/NotoSans-Bold.ttf",
    "/System/Library/Fonts/Helvetica.ttc",
    "C:/Windows/Fonts/arial.ttf",
]
FONT_PATHS_REGULAR = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
    "/usr/share/fonts/noto/NotoSans-Regular.ttf",
]


def get_font(size: int, bold: bool = True) -> ImageFont.ImageFont:
    paths = FONT_PATHS if bold else FONT_PATHS_REGULAR
    for path in paths:
        try:
            return ImageFont.truetype(path, size)
        except (OSError, IOError):
            continue
    return ImageFont.load_default()


def circle_crop(img: Image.Image, size: int) -> Image.Image:
    img = img.resize((size, size), Image.LANCZOS).convert("RGBA")
    mask = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0, size - 1, size - 1), fill=255)
    result = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    result.paste(img, (0, 0), mask)
    return result


def draw_rounded_rect(
    draw: ImageDraw.Draw,
    xy: Tuple[int, int, int, int],
    radius: int,
    fill: Optional[Tuple] = None,
    outline: Optional[Tuple] = None,
    outline_width: int = 2,
) -> None:
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=outline_width)


def truncate_text(text: str, max_chars: int = 100) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars - 3] + "..."


class BaseTemplate:
    """Base class for all card templates."""

    WIDTH = 900
    HEIGHT = 300

    def __init__(self, theme: str = "dark"):
        self.theme = self._resolve_theme(theme)

    def _resolve_theme(self, theme: str) -> dict:
        """Resolve a theme name to its color palette."""
        return THEME_COLORS.get(theme, THEME_COLORS["dark"])

    def new_canvas(self, width: Optional[int] = None, height: Optional[int] = None) -> Image.Image:
        w = width or self.WIDTH
        h = height or self.HEIGHT
        img = Image.new("RGBA", (w, h), self.theme["background"])
        return img

    def draw_banner_background(
        self, 
        canvas: Image.Image, 
        banner_image: Optional[Image.Image], 
        height: int = 120, 
        opacity: int = 160,
        blur: int = 0
    ) -> None:
        """Helper to draw a banner background with overlay and optional blur."""
        if not banner_image:
            return
            
        w, _ = canvas.size
        banner = banner_image.resize((w, height), Image.LANCZOS)
        
        if blur > 0:
            banner = banner.filter(ImageFilter.GaussianBlur(blur))
            
        faded = banner.convert("RGBA")
        overlay = Image.new("RGBA", faded.size, (*self.theme["background"], opacity))
        faded = Image.alpha_composite(faded, overlay)
        canvas.paste(faded, (0, 0))

    def to_bytes(self, img: Image.Image, format: str = "PNG", optimize: bool = True) -> bytes:
        from io import BytesIO
        out = BytesIO()
        if format == "PNG":
            img.save(out, format="PNG", optimize=optimize)
        else:
            img.save(out, format=format)
        return out.getvalue()
