from __future__ import annotations
from typing import Optional, List
from PIL import Image, ImageDraw
import discord

from .base import BaseTemplate, get_font, circle_crop, draw_rounded_rect, truncate_text, THEME_COLORS


class LeaderboardEntry:
    def __init__(self, user: discord.Member, level: int, total_xp: int, rank: int,
                 current_xp: int = 0, needed_xp: int = 100,
                 avatar_image: Optional[Image.Image] = None,
                 banner_image: Optional[Image.Image] = None):
        self.user = user
        self.level = level
        self.total_xp = total_xp
        self.rank = rank
        self.current_xp = current_xp
        self.needed_xp = needed_xp
        self.avatar_image = avatar_image
        self.banner_image = banner_image


class LeaderboardTemplate(BaseTemplate):
    """
    Leaderboard card template showing top users with avatars, levels, and XP.
    """

    WIDTH = 900
    ROW_HEIGHT = 100
    HEADER_HEIGHT = 120
    PADDING = 20

    async def render(
        self,
        entries: List[LeaderboardEntry],
        guild: discord.Guild,
        page: int = 1,
        theme: str = "dark",
        rank_emojis: Optional[List[Image.Image]] = None,
        banner_image: Optional[Image.Image] = None,
        icon_image: Optional[Image.Image] = None,
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        self.theme = colors
        visible = entries[:10]
        height = self.HEADER_HEIGHT + len(visible) * self.ROW_HEIGHT + self.PADDING * 2

        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw = ImageDraw.Draw(canvas)

        # Draw guild banner background using helper
        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=self.HEADER_HEIGHT, opacity=140, blur=1)

        header_font = get_font(34, bold=True)
        
        # Draw guild icon if provided
        if icon_image:
            icon_size = 70
            icon = circle_crop(icon_image, icon_size)
            canvas.paste(icon, (self.PADDING, self.PADDING + 10), icon)
            header_x = self.PADDING + icon_size + 20
        else:
            header_x = self.PADDING
            
        name_font = get_font(22, bold=True)
        sub_font = get_font(16, bold=False)
        rank_font = get_font(24, bold=True)
        level_font = get_font(14, bold=True)

        draw.text((header_x, self.PADDING + 15), f"{guild.name} — Leaderboard",
                  font=header_font, fill=colors["text_primary"])
        draw.text((header_x, self.PADDING + 60),
                  f"Page {page} | Top {len(visible)} users",
                  font=sub_font, fill=colors["text_secondary"])

        for i, entry in enumerate(visible):
            y = self.HEADER_HEIGHT + i * self.ROW_HEIGHT
            row_rect = (self.PADDING, y + 4, self.WIDTH - self.PADDING, y + self.ROW_HEIGHT - 4)
            
            # Draw user banner if available, otherwise row color
            if entry.banner_image:
                row_w = self.WIDTH - (self.PADDING * 2)
                row_h = self.ROW_HEIGHT - 8
                
                # Resize and crop banner to fit row (center crop)
                banner = entry.banner_image.convert("RGBA")
                aspect_ratio = row_w / row_h
                banner_aspect = banner.width / banner.height
                
                if banner_aspect > aspect_ratio:
                    new_width = int(banner.height * aspect_ratio)
                    left = (banner.width - new_width) // 2
                    banner = banner.crop((left, 0, left + new_width, banner.height))
                else:
                    new_height = int(banner.width / aspect_ratio)
                    top = (banner.height - new_height) // 2
                    banner = banner.crop((0, top, banner.width, top + new_height))
                
                banner = banner.resize((row_w, row_h), Image.LANCZOS)
                
                # Create mask for rounded corners
                mask = Image.new("L", (row_w, row_h), 0)
                mask_draw = ImageDraw.Draw(mask)
                mask_draw.rounded_rectangle((0, 0, row_w, row_h), radius=12, fill=255)
                
                # Add dark overlay to make text readable
                overlay = Image.new("RGBA", (row_w, row_h), (0, 0, 0, 160))
                banner.alpha_composite(overlay)
                
                # Paste the banner onto the canvas using the rounded mask
                canvas.paste(banner, (self.PADDING, y + 4), mask)
            else:
                row_color = (*colors["surface"], 220) if i % 2 == 0 else (*colors["background"], 180)
                draw_rounded_rect(draw, row_rect, radius=12, fill=row_color)

            # Rank
            rank_str = f"#{entry.rank}"
            draw.text((self.PADDING + 15, y + 35), rank_str, font=rank_font, fill=colors["accent"])

            # Avatar
            av_x = self.PADDING + 75
            av_y = y + 15
            av_size = self.ROW_HEIGHT - 30
            
            if entry.avatar_image:
                av = circle_crop(entry.avatar_image, av_size)
                canvas.paste(av, (av_x, av_y), av)
            else:
                draw.ellipse((av_x, av_y, av_x + av_size, av_y + av_size), fill=colors["accent"])

            # Name, Username and Level
            tx = av_x + av_size + 20
            display_name = truncate_text(entry.user.display_name, 25)
            draw.text((tx, y + 20), display_name, font=name_font, fill=colors["text_primary"])
            
            # Username
            username = f"@{entry.user.name}" if entry.user.discriminator == "0" else f"{entry.user.name}#{entry.user.discriminator}"
            username = truncate_text(username, 18)
            draw.text((tx, y + 52), username, font=sub_font, fill=colors["text_secondary"])
            
            # Level in a rounded square
            level_text = f"LVL {entry.level}"
            uw = draw.textlength(username, font=sub_font)
            lx = tx + uw + 15
            ly = y + 50
            
            # Measure level text
            lw = draw.textlength(level_text, font=level_font)
            lh = 20
            padding_w = 8
            
            # Draw rounded square for level
            draw_rounded_rect(draw, (lx, ly, lx + lw + padding_w * 2, ly + lh), radius=5, fill=colors["accent"])
            draw.text((lx + padding_w, ly + 1), level_text, font=level_font, fill=(255, 255, 255))

            # XP Progress Bar
            bar_w = 250
            bar_h = 12
            bar_x = self.WIDTH - self.PADDING - bar_w - 20
            bar_y = y + 45
            bar_radius = bar_h // 2

            # Background bar
            draw.rounded_rectangle(
                (bar_x, bar_y, bar_x + bar_w, bar_y + bar_h),
                radius=bar_radius, fill=colors["bar_empty"]
            )
            
            # Progress fill
            progress = min(entry.current_xp / max(entry.needed_xp, 1), 1.0)
            if progress > 0:
                fill_w = max(int(bar_w * progress), bar_radius * 2)
                draw.rounded_rectangle(
                    (bar_x, bar_y, bar_x + fill_w, bar_y + bar_h),
                    radius=bar_radius, fill=colors["bar_fill"]
                )

            # XP Text ABOVE bar (fixed overlap)
            xp_text = f"{entry.current_xp:,} / {entry.needed_xp:,} XP"
            xp_font = get_font(14, bold=False)
            tw = draw.textlength(xp_text, font=xp_font)
            draw.text((bar_x + bar_w - tw, bar_y - 22), xp_text, font=xp_font, fill=colors["text_secondary"])
            
            # Total XP BELOW bar
            total_xp_text = f"Total: {entry.total_xp:,} XP"
            draw.text((bar_x, bar_y + bar_h + 6), total_xp_text, font=get_font(12, bold=False), fill=colors["text_secondary"])

        return self.to_bytes(canvas)
