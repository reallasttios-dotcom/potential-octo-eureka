from __future__ import annotations
from typing import Optional, List
from PIL import Image, ImageDraw
import discord
from datetime import datetime

from .base import BaseTemplate, get_font, circle_crop, draw_rounded_rect, truncate_text, THEME_COLORS

STATUS_COLORS = {
    "pending":  (243, 156, 18),
    "approved": (46,  204, 113),
    "denied":   (231, 76,  60),
}
STEP_EMOJIS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"]


class VerificationCardTemplate(BaseTemplate):
    """
    Verification system card: shows user info, status, and verification steps.
    """

    WIDTH = 860
    LINE_HEIGHT = 32

    async def render(
        self,
        user: discord.Member | discord.User,
        status: str = "pending",
        steps: Optional[List[str]] = None,
        completed_steps: int = 0,
        notes: Optional[str] = None,
        user_avatar: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        theme: str = "dark",
        timestamp: Optional[datetime] = None,
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        status_color = STATUS_COLORS.get(status.lower(), (114, 137, 218))
        
        header_font = get_font(22, bold=True)
        label_font  = get_font(15, bold=True)
        val_font    = get_font(15, bold=False)
        meta_font   = get_font(13, bold=False)

        # Calculate total height
        height = 100 # Header + Padding
        height += 75 # User info
        if steps: height += 30 + len(steps) * self.LINE_HEIGHT
        if notes: height += 40
        height = max(height, 200)

        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw = ImageDraw.Draw(canvas)

        # Draw banner background using helper
        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=100, opacity=140, blur=1)

        draw.rectangle((0, 0, 6, height), fill=status_color)
        draw_rounded_rect(draw, (12, 12, self.WIDTH - 12, height - 12),
                          radius=14, fill=(*colors["surface"], 230))

        draw.text((24, 20), "🛡️  Verification", font=header_font, fill=colors["text_primary"])

        ts_str = (timestamp or datetime.utcnow()).strftime("%Y-%m-%d %H:%M UTC")
        bbox = draw.textbbox((0, 0), ts_str, font=meta_font)
        draw.text((self.WIDTH - bbox[2] - 24, 24), ts_str, font=meta_font, fill=colors["text_secondary"])

        y = 65
        av_size = 52
        if user_avatar:
            av = circle_crop(user_avatar, av_size)
            canvas.paste(av, (24, y), av)
        else:
            draw.ellipse((24, y, 24 + av_size, y + av_size), fill=colors["accent"])

        draw.text((86, y + 4),  truncate_text(str(user), 30), font=label_font, fill=colors["text_primary"])
        draw.text((86, y + 26), f"ID: {user.id}", font=meta_font, fill=colors["text_secondary"])
        draw.text((86, y + 44), f"Status: {status.upper()}", font=val_font, fill=status_color)
        y += 80

        if steps:
            draw.text((24, y), "Verification Steps:", font=label_font, fill=colors["text_secondary"])
            y += 24
            for i, step in enumerate(steps):
                icon = "✅" if i < completed_steps else ("🔄" if i == completed_steps else "⬜")
                step_color = colors["success"] if i < completed_steps else \
                             (colors["warning"] if i == completed_steps else colors["text_secondary"])
                draw.text((24, y), f"{icon}  {step}", font=val_font, fill=step_color)
                y += self.LINE_HEIGHT

        if notes:
            y += 10
            draw.text((24, y), "Notes:", font=label_font, fill=colors["text_secondary"])
            draw.text((110, y), truncate_text(notes, 80), font=val_font, fill=colors["text_primary"])

        return self.to_bytes(canvas)
