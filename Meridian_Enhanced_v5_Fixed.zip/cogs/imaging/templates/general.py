"""
general.py — General-purpose card templates for all cogs not covered by
dedicated templates. Each sub-renderer is self-contained and accepts only
the data it actually needs.

Covered use-cases:
  - info_card      → help, self, embed, prefix_manager, sync, server_config,
                     rolecounter, channel, reactionroles, tempvoice, activity
  - snipe_card     → snipe (deleted / edited message recall)
  - afk_card       → afk (AFK status with duration)
  - boost_card     → boost_tracker (server boost announcements)
  - translate_card → translate (original + translated text)
  - starboard_card → starboard (starred message display)
  - alert_card     → antibot, antinuke, appeal, anon (high-visibility alerts)
  - invite_card    → invite_logger (invite usage tracking)
  - bump_card      → bump (bump reminders / leader-boards)
  - debate_card    → debate (topic + participants)
  - tiktok_card    → tiktok (video metadata preview)
  - stats_card     → rolecounter, emoji (counted items + breakdown)
"""
from __future__ import annotations

import inspect
from datetime import datetime
from typing import Optional, List, Tuple
from PIL import Image, ImageDraw

import discord

from .base import (
    BaseTemplate,
    THEME_COLORS,
    get_font,
    circle_crop,
    draw_rounded_rect,
    truncate_text,
)

# ── colour constants ───────────────────────────────────────────────────────────
_RED    = (231,  76,  60)
_ORANGE = (230, 126,  34)
_GREEN  = ( 46, 204, 113)
_BLUE   = ( 52, 152, 219)
_PURPLE = (155,  89, 182)
_GOLD   = (212, 175,  55)


# ── helpers ───────────────────────────────────────────────────────────────────

def _wrap(draw: ImageDraw.Draw, text: str, font, max_width: int) -> List[str]:
    if not text: return []
    lines = []
    for paragraph in text.split('\n'):
        words = paragraph.split()
        if not words:
            lines.append("")
            continue
        current = ""
        for word in words:
            test = f"{current} {word}".strip()
            bbox = draw.textbbox((0, 0), test, font=font)
            if bbox[2] - bbox[0] <= max_width:
                current = test
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
    return lines


def _ts(dt: Optional[datetime] = None) -> str:
    return (dt or datetime.utcnow()).strftime("%Y-%m-%d %H:%M UTC")


def _draw_accent_bar(draw: ImageDraw.Draw, height: int, color: tuple) -> None:
    draw.rectangle((0, 0, 5, height), fill=color)


def _draw_surface(draw: ImageDraw.Draw, width: int, height: int, colors: dict) -> None:
    draw_rounded_rect(draw, (12, 12, width - 12, height - 12),
                      radius=14, fill=(*colors["surface"], 230))


# ══════════════════════════════════════════════════════════════════════════════
class GeneralTemplate(BaseTemplate):
    """
    General-purpose template hub. Choose the right sub-renderer for each cog.
    All methods return PNG bytes.

    Dispatcher via render(card_type, **kwargs):
        await bot.imaging.render("general", card_type="snipe", ...)
    """

    WIDTH = 860
    LINE_HEIGHT = 22

    async def render(self, card_type: str, **kwargs) -> bytes:
        """Main dispatcher for the general template."""
        method_name = f"render_{card_type}_card"
        if hasattr(self, method_name):
            method = getattr(self, method_name)
            # Filter kwargs for the specific method
            sig = inspect.signature(method)
            valid_kwargs = {k: v for k, v in kwargs.items() if k in sig.parameters}
            return await method(**valid_kwargs)
        # Fallback to info card
        return await self.render_info_card(**kwargs)

    # ── 1. Generic info card ──────────────────────────────────────────────────
    async def render_info_card(
        self,
        title: str,
        description: Optional[str] = None,
        fields: Optional[List[Tuple[str, str, bool]]] = None,
        thumbnail: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        color: Optional[tuple] = None,
        footer: Optional[str] = None,
        timestamp: Optional[datetime] = None,
        theme: str = "dark",
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        accent = color or colors["accent"]

        title_font  = get_font(22, bold=True)
        body_font   = get_font(15, bold=False)
        label_font  = get_font(14, bold=True)
        footer_font = get_font(12, bold=False)

        dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
        tx = 60 if thumbnail is None else 120
        desc_lines = _wrap(dummy_draw, description or "", body_font, self.WIDTH - tx - 40)
        desc_lines = desc_lines[:15]

        height = 90 # Header
        height += len(desc_lines) * self.LINE_HEIGHT
        if fields: height += 20 + len(fields) * 28
        if footer: height += 30
        height = max(height, 140)

        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw   = ImageDraw.Draw(canvas)

        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=80, opacity=140, blur=1)

        _draw_accent_bar(draw, height, accent)
        _draw_surface(draw, self.WIDTH, height, colors)

        if thumbnail:
            th = circle_crop(thumbnail, 52)
            canvas.paste(th, (24, 20), th)

        draw.text((tx, 20), truncate_text(title, 55), font=title_font, fill=colors["text_primary"])

        ts_str = _ts(timestamp)
        tb = draw.textbbox((0, 0), ts_str, font=footer_font)
        draw.text((self.WIDTH - tb[2] - 24, 24), ts_str, font=footer_font, fill=colors["text_secondary"])

        y = 54
        if desc_lines:
            for line in desc_lines:
                draw.text((tx, y), line, font=body_font, fill=colors["text_primary"])
                y += self.LINE_HEIGHT
            y += 10

        if fields:
            draw.line((tx, y, self.WIDTH - 24, y), fill=(*colors["bar_empty"], 120), width=1)
            y += 10
            for fname, fval, *_ in fields:
                draw.text((tx, y), f"{fname}:", font=label_font, fill=colors["text_secondary"])
                draw.text((tx + 160, y), truncate_text(str(fval), 55), font=body_font, fill=colors["text_primary"])
                y += 28

        if footer:
            draw.text((tx, y + 6), truncate_text(footer, 80), font=footer_font, fill=colors["text_secondary"])

        return self.to_bytes(canvas)

    # ── 2. Snipe card ─────────────────────────────────────────────────────────
    async def render_snipe_card(
        self,
        snipe_type: str,                    # "delete" | "edit" | "react"
        author_name: str,
        author_id: int,
        content: Optional[str] = None,
        before_content: Optional[str] = None,
        channel_name: Optional[str] = None,
        sniped_at: Optional[datetime] = None,
        avatar_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        attachment_image: Optional[Image.Image] = None,
        reactions: Optional[str] = None,
        theme: str = "dark",
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        accent = _RED if snipe_type == "delete" else (_ORANGE if snipe_type == "edit" else _PURPLE)
        
        body_font  = get_font(15, bold=False)
        label_font = get_font(16, bold=True)
        meta_font  = get_font(13, bold=False)
        header_font = get_font(20, bold=True)

        dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
        
        if snipe_type == "edit" and before_content and content:
            mid = self.WIDTH // 2
            col_w = mid - 48
            before_lines = _wrap(dummy_draw, truncate_text(before_content, 400), body_font, col_w)[:15]
            after_lines = _wrap(dummy_draw, truncate_text(content, 400), body_font, col_w)[:15]
            content_h = max(len(before_lines), len(after_lines), 1) * self.LINE_HEIGHT
        else:
            content_lines = _wrap(dummy_draw, truncate_text(content or "", 500), body_font, self.WIDTH - 48)[:15]
            content_h = len(content_lines) * self.LINE_HEIGHT

        height = 100 # Header
        height += 60 # User info
        if reactions: height += 25
        height += content_h + 20
        if attachment_image: height += 180
        height = max(height, 160)

        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw   = ImageDraw.Draw(canvas)

        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=80, opacity=140, blur=1)

        _draw_accent_bar(draw, height, accent)
        _draw_surface(draw, self.WIDTH, height, colors)

        TYPE_LABELS = {"delete": "🗑️  Sniped — Deleted", "edit": "✏️  Sniped — Edited", "react": "💬  Sniped — Reactions"}
        draw.text((24, 20), TYPE_LABELS.get(snipe_type, "🔍  Sniped"), font=header_font, fill=accent)

        ts = _ts(sniped_at)
        tb = draw.textbbox((0, 0), ts, font=meta_font)
        draw.text((self.WIDTH - tb[2] - 24, 24), ts, font=meta_font, fill=colors["text_secondary"])

        y = 52
        av_size = 48
        if avatar_image:
            av = circle_crop(avatar_image, av_size)
            canvas.paste(av, (24, y), av)
        else:
            draw.ellipse((24, y, 24 + av_size, y + av_size), fill=accent)

        draw.text((82, y + 4),  truncate_text(author_name, 30), font=label_font, fill=colors["text_primary"])
        ch_str = f"#{channel_name}" if channel_name else ""
        draw.text((82, y + 26), f"ID: {author_id}  {ch_str}", font=meta_font, fill=colors["text_secondary"])
        y += 65

        if reactions:
            draw.text((24, y), f"Reactions: {truncate_text(reactions, 80)}", font=meta_font, fill=colors["text_secondary"])
            y += 25

        if snipe_type == "edit" and before_content and content:
            mid = self.WIDTH // 2
            draw.rectangle((mid - 1, y, mid + 1, height - 20), fill=(*colors["bar_empty"], 160))
            draw.text((24, y), "Before", font=label_font, fill=_RED)
            draw.text((mid + 20, y), "After", font=label_font, fill=_GREEN)
            y += 24
            by, ay = y, y
            for line in before_lines:
                draw.text((24, by), line, font=body_font, fill=colors["text_primary"]); by += self.LINE_HEIGHT
            for line in after_lines:
                draw.text((mid + 20, ay), line, font=body_font, fill=colors["text_primary"]); ay += self.LINE_HEIGHT
            y = max(by, ay)
        elif content:
            for line in content_lines:
                draw.text((24, y), line, font=body_font, fill=colors["text_primary"]); y += self.LINE_HEIGHT

        if attachment_image:
            y += 10
            max_w = self.WIDTH - 48
            ratio = max_w / attachment_image.width
            th = min(int(attachment_image.height * ratio), 160)
            thumb = attachment_image.resize((max_w, th), Image.LANCZOS)
            canvas.paste(thumb, (24, y))

        return self.to_bytes(canvas)

    # ── 3. AFK card ───────────────────────────────────────────────────────────
    async def render_afk_card(
        self,
        user_name: str,
        user_id: int,
        reason: str,
        since: float,
        avatar_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        returning: bool = False,
        theme: str = "dark",
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        accent = _GREEN if returning else _BLUE

        import time
        elapsed = time.time() - since
        d, rem = divmod(int(elapsed), 86400)
        h, rem = divmod(rem, 3600)
        m, s   = divmod(rem, 60)
        parts = []
        if d: parts.append(f"{d}d")
        if h: parts.append(f"{h}h")
        if m: parts.append(f"{m}m")
        if s or not parts: parts.append(f"{s}s")
        duration_str = " ".join(parts)

        canvas = Image.new("RGBA", (self.WIDTH, 160), colors["background"])
        draw   = ImageDraw.Draw(canvas)

        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=80, opacity=140, blur=1)

        _draw_accent_bar(draw, 160, accent)
        _draw_surface(draw, self.WIDTH, 160, colors)

        header_font = get_font(20, bold=True)
        name_font   = get_font(17, bold=True)
        body_font   = get_font(15, bold=False)
        meta_font   = get_font(13, bold=False)

        label = "✅  Back from AFK" if returning else "💤  AFK"
        draw.text((24, 20), label, font=header_font, fill=accent)

        av_size = 56
        y = 50
        if avatar_image:
            av = circle_crop(avatar_image, av_size)
            canvas.paste(av, (24, y), av)
        else:
            draw.ellipse((24, y, 24 + av_size, y + av_size), fill=accent)

        tx = 90
        draw.text((tx, y + 2),  truncate_text(user_name, 30), font=name_font, fill=colors["text_primary"])
        draw.text((tx, y + 26), f"Reason: {truncate_text(reason, 50)}", font=body_font, fill=colors["text_primary"])
        draw.text((tx, y + 48), f"{'Away for' if returning else 'Since'}: {duration_str}",
                  font=meta_font, fill=colors["text_secondary"])

        return self.to_bytes(canvas)

    # ── 4. Boost card ─────────────────────────────────────────────────────────
    async def render_boost_card(
        self,
        user_name: str,
        user_id: int,
        boost_count: int,
        total_guild_boosts: int,
        boost_emoji: Optional[str] = None,
        role_name: Optional[str] = None,
        avatar_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        theme: str = "dark",
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        accent = _GOLD

        canvas = Image.new("RGBA", (self.WIDTH, 200), colors["background"])
        draw   = ImageDraw.Draw(canvas)

        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=80, opacity=140, blur=1)

        _draw_accent_bar(draw, 200, accent)
        _draw_surface(draw, self.WIDTH, 200, colors)

        header_font = get_font(24, bold=True)
        name_font   = get_font(18, bold=True)
        sub_font    = get_font(15, bold=False)
        big_font    = get_font(40, bold=True)
        meta_font   = get_font(13, bold=False)

        draw.text((24, 20), "🚀  Server Boost!", font=header_font, fill=accent)

        av_size = 72
        if avatar_image:
            av = circle_crop(avatar_image, av_size)
            canvas.paste(av, (24, 70), av)
        else:
            draw.ellipse((24, 70, 24 + av_size, 70 + av_size), fill=accent)

        tx = 108
        draw.text((tx, 70),  truncate_text(user_name, 26), font=name_font, fill=colors["text_primary"])
        draw.text((tx, 96),  f"Total personal boosts: {boost_count}", font=sub_font, fill=colors["text_secondary"])
        if role_name:
            draw.text((tx, 118), f"Custom role: {role_name}", font=sub_font, fill=accent)
        draw.text((tx, 142 if role_name else 120),
                  f"Guild boosts: {total_guild_boosts}", font=meta_font, fill=colors["text_secondary"])

        count_str = str(boost_count)
        cb = draw.textbbox((0, 0), count_str, font=big_font)
        cw = cb[2] - cb[0]
        draw.text((self.WIDTH - cw - 30, 70), count_str, font=big_font, fill=accent)
        draw.text((self.WIDTH - cw - 50, 118), "BOOSTS", font=meta_font, fill=colors["text_secondary"])

        return self.to_bytes(canvas)

    # ── 5. Translate card ─────────────────────────────────────────────────────
    async def render_translate_card(
        self,
        original_text: str,
        translated_text: str,
        source_lang: str = "auto",
        target_lang: str = "en",
        requested_by: Optional[str] = None,
        banner_image: Optional[Image.Image] = None,
        theme: str = "dark",
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        accent = _BLUE
        
        body_font   = get_font(15, bold=False)
        label_font  = get_font(16, bold=True)
        header_font = get_font(20, bold=True)
        meta_font   = get_font(13, bold=False)

        dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
        mid = self.WIDTH // 2
        col_w = mid - 48
        orig_lines  = _wrap(dummy_draw, truncate_text(original_text, 400),  body_font, col_w)[:15]
        trans_lines = _wrap(dummy_draw, truncate_text(translated_text, 400), body_font, col_w)[:15]
        max_lines   = max(len(orig_lines), len(trans_lines), 1)

        height = 100 + max_lines * self.LINE_HEIGHT + 40
        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw   = ImageDraw.Draw(canvas)

        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=80, opacity=140, blur=1)

        _draw_accent_bar(draw, height, accent)
        _draw_surface(draw, self.WIDTH, height, colors)

        draw.text((24, 20), "🌐  Translation", font=header_font, fill=accent)
        lang_str = f"{source_lang.upper()} → {target_lang.upper()}"
        lb = draw.textbbox((0, 0), lang_str, font=meta_font)
        draw.text((self.WIDTH - lb[2] - 24, 24), lang_str, font=meta_font, fill=colors["text_secondary"])

        y = 65
        draw.rectangle((mid - 1, y, mid + 1, height - 30), fill=(*colors["bar_empty"], 160))
        draw.text((24, y), "Original", font=label_font, fill=colors["text_secondary"])
        draw.text((mid + 20, y), "Translated", font=label_font, fill=accent)
        y += 30

        by, ay = y, y
        for line in orig_lines:
            draw.text((24, by), line, font=body_font, fill=colors["text_primary"]); by += self.LINE_HEIGHT
        for line in trans_lines:
            draw.text((mid + 20, ay), line, font=body_font, fill=colors["text_primary"]); ay += self.LINE_HEIGHT

        if requested_by:
            rb = draw.textbbox((0, 0), f"— {requested_by}", font=meta_font)
            draw.text((self.WIDTH - rb[2] - 24, height - 25),
                      f"— {requested_by}", font=meta_font, fill=colors["text_secondary"])

        return self.to_bytes(canvas)

    # ── 6. Starboard card ─────────────────────────────────────────────────────
    async def render_starboard_card(
        self,
        author_name: str,
        content: Optional[str] = None,
        score: int = 0,
        reactions_str: Optional[str] = None,
        channel_name: Optional[str] = None,
        jump_url: Optional[str] = None,
        created_at: Optional[datetime] = None,
        avatar_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        attachment_image: Optional[Image.Image] = None,
        theme: str = "dark",
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        accent = _GOLD

        body_font  = get_font(15, bold=False)
        label_font = get_font(16, bold=True)
        meta_font  = get_font(13, bold=False)
        header_font = get_font(20, bold=True)
        score_font  = get_font(32, bold=True)

        dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
        c_lines = _wrap(dummy_draw, truncate_text(content or "", 500), body_font, self.WIDTH - 48)[:15]

        height = 100 + len(c_lines) * self.LINE_HEIGHT + (180 if attachment_image else 0) + 40
        height = max(height, 160)

        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw   = ImageDraw.Draw(canvas)

        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=80, opacity=140, blur=1)

        _draw_accent_bar(draw, height, accent)
        _draw_surface(draw, self.WIDTH, height, colors)

        score_str = str(score)
        sb = draw.textbbox((0, 0), score_str, font=score_font)
        sw = sb[2] - sb[0]
        draw.text((self.WIDTH - sw - 28, 20), score_str, font=score_font, fill=accent)
        if reactions_str:
            rb = draw.textbbox((0, 0), reactions_str, font=meta_font)
            draw.text((self.WIDTH - rb[2] - 28, 62), reactions_str, font=meta_font, fill=colors["text_secondary"])

        av_size = 48
        y = 20
        if avatar_image:
            av = circle_crop(avatar_image, av_size)
            canvas.paste(av, (24, y), av)
        else:
            draw.ellipse((24, y, 24 + av_size, y + av_size), fill=accent)
      
        draw.text((82, y + 4),  truncate_text(author_name, 28), font=label_font, fill=colors["text_primary"])
        ch_str = f"#{channel_name}" if channel_name else ""
        ts_str = _ts(created_at)
        draw.text((82, y + 26), f"{ch_str}  {ts_str}", font=meta_font, fill=colors["text_secondary"])

        y = 80
        for line in c_lines:
            draw.text((24, y), line, font=body_font, fill=colors["text_primary"]); y += self.LINE_HEIGHT

        if attachment_image:
            y += 10
            max_w = self.WIDTH - 48
            ratio = max_w / attachment_image.width
            th = min(int(attachment_image.height * ratio), 160)
            thumb = attachment_image.resize((max_w, th), Image.LANCZOS)
            canvas.paste(thumb, (24, y))

        return self.to_bytes(canvas)

    # ── 7. Alert card ─────────────────────────────────────────────────────────
    async def render_alert_card(
        self,
        alert_type: str,
        title: str,
        content: str,
        user_name: Optional[str] = None,
        avatar_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        severity: str = "INFO",
        theme: str = "dark",
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        sev_map = {"INFO": _BLUE, "WARNING": _ORANGE, "CRITICAL": _RED, "SUCCESS": _GREEN}
        accent = sev_map.get(severity, _BLUE)

        body_font   = get_font(15, bold=False)
        label_font  = get_font(18, bold=True)
        header_font = get_font(22, bold=True)

        dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
        c_lines = _wrap(dummy_draw, truncate_text(content, 600), body_font, self.WIDTH - 60)[:15]

        height = 120 + len(c_lines) * self.LINE_HEIGHT + 20
        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw   = ImageDraw.Draw(canvas)

        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=80, opacity=140, blur=1)

        _draw_accent_bar(draw, height, accent)
        _draw_surface(draw, self.WIDTH, height, colors)

        draw.text((24, 20), title, font=header_font, fill=accent)
        y = 60
        if user_name:
            av_size = 40
            if avatar_image:
                av = circle_crop(avatar_image, av_size)
                canvas.paste(av, (24, y), av)
            else:
                draw.ellipse((24, y, 24 + av_size, y + av_size), fill=accent)
            draw.text((74, y + 8), user_name, font=label_font, fill=colors["text_primary"])
            y += 50

        for line in c_lines:
            draw.text((24, y), line, font=body_font, fill=colors["text_primary"]); y += self.LINE_HEIGHT

        return self.to_bytes(canvas)
