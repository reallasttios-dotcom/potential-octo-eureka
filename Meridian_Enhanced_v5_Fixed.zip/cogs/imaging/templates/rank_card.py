from __future__ import annotations
from typing import Optional
from PIL import Image, ImageDraw
import discord

from .base import BaseTemplate, get_font, circle_crop, draw_rounded_rect, truncate_text


class RankCardTemplate(BaseTemplate):
    """
    User rank / level card template.
    Shows avatar, username, level, XP progress bar, rank position, and badges.
    """

    WIDTH = 900
    HEIGHT = 280

    async def render(
        self,
        user: discord.Member,
        level: int,
        total_xp: int,
        progress_xp: int,
        needed_xp: int,
        rank_pos: int,
        avatar_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        badges: Optional[list] = None,
        theme: str = "dark",
        emoji_images: Optional[list] = None,
        **kwargs  # Handle unexpected arguments like user_avatar, user_banner
    ) -> bytes:
        # Support both avatar_image and user_avatar
        avatar_image = avatar_image or kwargs.get("user_avatar")
        # Support both banner_image and user_banner
        banner_image = banner_image or kwargs.get("user_banner")
        
        self.theme = self._resolve_theme(theme)
        canvas = Image.new("RGBA", (self.WIDTH, self.HEIGHT), self.theme["background"])
        draw = ImageDraw.Draw(canvas)

        # Draw banner background
        if banner_image:
            # Resize and center crop banner to fill the entire card
            banner = banner_image.convert("RGBA")
            aspect_ratio = self.WIDTH / self.HEIGHT
            banner_aspect = banner.width / banner.height
            
            if banner_aspect > aspect_ratio:
                new_width = int(banner.height * aspect_ratio)
                left = (banner.width - new_width) // 2
                banner = banner.crop((left, 0, left + new_width, banner.height))
            else:
                new_height = int(banner.width / aspect_ratio)
                top = (banner.height - new_height) // 2
                banner = banner.crop((0, top, banner.width, top + new_height))
            
            banner = banner.resize((self.WIDTH, self.HEIGHT), Image.LANCZOS)
            
            # Add a dark overlay to ensure text readability
            overlay = Image.new("RGBA", (self.WIDTH, self.HEIGHT), (0, 0, 0, 140))
            banner.alpha_composite(overlay)
            
            # Apply rounded corners to the banner itself
            mask = Image.new("L", (self.WIDTH, self.HEIGHT), 0)
            mask_draw = ImageDraw.Draw(mask)
            mask_draw.rounded_rectangle((0, 0, self.WIDTH, self.HEIGHT), radius=18, fill=255)
            
            canvas.paste(banner, (0, 0), mask)
        else:
            # Fallback to theme background if no banner
            draw_rounded_rect(draw, (0, 0, self.WIDTH, self.HEIGHT), radius=18, fill=self.theme["background"])

        # REMOVED the obstructing surface rectangle here to allow banner to show clearly

        avatar_size = 140
        avatar_x, avatar_y = 50, (self.HEIGHT - avatar_size) // 2
        if avatar_image:
            av = circle_crop(avatar_image, avatar_size)
            canvas.paste(av, (avatar_x, avatar_y), av)
        else:
            draw.ellipse(
                (avatar_x, avatar_y, avatar_x + avatar_size, avatar_y + avatar_size),
                fill=self.theme["accent"]
            )

        text_x = avatar_x + avatar_size + 30
        name_font = get_font(32, bold=True)
        disc_font = get_font(20, bold=False)
        label_font = get_font(18, bold=False)
        val_font = get_font(24, bold=True)
        level_font = get_font(16, bold=True)

        display_name = truncate_text(user.display_name, 24)
        draw.text((text_x, 60), display_name, font=name_font, fill=self.theme["text_primary"])
        
        # Username
        username = f"@{user.name}" if user.discriminator == "0" else f"{user.name}#{user.discriminator}"
        username = truncate_text(username, 18)
        draw.text((text_x, 102), username, font=disc_font, fill=self.theme["text_secondary"])
        
        # Level in a rounded square
        level_text = f"LVL {level}"
        uw = draw.textlength(username, font=disc_font)
        lx = text_x + uw + 15
        ly = 102
        
        # Measure level text
        lw = draw.textlength(level_text, font=level_font)
        lh = 24
        padding_w = 10
        
        # Draw rounded square for level
        draw_rounded_rect(draw, (lx, ly, lx + lw + padding_w * 2, ly + lh), radius=6, fill=self.theme["accent"])
        draw.text((lx + padding_w, ly + 2), level_text, font=level_font, fill=(255, 255, 255))

        bar_x = text_x
        bar_y = 155
        bar_w = self.WIDTH - text_x - 60
        bar_h = 24
        bar_radius = bar_h // 2

        draw.rounded_rectangle(
            (bar_x, bar_y, bar_x + bar_w, bar_y + bar_h),
            radius=bar_radius, fill=self.theme["bar_empty"]
        )
        progress = min(progress_xp / max(needed_xp, 1), 1.0)
        if progress > 0:
            fill_w = max(int(bar_w * progress), bar_radius * 2)
            draw.rounded_rectangle(
                (bar_x, bar_y, bar_x + fill_w, bar_y + bar_h),
                radius=bar_radius, fill=self.theme["bar_fill"]
            )

        # XP Text BELOW bar (requested change)
        xp_text = f"{progress_xp:,} / {needed_xp:,} XP"
        tw = draw.textlength(xp_text, font=label_font)
        draw.text((bar_x + bar_w - tw, bar_y + bar_h + 8), xp_text, font=label_font, fill=self.theme["text_secondary"])

        right_x = self.WIDTH - 60
        # Rank info
        draw.text((right_x - 60, 60), f"Rank", font=label_font, fill=self.theme["text_secondary"])
        draw.text((right_x - 80, 85), f"#{rank_pos}", font=val_font, fill=self.theme["accent"])
        
        # Total XP info
        draw.text((right_x - 60, 125), f"Total", font=label_font, fill=self.theme["text_secondary"])
        draw.text((right_x - 100, 150), f"{total_xp:,} XP", font=val_font, fill=self.theme["text_primary"])

        if badges and emoji_images:
            bx = text_x
            by = bar_y + bar_h + 35
            for i, emoji_img in enumerate(emoji_images[:6]):
                if emoji_img:
                    em = emoji_img.resize((28, 28), Image.LANCZOS)
                    canvas.paste(em, (bx + i * 35, by), em if em.mode == "RGBA" else None)

        return self.to_bytes(canvas)

    def _resolve_theme(self, theme: str) -> dict:
        from .base import THEME_COLORS
        return THEME_COLORS.get(theme, THEME_COLORS["dark"])
