from __future__ import annotations
from typing import Optional, List
from PIL import Image, ImageDraw
import discord
from datetime import datetime

from .base import BaseTemplate, get_font, circle_crop, draw_rounded_rect, truncate_text, THEME_COLORS


class EditTrackingTemplate(BaseTemplate):
    """
    Before | After split card for message edit tracking.
    Intelligently wraps and truncates long messages.
    """

    WIDTH = 900
    MAX_CHARS = 500
    COL_PAD = 24
    LINE_HEIGHT = 22

    async def render(
        self,
        before_content: str,
        after_content: str,
        user: Optional[discord.Member | discord.User] = None,
        channel: Optional[discord.TextChannel] = None,
        avatar_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        theme: str = "dark",
        timestamp: Optional[datetime] = None,
        **kwargs,
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        
        header_font = get_font(22, bold=True)
        label_font  = get_font(17, bold=True)
        body_font   = get_font(15, bold=False)
        meta_font   = get_font(13, bold=False)

        # Pre-wrap text to calculate height
        mid = self.WIDTH // 2
        col_w = mid - self.COL_PAD - 24
        
        # Create a dummy draw object for wrapping
        dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
        before_lines = self._wrap_text(dummy_draw, before_content[:self.MAX_CHARS], body_font, col_w)
        after_lines = self._wrap_text(dummy_draw, after_content[:self.MAX_CHARS], body_font, col_w)
        
        # Limit to 15 lines per side to prevent massive cards
        before_lines = before_lines[:15]
        after_lines = after_lines[:15]
        
        content_height = max(len(before_lines), len(after_lines), 1) * self.LINE_HEIGHT
        header_height = 110 if (user or channel) else 60
        total_height = header_height + content_height + 60
        total_height = max(240, total_height) # Minimum height

        canvas = Image.new("RGBA", (self.WIDTH, total_height), colors["background"])
        draw = ImageDraw.Draw(canvas)

        # Draw banner background using helper
        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=80, opacity=140, blur=1)

        # Left accent bar
        draw.rectangle((0, 0, 5, total_height), fill=(243, 156, 18))
        # Main surface
        draw_rounded_rect(draw, (12, 12, self.WIDTH - 12, total_height - 12),
                          radius=14, fill=(*colors["surface"], 230))

        # Header
        draw.text((24, 20), "✏️  Message Edited", font=header_font, fill=colors["text_primary"])

        ts_str = (timestamp or datetime.utcnow()).strftime("%Y-%m-%d %H:%M UTC")
        bbox = draw.textbbox((0, 0), ts_str, font=meta_font)
        draw.text((self.WIDTH - bbox[2] - 24, 24), ts_str,
                  font=meta_font, fill=colors["text_secondary"])

        y = 56
        if user or channel:
            av_size = 48
            if avatar_image and user:
                av = circle_crop(avatar_image, av_size)
                canvas.paste(av, (24, y), av)
            else:
                draw.ellipse((24, y, 24 + av_size, y + av_size), fill=colors["accent"])
            
            user_str = str(user) if user else "Unknown User"
            channel_str = f" in #{channel.name}" if channel else ""
            draw.text((82, y + 4), truncate_text(user_str, 40), font=label_font, fill=colors["text_primary"])
            draw.text((82, y + 26), truncate_text(f"ID: {user.id if user else 'N/A'}{channel_str}", 60),
                      font=meta_font, fill=colors["text_secondary"])
            y += 70

        # Vertical separator
        draw.rectangle((mid - 1, y, mid + 1, total_height - 30), fill=(*colors["bar_empty"], 180))

        # Before Column
        draw.text((24, y), "Before", font=label_font, fill=(231, 76, 60))
        y_before = y + 30
        for line in before_lines:
            draw.text((24, y_before), line, font=body_font, fill=colors["text_primary"])
            y_before += self.LINE_HEIGHT

        # After Column
        draw.text((mid + self.COL_PAD, y), "After", font=label_font, fill=(46, 204, 113))
        y_after = y + 30
        for line in after_lines:
            draw.text((mid + self.COL_PAD, y_after), line, font=body_font, fill=colors["text_primary"])
            y_after += self.LINE_HEIGHT

        return self.to_bytes(canvas)

    def _wrap_text(self, draw: ImageDraw.Draw, text: str, font, max_width: int) -> List[str]:
        if not text:
            return ["(empty)"]
            
        lines = []
        for paragraph in text.split('\n'):
            words = paragraph.split()
            if not words:
                lines.append("")
                continue
                
            current = ""
            for word in words:
                test = f"{current} {word}".strip()
                bbox = draw.textbbox((0, 0), test, font=font)
                if bbox[2] - bbox[0] <= max_width:
                    current = test
                else:
                    if current:
                        lines.append(current)
                    current = word
            if current:
                lines.append(current)
        return lines
