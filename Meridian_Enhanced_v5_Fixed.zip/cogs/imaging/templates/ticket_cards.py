from __future__ import annotations
from typing import Optional, List
from PIL import Image, ImageDraw
import discord
from datetime import datetime

from .base import BaseTemplate, get_font, circle_crop, draw_rounded_rect, truncate_text, THEME_COLORS

PRIORITY_COLORS = {
    "low":      (46,  204, 113),
    "medium":   (243, 156, 18),
    "high":     (231, 76,  60),
    "critical": (192, 57,  43),
}
STATUS_EMOJIS = {
    "open":    "🟢",
    "closed":  "🔴",
    "pending": "🟡",
    "resolved":"✅",
}


class TicketCardTemplate(BaseTemplate):
    """
    Ticket system card template.
    Shows ticket info, user, status, priority, and staff assignment.
    """

    WIDTH = 860
    LINE_HEIGHT = 26

    async def render(
        self,
        ticket_id: str,
        user: discord.Member | discord.User,
        status: str = "open",
        priority: str = "medium",
        subject: Optional[str] = None,
        assigned_staff: Optional[discord.Member] = None,
        opened_at: Optional[datetime] = None,
        fields: Optional[List[tuple]] = None,
        user_avatar: Optional[Image.Image] = None,
        avatar_image: Optional[Image.Image] = None,
        target_avatar: Optional[Image.Image] = None,
        staff_avatar: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        theme: str = "dark",
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        priority_color = PRIORITY_COLORS.get(priority.lower(), (114, 137, 218))
        
        header_font = get_font(22, bold=True)
        label_font  = get_font(15, bold=True)
        val_font    = get_font(15, bold=False)
        meta_font   = get_font(13, bold=False)

        # Calculate total height
        height = 100 # Header + Padding
        height += 65 # User
        if assigned_staff: height += 65
        if subject: height += 30
        height += 30 # Priority/Status
        if fields: height += 20 + len(fields) * self.LINE_HEIGHT
        height = max(height, 240)

        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw = ImageDraw.Draw(canvas)

        # Draw banner background using helper
        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=100, opacity=140, blur=1)

        draw.rectangle((0, 0, 6, height), fill=priority_color)
        draw_rounded_rect(draw, (12, 12, self.WIDTH - 12, height - 12),
                          radius=14, fill=(*colors["surface"], 230))

        status_emoji = STATUS_EMOJIS.get(status.lower(), "🎫")
        draw.text((24, 20), f"{status_emoji}  Ticket #{ticket_id}", font=header_font, fill=colors["text_primary"])

        if opened_at:
            ts_str = opened_at.strftime("%Y-%m-%d %H:%M UTC")
            bbox = draw.textbbox((0, 0), ts_str, font=meta_font)
            draw.text((self.WIDTH - bbox[2] - 24, 24), ts_str, font=meta_font, fill=colors["text_secondary"])

        y = 65
        av_size = 48
        # Use user_avatar, target_avatar, or avatar_image (fallback)
        effective_avatar = user_avatar or target_avatar or avatar_image
        if effective_avatar:
            av = circle_crop(effective_avatar, av_size)
            canvas.paste(av, (24, y), av)
        else:
            draw.ellipse((24, y, 24 + av_size, y + av_size), fill=colors["accent"])
        draw.text((82, y + 4), "Opened by:", font=label_font, fill=colors["text_secondary"])
        draw.text((82, y + 24), truncate_text(str(user), 30), font=val_font, fill=colors["text_primary"])
        y += 65

        if assigned_staff:
            if staff_avatar:
                av = circle_crop(staff_avatar, av_size)
                canvas.paste(av, (24, y), av)
            else:
                draw.ellipse((24, y, 24 + av_size, y + av_size), fill=(114, 137, 218))
            draw.text((82, y + 4), "Assigned to:", font=label_font, fill=colors["text_secondary"])
            draw.text((82, y + 24), truncate_text(str(assigned_staff), 30), font=val_font, fill=colors["text_primary"])
            y += 65

        if subject:
            draw.text((24, y), "Subject:", font=label_font, fill=colors["text_secondary"])
            draw.text((140, y), truncate_text(subject, 60), font=val_font, fill=colors["text_primary"])
            y += 30

        priority_str = priority.upper()
        draw.text((24, y), "Priority:", font=label_font, fill=colors["text_secondary"])
        draw.text((140, y), priority_str, font=val_font, fill=priority_color)
        draw.text((300, y), "Status:", font=label_font, fill=colors["text_secondary"])
        draw.text((400, y), status.title(), font=val_font, fill=colors["text_primary"])
        y += 30

        if fields:
            draw.line((24, y, self.WIDTH - 24, y), fill=(*colors["bar_empty"], 160), width=1)
            y += 12
            for field_name, field_value in fields:
                draw.text((24, y), f"{field_name}:", font=label_font, fill=colors["text_secondary"])
                draw.text((200, y), truncate_text(str(field_value), 55), font=val_font, fill=colors["text_primary"])
                y += self.LINE_HEIGHT

        return self.to_bytes(canvas)
