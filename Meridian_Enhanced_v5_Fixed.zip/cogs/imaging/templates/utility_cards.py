from __future__ import annotations
from typing import Optional, List
from PIL import Image, ImageDraw
import discord
from datetime import datetime

from .base import BaseTemplate, get_font, circle_crop, draw_rounded_rect, truncate_text, THEME_COLORS


class UtilityCardTemplate(BaseTemplate):
    """
    Card template for utility commands: userinfo, serverinfo, etc.
    """

    WIDTH = 900

    async def render_userinfo(
        self,
        user: discord.Member | discord.User,
        fields: List[tuple],
        avatar_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        theme: str = "dark",
        emoji_images: Optional[dict] = None,
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        height = 100 + max(len(fields) * 28, 80) + 40
        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw = ImageDraw.Draw(canvas)

        # Draw banner background using helper
        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=100, opacity=140, blur=1)

        draw_rounded_rect(draw, (12, 12, self.WIDTH - 12, height - 12),
                          radius=14, fill=(*colors["surface"], 200))

        av_size = 80
        if avatar_image:
            av = circle_crop(avatar_image, av_size)
            canvas.paste(av, (24, 20), av)
        else:
            draw.ellipse((24, 20, 24 + av_size, 20 + av_size), fill=colors["accent"])

        header_font = get_font(24, bold=True)
        label_font  = get_font(15, bold=True)
        val_font    = get_font(15, bold=False)

        name_str = truncate_text(str(user), 30)
        draw.text((120, 28), name_str, font=header_font, fill=colors["text_primary"])
        draw.text((120, 58), f"ID: {user.id}", font=val_font, fill=colors["text_secondary"])

        y = 116
        for field_name, field_value in fields:
            draw.text((24, y), f"{field_name}:", font=label_font, fill=colors["text_secondary"])
            draw.text((200, y), truncate_text(str(field_value), 60), font=val_font, fill=colors["text_primary"])
            y += 28

        return self.to_bytes(canvas)

    async def render_serverinfo(
        self,
        guild: discord.Guild,
        fields: List[tuple],
        icon_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        theme: str = "dark",
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        height = 100 + len(fields) * 28 + 40
        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw = ImageDraw.Draw(canvas)

        # Draw banner background using helper
        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=100, opacity=140, blur=1)

        draw_rounded_rect(draw, (12, 12, self.WIDTH - 12, height - 12),
                          radius=14, fill=(*colors["surface"], 200))

        icon_size = 80
        if icon_image:
            icon = circle_crop(icon_image, icon_size)
            canvas.paste(icon, (24, 20), icon)
        else:
            draw.ellipse((24, 20, 24 + icon_size, 20 + icon_size), fill=colors["accent"])

        header_font = get_font(24, bold=True)
        label_font  = get_font(15, bold=True)
        val_font    = get_font(15, bold=False)

        draw.text((120, 28), truncate_text(guild.name, 30), font=header_font, fill=colors["text_primary"])
        draw.text((120, 58), f"ID: {guild.id}", font=val_font, fill=colors["text_secondary"])

        y = 116
        for field_name, field_value in fields:
            draw.text((24, y), f"{field_name}:", font=label_font, fill=colors["text_secondary"])
            draw.text((200, y), truncate_text(str(field_value), 60), font=val_font, fill=colors["text_primary"])
            y += 28

        return self.to_bytes(canvas)
