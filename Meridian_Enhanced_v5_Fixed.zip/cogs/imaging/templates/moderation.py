from __future__ import annotations
from typing import Optional, List
from PIL import Image, ImageDraw
import discord
from datetime import datetime

from .base import BaseTemplate, get_font, circle_crop, draw_rounded_rect, truncate_text, THEME_COLORS

ACTION_COLORS = {
    "ban":    (231, 76,  60),
    "kick":   (230, 126, 34),
    "mute":   (52,  152, 219),
    "unmute": (46,  204, 113),
    "warn":   (243, 156, 18),
    "unban":  (46,  204, 113),
    "softban":(192, 57,  43),
    "timeout":(155, 89,  182),
}
ACTION_EMOJIS = {
    "ban": "🔨", "kick": "👢", "mute": "🔇", "unmute": "🔊",
    "warn": "⚠️", "unban": "✅", "softban": "💥", "timeout": "⏱️",
}


class ModerationTemplate(BaseTemplate):
    """
    Moderation action card template.
    Shows the user, moderator, action, reason, and optional evidence.
    """

    WIDTH = 860
    LINE_HEIGHT = 22

    async def render(
        self,
        action: str,
        target: discord.Member | discord.User,
        moderator: discord.Member | discord.User,
        reason: str = "No reason provided",
        duration: Optional[str] = None,
        case_id: Optional[str] = None,
        target_avatar: Optional[Image.Image] = None,
        mod_avatar: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        evidence_image: Optional[Image.Image] = None,
        theme: str = "dark",
        timestamp: Optional[datetime] = None,
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        action_color = ACTION_COLORS.get(action.lower(), (114, 137, 218))
        
        header_font = get_font(26, bold=True)
        label_font  = get_font(16, bold=True)
        val_font    = get_font(16, bold=False)
        meta_font   = get_font(13, bold=False)

        # Pre-wrap reason to calculate height
        dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
        reason_lines = self._wrap_text(dummy_draw, truncate_text(reason, 500), val_font, self.WIDTH - 48)
        reason_lines = reason_lines[:10] # Limit lines

        # Calculate total height
        height = 240 # Header + Users + Padding
        height += len(reason_lines) * self.LINE_HEIGHT
        if duration: height += 30
        if evidence_image: height += 200
        height = max(height, 300)

        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw = ImageDraw.Draw(canvas)

        # Draw banner background using helper
        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=120, opacity=140, blur=1)

        draw.rectangle((0, 0, 6, height), fill=action_color)
        draw_rounded_rect(draw, (12, 12, self.WIDTH - 12, height - 12),
                          radius=14, fill=(*colors["surface"], 230))

        action_emoji = ACTION_EMOJIS.get(action.lower(), "🛡️")
        label_str = f"{action_emoji}  {action.upper()}"
        draw.text((24, 22), label_str, font=header_font, fill=action_color)

        if case_id:
            draw.text((self.WIDTH - 160, 26), f"Case #{case_id}", font=meta_font, fill=colors["text_secondary"])

        ts_str = (timestamp or datetime.utcnow()).strftime("%Y-%m-%d %H:%M UTC")
        bbox = draw.textbbox((0, 0), ts_str, font=meta_font)
        draw.text((self.WIDTH - bbox[2] - 24, 46), ts_str, font=meta_font, fill=colors["text_secondary"])

        y = 70
        for label, user, av_img in [("Target", target, target_avatar), ("Moderator", moderator, mod_avatar)]:
            av_size = 52
            if av_img:
                av = circle_crop(av_img, av_size)
                canvas.paste(av, (24, y), av)
            else:
                draw.ellipse((24, y, 24 + av_size, y + av_size), fill=action_color)

            draw.text((86, y + 2), label, font=label_font, fill=colors["text_secondary"])
            draw.text((86, y + 22), truncate_text(str(user), 30), font=val_font, fill=colors["text_primary"])
            draw.text((86, y + 42), f"ID: {user.id}", font=meta_font, fill=colors["text_secondary"])
            y += 72

        draw.line((24, y, self.WIDTH - 24, y), fill=(*colors["bar_empty"], 180), width=1)
        y += 14

        draw.text((24, y), "Reason:", font=label_font, fill=colors["text_secondary"])
        y += 24
        for line in reason_lines:
            draw.text((24, y), line, font=val_font, fill=colors["text_primary"])
            y += self.LINE_HEIGHT

        if duration:
            y += 10
            draw.text((24, y), f"Duration: {duration}", font=label_font, fill=colors["accent"])
            y += 28

        if evidence_image:
            y += 10
            max_w = self.WIDTH - 48
            ratio = max_w / evidence_image.width
            th = min(int(evidence_image.height * ratio), 180)
            thumb = evidence_image.resize((max_w, th), Image.LANCZOS)
            canvas.paste(thumb, (24, y))

        return self.to_bytes(canvas)

    def _wrap_text(self, draw: ImageDraw.Draw, text: str, font, max_width: int) -> List[str]:
        if not text: return []
        lines = []
        for paragraph in text.split('\n'):
            words = paragraph.split()
            if not words:
                lines.append("")
                continue
            current = ""
            for word in words:
                test = f"{current} {word}".strip()
                bbox = draw.textbbox((0, 0), test, font=font)
                if bbox[2] - bbox[0] <= max_width:
                    current = test
                else:
                    if current:
                        lines.append(current)
                    current = word
            if current:
                lines.append(current)
        return lines
