from __future__ import annotations
from typing import Optional, List
from PIL import Image, ImageDraw
import discord

from .base import BaseTemplate, get_font, circle_crop, draw_rounded_rect, truncate_text, THEME_COLORS


MILESTONES = {5: "🌱", 10: "⭐", 20: "💫", 35: "🔥", 50: "👑", 75: "🏆", 100: "🌟"}


class LevelingCardTemplate(BaseTemplate):
    """
    Leveling system card: level-up announcements, progress cards, and milestone cards.
    """

    WIDTH = 900
    HEIGHT = 280

    async def render_levelup(
        self,
        user: discord.Member,
        new_level: int,
        total_xp: Optional[int] = 0,
        role_reward: Optional[discord.Role] = None,
        avatar_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        theme: str = "dark",
        **kwargs
    ) -> bytes:
        # Support both avatar_image and user_avatar
        avatar_image = avatar_image or kwargs.get("user_avatar")
        # Support both banner_image and user_banner
        banner_image = banner_image or kwargs.get("user_banner")
        
        self.theme = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        canvas = Image.new("RGBA", (self.WIDTH, self.HEIGHT), self.theme["background"])
        draw = ImageDraw.Draw(canvas)

        # Draw banner background
        if banner_image:
            # Resize and center crop banner to fill the entire card
            banner = banner_image.convert("RGBA")
            aspect_ratio = self.WIDTH / self.HEIGHT
            banner_aspect = banner.width / banner.height
            
            if banner_aspect > aspect_ratio:
                new_width = int(banner.height * aspect_ratio)
                left = (banner.width - new_width) // 2
                banner = banner.crop((left, 0, left + new_width, banner.height))
            else:
                new_height = int(banner.width / aspect_ratio)
                top = (banner.height - new_height) // 2
                banner = banner.crop((0, top, banner.width, top + new_height))
            
            banner = banner.resize((self.WIDTH, self.HEIGHT), Image.LANCZOS)
            
            # Add a dark overlay to ensure text readability
            overlay = Image.new("RGBA", (self.WIDTH, self.HEIGHT), (0, 0, 0, 140))
            banner.alpha_composite(overlay)
            
            # Apply rounded corners to the banner itself
            mask = Image.new("L", (self.WIDTH, self.HEIGHT), 0)
            mask_draw = ImageDraw.Draw(mask)
            mask_draw.rounded_rectangle((0, 0, self.WIDTH, self.HEIGHT), radius=18, fill=255)
            
            canvas.paste(banner, (0, 0), mask)
        else:
            # Fallback to theme background if no banner
            draw_rounded_rect(draw, (0, 0, self.WIDTH, self.HEIGHT), radius=18, fill=self.theme["background"])

        # REMOVED the obstructing surface rectangle here to allow banner to show clearly

        # Avatar
        avatar_size = 140
        avatar_x, avatar_y = 50, (self.HEIGHT - avatar_size) // 2
        if avatar_image:
            av = circle_crop(avatar_image, avatar_size)
            canvas.paste(av, (avatar_x, avatar_y), av)
        else:
            draw.ellipse(
                (avatar_x, avatar_y, avatar_x + avatar_size, avatar_y + avatar_size),
                fill=self.theme["accent"]
            )

        # Fonts
        header_font = get_font(34, bold=True)
        name_font   = get_font(28, bold=True)
        sub_font    = get_font(20, bold=False)
        level_font  = get_font(60, bold=True)
        label_font  = get_font(18, bold=False)

        text_x = avatar_x + avatar_size + 30
        
        # Level Up Header
        milestone = MILESTONES.get(new_level, "")
        header_text = f"Level Up! {milestone}".strip()
        draw.text((text_x, 60), header_text, font=header_font, fill=self.theme["accent"])
        
        # User Display Name
        display_name = truncate_text(user.display_name, 20)
        draw.text((text_x, 110), display_name, font=name_font, fill=self.theme["text_primary"])
        
        # Total XP or Role Reward
        if role_reward:
            reward_text = f"🎉 Earned: {role_reward.name}"
            draw.text((text_x, 155), reward_text, font=sub_font, fill=self.theme["success"] if "success" in self.theme else (75, 181, 67))
        elif total_xp:
            xp_text = f"Total XP: {total_xp:,}"
            draw.text((text_x, 155), xp_text, font=label_font, fill=self.theme["text_secondary"])

        # Large Level Number on the right
        level_str = str(new_level)
        lw = draw.textlength(level_str, font=level_font)
        level_x = self.WIDTH - lw - 60
        draw.text((level_x, 80), level_str, font=level_font, fill=self.theme["accent"])
        
        # "LEVEL" label below the number
        label_text = "LEVEL"
        label_w = draw.textlength(label_text, font=label_font)
        draw.text((level_x + (lw - label_w) / 2, 150), label_text, font=label_font, fill=self.theme["text_secondary"])

        return self.to_bytes(canvas)

    async def render_xp_progress(
        self,
        user: discord.Member,
        level: int,
        progress_xp: int,
        needed_xp: int,
        streak_days: int = 0,
        avatar_image: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        theme: str = "dark",
        **kwargs
    ) -> bytes:
        from .rank_card import RankCardTemplate
        template = RankCardTemplate()
        return await template.render(
            user=user,
            level=level,
            total_xp=progress_xp, # Approximation
            progress_xp=progress_xp,
            needed_xp=needed_xp,
            rank_pos=0,
            avatar_image=avatar_image,
            banner_image=banner_image,
            theme=theme,
            **kwargs
        )
