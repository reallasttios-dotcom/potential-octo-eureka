from __future__ import annotations
from typing import Optional, List
from PIL import Image, ImageDraw
import discord
from datetime import datetime

from .base import BaseTemplate, get_font, circle_crop, draw_rounded_rect, truncate_text, THEME_COLORS

SEVERITY_COLORS = {
    "INFO":    (52, 152, 219),
    "WARNING": (243, 156, 18),
    "CRITICAL":(231, 76,  60),
    "SUCCESS": (46, 204, 113),
}

EVENT_LABELS = {
    "message_edit":   "✏️  Message Edited",
    "message_delete": "🗑️  Message Deleted",
    "member_join":    "📥  Member Joined",
    "member_leave":   "📤  Member Left",
    "member_ban":     "🔨  Member Banned",
    "member_unban":   "✅  Member Unbanned",
    "member_kick":    "👢  Member Kicked",
    "role_add":       "🏷️  Role Added",
    "role_remove":    "🏷️  Role Removed",
    "channel_create": "📁  Channel Created",
    "channel_delete": "📁  Channel Deleted",
    "voice_join":     "🔊  Voice Joined",
    "voice_leave":    "🔇  Voice Left",
}


class LoggingCardTemplate(BaseTemplate):
    """
    Card template for all server logging events.
    Includes message content, user information, and optional attachments.
    """

    WIDTH = 860
    MAX_CONTENT = 500
    LINE_HEIGHT = 22

    async def render(
        self,
        event_type: str,
        user: Optional[discord.Member | discord.User] = None,
        channel: Optional[discord.TextChannel] = None,
        content: Optional[str] = None,
        extra_fields: Optional[List[tuple]] = None,
        severity: str = "INFO",
        avatar_image: Optional[Image.Image] = None,
        attachment_image: Optional[Image.Image] = None,
        perpetrator: Optional[discord.Member | discord.User] = None,
        perpetrator_avatar: Optional[Image.Image] = None,
        banner_image: Optional[Image.Image] = None,
        theme: str = "dark",
        timestamp: Optional[datetime] = None,
        **kwargs,
    ) -> bytes:
        colors = THEME_COLORS.get(theme, THEME_COLORS["dark"])
        sev_color = SEVERITY_COLORS.get(severity, SEVERITY_COLORS["INFO"])
        
        header_font = get_font(22, bold=True)
        label_font  = get_font(16, bold=True)
        val_font    = get_font(16, bold=False)
        time_font   = get_font(13, bold=False)
        meta_font   = get_font(13, bold=False)
        content_font = get_font(15, bold=False)

        # Pre-wrap content to calculate height
        dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
        content_lines = []
        if content:
            content_lines = self._wrap_text(dummy_draw, truncate_text(content, self.MAX_CONTENT), content_font, self.WIDTH - 48)
            content_lines = content_lines[:15] # Limit lines

        # Calculate total height
        height = 100 # Header + padding
        if user: height += 70
        if perpetrator and perpetrator.id != (user.id if user else None):
            height += 40 # Extra space for attribution line
        if channel: height += 30
        if content_lines: height += 30 + len(content_lines) * self.LINE_HEIGHT
        if extra_fields: height += len(extra_fields) * 28
        if attachment_image: height += 220
        height = max(height, 160)

        canvas = Image.new("RGBA", (self.WIDTH, height), colors["background"])
        draw = ImageDraw.Draw(canvas)

        # Draw banner background using helper
        if banner_image:
            self.draw_banner_background(canvas, banner_image, height=80, opacity=140, blur=1)

        draw.rectangle((0, 0, 5, height), fill=sev_color)
        draw_rounded_rect(draw, (12, 12, self.WIDTH - 12, height - 12),
                          radius=14, fill=(*colors["surface"], 230))

        label = EVENT_LABELS.get(event_type, f"📋  {event_type.replace('_', ' ').title()}")
        draw.text((24, 22), label, font=header_font, fill=colors["text_primary"])

        ts_str = (timestamp or datetime.utcnow()).strftime("%Y-%m-%d %H:%M UTC")
        bbox = draw.textbbox((0, 0), ts_str, font=time_font)
        tw = bbox[2] - bbox[0]
        draw.text((self.WIDTH - 24 - tw, 26), ts_str, font=time_font, fill=colors["text_secondary"])

        y = 65
        if user:
            av_size = 48
            if avatar_image:
                av = circle_crop(avatar_image, av_size)
                canvas.paste(av, (24, y), av)
            else:
                draw.ellipse((24, y, 24 + av_size, y + av_size), fill=colors["accent"])

            draw.text((82, y + 4), truncate_text(str(user), 32),
                      font=label_font, fill=colors["text_primary"])
            draw.text((82, y + 26), f"ID: {user.id}", font=val_font, fill=colors["text_secondary"])
            
            y += 65

            # "@user did that" system - Attribution line
            if perpetrator and perpetrator.id != user.id:
                action_verb = "performed"
                if event_type == "message_delete": action_verb = "deleted"
                elif event_type == "role_remove": action_verb = "removed"
                elif event_type == "member_ban": action_verb = "banned"
                elif event_type == "member_kick": action_verb = "kicked"
                elif event_type == "member_unban": action_verb = "unbanned"
                
                target_label = "Action on"
                if event_type.startswith("message_"): target_label = "Message by"
                elif event_type.startswith("role_"): target_label = "Role from"
                elif event_type.startswith("member_"): target_label = "Member"

                attribution_text = f"{target_label} @{user.name} {action_verb} by @{perpetrator.name}"
                draw.text((24, y), attribution_text, font=meta_font, fill=sev_color)
                y += 30

        if channel:
            draw.text((24, y), f"Channel: #{channel.name}", font=val_font, fill=colors["text_secondary"])
            y += 30

        if content_lines:
            draw.text((24, y), "Content:", font=label_font, fill=colors["text_secondary"])
            y += 24
            for line in content_lines:
                draw.text((24, y), line, font=content_font, fill=colors["text_primary"])
                y += self.LINE_HEIGHT
            y += 10

        if extra_fields:
            for field_name, field_value in extra_fields:
                draw.text((24, y), f"{field_name}:", font=label_font, fill=colors["text_secondary"])
                val_str = truncate_text(str(field_value), 80)
                draw.text((160, y), val_str, font=val_font, fill=colors["text_primary"])
                y += 28

        if attachment_image:
            y += 10
            max_w = self.WIDTH - 48
            ratio = max_w / attachment_image.width
            thumb_h = min(int(attachment_image.height * ratio), 200)
            thumb = attachment_image.resize((max_w, thumb_h), Image.LANCZOS)
            canvas.paste(thumb, (24, y))

        return self.to_bytes(canvas)

    def _wrap_text(self, draw: ImageDraw.Draw, text: str, font, max_width: int) -> List[str]:
        if not text: return []
        lines = []
        for paragraph in text.split('\n'):
            words = paragraph.split()
            if not words:
                lines.append("")
                continue
            current = ""
            for word in words:
                test = f"{current} {word}".strip()
                bbox = draw.textbbox((0, 0), test, font=font)
                if bbox[2] - bbox[0] <= max_width:
                    current = test
                else:
                    if current:
                        lines.append(current)
                    current = word
            if current:
                lines.append(current)
        return lines
