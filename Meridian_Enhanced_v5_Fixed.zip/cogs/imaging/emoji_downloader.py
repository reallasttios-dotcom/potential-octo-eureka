import asyncio
import aiohttp
from io import BytesIO
from PIL import Image
from typing import Optional, Dict
import discord

from .cache import ImageCache


UNICODE_EMOJI_CDN = "https://cdn.jsdelivr.net/npm/twemoji@latest/assets/72x72/{codepoint}.png"


class EmojiDownloader:
    """
    Downloads, converts, caches, and resizes emojis for card integration.
    Supports custom Discord emojis and standard Unicode (Twemoji) emojis.
    """

    EMOJI_CDN = "https://cdn.discordapp.com/emojis/{emoji_id}.{ext}?quality=lossless&size=64"

    def __init__(self):
        self._cache = ImageCache(max_size=512, default_ttl=3600)
        self._lock = asyncio.Lock()

    async def get_emoji_image(
        self,
        emoji: Optional[discord.PartialEmoji | discord.Emoji | str],
        size: int = 32,
        static: bool = True,
    ) -> Optional[Image.Image]:
        """
        Retrieve a PIL Image for a given emoji.
        Handles custom Discord emojis and unicode emojis via Twemoji.
        """
        if emoji is None:
            return None

        if isinstance(emoji, str):
            return await self._get_unicode_emoji(emoji, size)

        if isinstance(emoji, (discord.PartialEmoji, discord.Emoji)):
            return await self._get_custom_emoji(emoji, size, static)

        return None

    async def _get_custom_emoji(
        self,
        emoji: discord.PartialEmoji | discord.Emoji,
        size: int,
        static: bool,
    ) -> Optional[Image.Image]:
        emoji_id = emoji.id
        animated = emoji.animated and not static
        ext = "gif" if animated else "png"
        key = self._cache.emoji_key(emoji_id, animated=animated)
        cached = await self._cache.get(key)
        if cached:
            return self._resize(Image.open(BytesIO(cached)).convert("RGBA"), size)

        url = self.EMOJI_CDN.format(emoji_id=emoji_id, ext=ext)
        img = await self._download(url)
        if img is None and animated:
            url = self.EMOJI_CDN.format(emoji_id=emoji_id, ext="png")
            img = await self._download(url)

        if img:
            out = BytesIO()
            img.save(out, format="PNG")
            await self._cache.set(key, out.getvalue())
            return self._resize(img, size)

        return None

    async def _get_unicode_emoji(self, char: str, size: int) -> Optional[Image.Image]:
        codepoints = "-".join(f"{ord(c):x}" for c in char if ord(c) != 0xFE0F)
        url = UNICODE_EMOJI_CDN.format(codepoint=codepoints)
        key = self._cache._make_key("unicode", codepoints, size)
        cached = await self._cache.get(key)
        if cached:
            return self._resize(Image.open(BytesIO(cached)).convert("RGBA"), size)

        img = await self._download(url)
        if img:
            out = BytesIO()
            img.save(out, format="PNG")
            await self._cache.set(key, out.getvalue())
            return self._resize(img, size)

        return None

    async def _download(self, url: str) -> Optional[Image.Image]:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=8)) as resp:
                    if resp.status == 200:
                        data = await resp.read()
                        return Image.open(BytesIO(data)).convert("RGBA")
        except Exception:
            pass
        return None

    def _resize(self, img: Image.Image, size: int) -> Image.Image:
        return img.resize((size, size), Image.LANCZOS)

    async def get_emoji_string_image(
        self,
        emoji_string: str,
        size: int = 32,
        emoji_handler=None,
    ) -> Optional[Image.Image]:
        """
        Parse an emoji string (like <:name:id> or <a:name:id>) from emojihandler
        and return a PIL Image.
        """
        import re
        match = re.match(r"<(a?):(\w+):(\d+)>", emoji_string)
        if match:
            animated = match.group(1) == "a"
            emoji_id = int(match.group(3))
            partial = discord.PartialEmoji(name=match.group(2), id=emoji_id, animated=animated)
            return await self._get_custom_emoji(partial, size, static=not animated)

        if len(emoji_string) <= 4:
            return await self._get_unicode_emoji(emoji_string, size)

        return None

    async def paste_emoji(
        self,
        canvas: Image.Image,
        emoji: Optional[discord.PartialEmoji | discord.Emoji | str],
        pos: tuple,
        size: int = 24,
        static: bool = True,
    ) -> Image.Image:
        """Download emoji and paste it at pos on canvas."""
        img = await self.get_emoji_image(emoji, size=size, static=static)
        if img is None:
            return canvas
        canvas = canvas.copy()
        if img.mode == "RGBA":
            canvas.paste(img, pos, img)
        else:
            canvas.paste(img, pos)
        return canvas
