from __future__ import annotations
import asyncio
import time
from io import BytesIO
from typing import Any, Optional, Dict, Callable, Awaitable
from PIL import Image
import discord

from .cache import AvatarBannerCache, ImageCache
from .emoji_downloader import EmojiDownloader
from .templates.rank_card import RankCardTemplate
from .templates.leaderboard import LeaderboardTemplate, LeaderboardEntry
from .templates.logging_card import LoggingCardTemplate
from .templates.edit_tracking import EditTrackingTemplate
from .templates.moderation import ModerationTemplate
from .templates.utility_cards import UtilityCardTemplate
from .templates.leveling_cards import LevelingCardTemplate
from .templates.ticket_cards import TicketCardTemplate
from .templates.verification_cards import VerificationCardTemplate
from .templates.general import GeneralTemplate


class RenderRequest:
    """Represents a queued image render request."""
    __slots__ = ("template", "kwargs", "priority", "future", "created_at")

    PRIORITY_HIGH = 0
    PRIORITY_NORMAL = 5
    PRIORITY_LOW = 10

    def __init__(self, template: str, kwargs: dict, priority: int = PRIORITY_NORMAL):
        self.template = template
        self.kwargs = kwargs
        self.priority = priority
        self.future: asyncio.Future = asyncio.get_event_loop().create_future()
        self.created_at = time.monotonic()

    def __lt__(self, other: "RenderRequest") -> bool:
        return self.priority < other.priority


class ImageRenderer:
    """
    Main image processing engine.
    """

    MAX_CONCURRENT = 4
    QUEUE_TIMEOUT = 30.0
    RATE_LIMIT_PER_USER = 5
    RATE_LIMIT_WINDOW = 10.0

    def __init__(self, bot: discord.ext.commands.Bot, emoji_manager=None):
        self.bot = bot
        self.emoji_manager = emoji_manager

        self._avatar_cache = AvatarBannerCache()
        self._render_cache = ImageCache(max_size=128, default_ttl=120)
        self._emoji_dl = EmojiDownloader()

        self._queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._semaphore = asyncio.Semaphore(self.MAX_CONCURRENT)
        self._worker_task: Optional[asyncio.Task] = None

        self._rate_limits: Dict[int, list] = {}

        self._templates: Dict[str, Any] = {
            "rank_card":    RankCardTemplate,
            "leaderboard":  LeaderboardTemplate,
            "logging_card": LoggingCardTemplate,
            "edit_tracking":EditTrackingTemplate,
            "moderation":   ModerationTemplate,
            "userinfo":     UtilityCardTemplate,
            "serverinfo":   UtilityCardTemplate,
            "leveling":     LevelingCardTemplate,
            "levelup":      LevelingCardTemplate,
            "ticket":       TicketCardTemplate,
            "verification": VerificationCardTemplate,
            "general":      GeneralTemplate,
        }

        HIGH_PRIORITY_TEMPLATES = {"moderation", "logging_card", "edit_tracking"}
        self._high_priority = HIGH_PRIORITY_TEMPLATES

    def start(self):
        """Start the background queue worker."""
        if self._worker_task is None or self._worker_task.done():
            self._worker_task = asyncio.get_event_loop().create_task(self._worker())

    async def stop(self):
        """Stop the background queue worker."""
        if self._worker_task and not self._worker_task.done():
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass

    def _check_rate_limit(self, user_id: int) -> bool:
        """Returns True if the user is within rate limit, False if exceeded."""
        now = time.monotonic()
        history = self._rate_limits.get(user_id, [])
        history = [t for t in history if now - t < self.RATE_LIMIT_WINDOW]
        self._rate_limits[user_id] = history
        if len(history) >= self.RATE_LIMIT_PER_USER:
            return False
        history.append(now)
        self._rate_limits[user_id] = history
        return True

    async def render(
        self,
        template_name: str,
        priority: Optional[int] = None,
        user_id: Optional[int] = None,
        **kwargs,
    ) -> bytes:
        if template_name not in self._templates:
            raise ValueError(f"Unknown template: {template_name!r}. Available: {list(self._templates)}")

        if user_id and not self._check_rate_limit(user_id):
            raise RuntimeError(f"Rate limit exceeded for user {user_id}")

        if priority is None:
            priority = (RenderRequest.PRIORITY_HIGH
                        if template_name in self._high_priority
                        else RenderRequest.PRIORITY_NORMAL)

        request = RenderRequest(template_name, kwargs, priority)
        await self._queue.put((priority, request))
        self.start()

        try:
            result = await asyncio.wait_for(request.future, timeout=self.QUEUE_TIMEOUT)
            return result
        except asyncio.TimeoutError:
            raise asyncio.TimeoutError(f"Render timed out for template {template_name!r}")

    async def _worker(self):
        while True:
            try:
                _, request = await self._queue.get()
                asyncio.get_event_loop().create_task(self._process(request))
            except asyncio.CancelledError:
                break
            except Exception:
                pass

    async def _process(self, request: RenderRequest):
        async with self._semaphore:
            try:
                result = await self._dispatch(request.template, request.kwargs)
                request.future.set_result(result)
            except Exception as exc:
                if not request.future.done():
                    request.future.set_exception(exc)

    async def _dispatch(self, template_name: str, kwargs: dict) -> bytes:
        template_cls = self._templates[template_name]
        theme = kwargs.pop("theme", "dark")
        instance = template_cls(theme=theme)

        await self._resolve_images(kwargs)

        if template_name == "rank_card":
            return await instance.render(**kwargs, theme=theme)
        elif template_name == "leaderboard":
            return await instance.render(**kwargs, theme=theme)
        elif template_name == "logging_card":
            return await instance.render(**kwargs, theme=theme)
        elif template_name == "edit_tracking":
            return await instance.render(**kwargs, theme=theme)
        elif template_name == "moderation":
            return await instance.render(**kwargs, theme=theme)
        elif template_name == "userinfo":
            return await instance.render_userinfo(**kwargs, theme=theme)
        elif template_name == "serverinfo":
            return await instance.render_serverinfo(**kwargs, theme=theme)
        elif template_name == "levelup":
            return await instance.render_levelup(**kwargs, theme=theme)
        elif template_name == "leveling":
            return await instance.render_xp_progress(**kwargs, theme=theme)
        elif template_name == "ticket":
            return await instance.render(**kwargs, theme=theme)
        elif template_name == "verification":
            return await instance.render(**kwargs, theme=theme)
        elif template_name == "general":
            card_type = kwargs.pop("card_type", None)
            if card_type is None:
                raise ValueError("general template requires a 'card_type' keyword argument")
            return await instance.render(card_type=card_type, **kwargs, theme=theme)
        else:
            raise ValueError(f"No dispatch handler for template: {template_name!r}")

    async def _resolve_images(self, kwargs: dict) -> None:
        """
        Pre-fetch avatar/banner images for any discord.Member/User objects in kwargs.
        """
        tasks = []

        # 1. Main User / Target
        user = kwargs.get("user") or kwargs.get("target")
        if isinstance(user, (discord.Member, discord.User)):
            # Standard names
            if "avatar_image" not in kwargs:
                tasks.append(("avatar_image", self._fetch_avatar(user)))
            if "banner_image" not in kwargs:
                tasks.append(("banner_image", self._fetch_banner(user)))
            # Legacy/Template-specific names
            if "user_avatar" not in kwargs:
                tasks.append(("user_avatar", self._fetch_avatar(user)))
            if "target_avatar" not in kwargs:
                tasks.append(("target_avatar", self._fetch_avatar(user)))

        # 2. Moderator / Perpetrator
        moderator = kwargs.get("moderator") or kwargs.get("perpetrator")
        if isinstance(moderator, (discord.Member, discord.User)):
            if "mod_avatar" not in kwargs:
                tasks.append(("mod_avatar", self._fetch_avatar(moderator)))
            if "perpetrator_avatar" not in kwargs:
                tasks.append(("perpetrator_avatar", self._fetch_avatar(moderator)))

        # 3. Inviter
        inviter = kwargs.get("inviter")
        if isinstance(inviter, (discord.Member, discord.User)):
            if "inviter_avatar" not in kwargs:
                tasks.append(("inviter_avatar", self._fetch_avatar(inviter)))

        # 4. Invited
        invited = kwargs.get("invited")
        if isinstance(invited, (discord.Member, discord.User)):
            if "invited_avatar" not in kwargs:
                tasks.append(("invited_avatar", self._fetch_avatar(invited)))

        # 5. Staff (Tickets)
        staff = kwargs.get("assigned_staff")
        if isinstance(staff, (discord.Member, discord.User)):
            if "staff_avatar" not in kwargs:
                tasks.append(("staff_avatar", self._fetch_avatar(staff)))

        # 6. Guild (Serverinfo / Leaderboard)
        guild = kwargs.get("guild")
        if isinstance(guild, discord.Guild):
            if "icon_image" not in kwargs and guild.icon:
                tasks.append(("icon_image", self._avatar_cache.fetch_image(guild.icon.url, size=128)))
            if "banner_image" not in kwargs and guild.banner:
                tasks.append(("banner_image", self._avatar_cache.fetch_image(guild.banner.url, size=600)))

        if tasks:
            results = await asyncio.gather(*[coro for _, coro in tasks], return_exceptions=True)
            for i, (key, _) in enumerate(tasks):
                if not isinstance(results[i], Exception):
                    kwargs[key] = results[i]

    async def _fetch_avatar(self, user: discord.Member | discord.User, size: int = 128) -> Optional[Image.Image]:
        url = user.display_avatar.replace(size=size, format="png").url
        return await self._avatar_cache.fetch_image(url, size=size)

    async def _fetch_banner(self, user: discord.Member | discord.User, size: int = 600) -> Optional[Image.Image]:
        """Download and return a user banner as PIL Image if available."""
        try:
            # Check if it's already a full User object with banner, otherwise fetch
            if not hasattr(user, "banner"):
                user = await self.bot.fetch_user(user.id)
            
            if user.banner:
                url = user.banner.replace(size=size, format="png").url
                return await self._avatar_cache.fetch_image(url, size=size)
        except Exception:
            pass
        return None

    def make_file(self, image_bytes: bytes, filename: str = "card.png") -> discord.File:
        return discord.File(BytesIO(image_bytes), filename=filename)

    async def render_and_send(
        self,
        ctx_or_channel: Any,
        template_name: str,
        filename: str = "card.png",
        reply: bool = False,
        embed_title: Optional[str] = None,
        embed_description: Optional[str] = None,
        embed_color: Optional[int] = None,
        embed_fields: Optional[list] = None,
        view: Optional[discord.ui.View] = None,
        **kwargs,
    ) -> Optional[discord.Message]:
        try:
            image_bytes = await self.render(template_name, **kwargs)
            file = self.make_file(image_bytes, filename)
            
            embed = discord.Embed(
                title=embed_title or kwargs.get("title"),
                description=embed_description or kwargs.get("description"),
                color=embed_color or 0x5865F2,
                timestamp=kwargs.get("timestamp") or discord.utils.utcnow()
            )
            
            if embed_fields:
                for field in embed_fields:
                    embed.add_field(name=field["name"], value=field["value"], inline=field.get("inline", True))
            
            user = kwargs.get("user") or kwargs.get("target")
            if user:
                embed.set_author(name=str(user), icon_url=user.display_avatar.url)
            
            moderator = kwargs.get("moderator")
            if moderator:
                embed.set_footer(text=f"Action by {moderator}", icon_url=moderator.display_avatar.url)
            
            embed.set_image(url=f"attachment://{filename}")
            
            if reply and hasattr(ctx_or_channel, "reply"):
                return await ctx_or_channel.reply(embed=embed, file=file, view=view)
            elif hasattr(ctx_or_channel, "send"):
                return await ctx_or_channel.send(embed=embed, file=file, view=view)
                
        except asyncio.TimeoutError:
            if hasattr(ctx_or_channel, "send"):
                await ctx_or_channel.send("Image generation timed out.")
        except Exception as e:
            print(f"[Renderer Error] {e}")
            if hasattr(ctx_or_channel, "send"):
                await ctx_or_channel.send(f"Failed to generate image: {e}")
        return None
