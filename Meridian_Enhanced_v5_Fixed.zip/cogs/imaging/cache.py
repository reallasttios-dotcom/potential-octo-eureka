import asyncio
import time
import aiohttp
from io import BytesIO
from PIL import Image
from typing import Optional, Dict, Tuple
import hashlib


class ImageCache:
    """
    Caching system for avatars, banners, emojis, and processed images.
    Supports TTL-based expiration and memory management.
    """

    def __init__(self, max_size: int = 256, default_ttl: int = 300):
        self._cache: Dict[str, Tuple[bytes, float]] = {}
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._lock = asyncio.Lock()

    def _make_key(self, *parts) -> str:
        raw = "|".join(str(p) for p in parts)
        return hashlib.md5(raw.encode()).hexdigest()

    def _is_expired(self, stored_at: float, ttl: int) -> bool:
        return (time.monotonic() - stored_at) > ttl

    async def get(self, key: str) -> Optional[bytes]:
        async with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            data, stored_at = entry
            if self._is_expired(stored_at, self._default_ttl):
                del self._cache[key]
                return None
            return data

    async def set(self, key: str, data: bytes, ttl: Optional[int] = None) -> None:
        async with self._lock:
            if len(self._cache) >= self._max_size:
                self._evict_oldest()
            self._cache[key] = (data, time.monotonic())

    def _evict_oldest(self) -> None:
        if not self._cache:
            return
        oldest_key = min(self._cache, key=lambda k: self._cache[k][1])
        del self._cache[oldest_key]

    async def invalidate(self, key: str) -> None:
        async with self._lock:
            self._cache.pop(key, None)

    async def clear(self) -> None:
        async with self._lock:
            self._cache.clear()

    async def cleanup_expired(self) -> int:
        async with self._lock:
            now = time.monotonic()
            expired = [
                k for k, (_, stored_at) in self._cache.items()
                if (now - stored_at) > self._default_ttl
            ]
            for k in expired:
                del self._cache[k]
            return len(expired)

    def avatar_key(self, user_id: int, avatar_hash: Optional[str]) -> str:
        return self._make_key("avatar", user_id, avatar_hash or "default")

    def banner_key(self, user_id: int, banner_hash: Optional[str]) -> str:
        return self._make_key("banner", user_id, banner_hash or "none")

    def emoji_key(self, emoji_id: int, animated: bool = False) -> str:
        return self._make_key("emoji", emoji_id, "anim" if animated else "static")

    def rendered_key(self, template: str, **kwargs) -> str:
        sorted_items = sorted(kwargs.items())
        return self._make_key("rendered", template, *[f"{k}={v}" for k, v in sorted_items])


class AvatarBannerCache(ImageCache):
    """Specialised cache for user avatars and server banners."""

    AVATAR_TTL = 600
    BANNER_TTL = 600

    def __init__(self):
        super().__init__(max_size=512, default_ttl=self.AVATAR_TTL)

    async def fetch_image(self, url: str, size: int = 256) -> Optional[Image.Image]:
        """Download and cache an image from a URL, return PIL Image."""
        key = self._make_key("url", url, size)
        cached = await self.get(key)
        if cached:
            return Image.open(BytesIO(cached)).convert("RGBA")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    if resp.status == 200:
                        data = await resp.read()
                        img = Image.open(BytesIO(data)).convert("RGBA")
                        img = img.resize((size, size), Image.LANCZOS)
                        out = BytesIO()
                        img.save(out, format="PNG")
                        await self.set(key, out.getvalue())
                        return img
        except Exception:
            pass
        return None
