import discord
from discord.ext import commands
import datetime

STARBOARD_CHANNEL_ID = 1478270270090379339
STARBOARD_THRESHOLD = 3
EMOJI_WEIGHTS = {"⭐": 1, "🌟": 2, "✨": 1}

class Starboard(commands.Cog):
    """Advanced weighted reaction starboard with persistence and filtering."""

    def __init__(self, bot):
        self.bot = bot
        self._cache: dict[str, str] = {}

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        if hasattr(self.bot, 'imaging'):
            try:
                template = kwargs.pop("_template", "general")
                return await self.bot.imaging.render_and_send(
                    ctx_or_channel=reply_to or send_to,
                    template_name=template,
                    filename=f"{template}.png",
                    reply=(reply_to is not None),
                    embed_title=fallback_embed.title if fallback_embed else None,
                    embed_description=fallback_embed.description if fallback_embed else None,
                    **kwargs
                )
            except Exception as exc:
                print(f"[Starboard imaging] {exc}")
        if reply_to: return await reply_to.reply(embed=fallback_embed)
        return await send_to.send(embed=fallback_embed)

    async def cog_load(self):
        async with self.bot.db.execute("SELECT message_id, starboard_message_id FROM starboard_messages") as cursor:
            rows = await cursor.fetchall()
        for row in rows:
            self._cache[str(row["message_id"])] = str(row["starboard_message_id"])

    async def build_starboard_embed(self, message: discord.Message, score: int) -> discord.Embed:
        embed = discord.Embed(description=message.content or "*No content*", color=0xFFD700, timestamp=message.created_at)
        embed.set_author(name=str(message.author), icon_url=message.author.display_avatar.url)
        embed.add_field(name="Source", value=f"[Jump to message]({message.jump_url})", inline=False)
        for a in message.attachments:
            if a.content_type and a.content_type.startswith("image/"):
                embed.set_image(url=a.url)
                break
        embed.set_footer(text=f"⭐ Score: {score} | ID: {message.id}")
        return embed

    async def _compute_score(self, message: discord.Message) -> int:
        score = 0
        for r in message.reactions:
            e = str(r.emoji)
            if e in EMOJI_WEIGHTS:
                count = r.count
                # Prevent self-starring
                async for user in r.users():
                    if user.id == message.author.id:
                        count -= 1
                        break
                score += max(0, count) * EMOJI_WEIGHTS[e]
        return score

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        if str(payload.emoji) not in EMOJI_WEIGHTS: return
        if payload.channel_id == STARBOARD_CHANNEL_ID: return
        
        channel = self.bot.get_channel(payload.channel_id)
        if not channel: return
        try: message = await channel.fetch_message(payload.message_id)
        except: return
        if message.author.bot: return

        score = await self._compute_score(message)
        if score < STARBOARD_THRESHOLD: return

        starboard_channel = self.bot.get_channel(STARBOARD_CHANNEL_ID)
        if not starboard_channel: return

        embed = await self.build_starboard_embed(message, score)
        msg_id = str(message.id)

        if msg_id in self._cache:
            try:
                sb_msg = await starboard_channel.fetch_message(int(self._cache[msg_id]))
                await sb_msg.edit(embed=embed)
            except:
                await self._post_to_starboard(message, starboard_channel, embed, score)
        else:
            await self._post_to_starboard(message, starboard_channel, embed, score)

    async def _post_to_starboard(self, message, starboard_channel, embed, score):
        sb_msg = None
        if hasattr(self.bot, 'imaging'):
            try:
                sb_msg = await self.bot.imaging.render_and_send(
                    ctx_or_channel=starboard_channel,
                    template_name="general",
                    filename=f"starboard_{message.id}.png",
                    embed_title=f"⭐ Starboard | Score: {score}",
                    embed_description=message.content,
                    user=message.author,
                    card_type="starboard"
                )
            except: pass
        
        if not sb_msg:
            sb_msg = await starboard_channel.send(embed=embed)
        
        if sb_msg:
            self._cache[str(message.id)] = str(sb_msg.id)
            await self.bot.db.execute("INSERT OR REPLACE INTO starboard_messages (guild, message_id, starboard_message_id) VALUES (?, ?, ?)",
                                      (str(message.guild.id), str(message.id), str(sb_msg.id)))
            await self.bot.db.commit()

    # ─── Starboard Sub-Cog ──────────────────────────────────────────────

    @commands.group(name="starboard", invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    async def starboard_group(self, ctx):
        """Starboard management commands."""
        await ctx.send_help(ctx.command)

    @starboard_group.command(name="stats")
    async def starboard_stats(self, ctx):
        """Show server starboard statistics."""
        async with self.bot.db.execute("SELECT COUNT(*) FROM starboard_messages WHERE guild = ?", (str(ctx.guild.id),)) as cursor:
            count = (await cursor.fetchone())[0]
        embed = discord.Embed(title="⭐ Starboard Stats", description=f"Total starred messages: **{count}**", color=0xFFD700)
        await ctx.send(embed=embed)

    @starboard_group.command(name="fix")
    @commands.has_permissions(administrator=True)
    async def fix_starboard(self, ctx, message_id: int):
        """Manually force a message onto the starboard or update its score."""
        try:
            message = await ctx.channel.fetch_message(message_id)
            score = await self._compute_score(message)
            starboard_channel = self.bot.get_channel(STARBOARD_CHANNEL_ID)
            embed = await self.build_starboard_embed(message, score)
            await self._post_to_starboard(message, starboard_channel, embed, score)
            await ctx.send("✅ Starboard entry updated.")
        except:
            await ctx.send("❌ Message not found.")

async def setup(bot):
    await bot.add_cog(Starboard(bot))
