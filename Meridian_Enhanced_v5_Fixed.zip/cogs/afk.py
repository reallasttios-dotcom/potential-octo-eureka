import discord
from discord.ext import commands
import time


def fmt_duration(seconds: float) -> str:
    seconds = int(seconds)
    d, s = divmod(seconds, 86400)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    parts = []
    if d: parts.append(f"{d}d")
    if h: parts.append(f"{h}h")
    if m: parts.append(f"{m}m")
    if s or not parts: parts.append(f"{s}s")
    return " ".join(parts)


class AFK(commands.Cog):
    """AFK status tracking — persistent across bot restarts, guild-aware."""

    def __init__(self, bot):
        self.bot = bot
        # In-memory cache: (guild_id, user_id) -> {reason, since}
        self._cache: dict = {}

    async def cog_load(self):
        async with self.bot.db.execute("SELECT guild, user_id, reason, since FROM afk") as cursor:
            rows = await cursor.fetchall()
        for row in rows:
            self._cache[(row["guild"], row["user_id"])] = {
                "reason": row["reason"],
                "since": row["since"],
            }

    # ─── Imaging helper ───────────────────────────────────────────────────

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[AFK imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    # ─── Internal helpers ─────────────────────────────────────────────────

    def _is_afk(self, guild_id: int, user_id: int) -> dict | None:
        return self._cache.get((str(guild_id), str(user_id)))

    async def _set_afk(self, guild_id: int, user_id: int, reason: str):
        key = (str(guild_id), str(user_id))
        since = time.time()
        self._cache[key] = {"reason": reason, "since": since}
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO afk (guild, user_id, reason, since) VALUES (?, ?, ?, ?)",
            (str(guild_id), str(user_id), reason, since),
        )
        await self.bot.db.commit()

    async def _clear_afk(self, guild_id: int, user_id: int):
        key = (str(guild_id), str(user_id))
        entry = self._cache.pop(key, None)
        await self.bot.db.execute(
            "DELETE FROM afk WHERE guild = ? AND user_id = ?",
            (str(guild_id), str(user_id)),
        )
        await self.bot.db.commit()
        return entry

    # ─── Commands ─────────────────────────────────────────────────────────

    @commands.command()
    async def afk(self, ctx, *, reason: str = "Just vibing"):
        """Set yourself as AFK with an optional reason."""
        since = time.time()
        await self._set_afk(ctx.guild.id, ctx.author.id, reason)

        # Nickname tagging — try to prepend [AFK]
        if not ctx.author.display_name.startswith("[AFK]"):
            try:
                await ctx.author.edit(nick=f"[AFK] {ctx.author.display_name}"[:32])
            except (discord.Forbidden, discord.HTTPException):
                pass

        fallback = discord.Embed(
            description=f"💤 {ctx.author.mention} is now AFK: **{reason}**",
            color=0xFFA500,
        )
        await self._send_card(
            ctx, fallback,
            card_type="afk",
            user_name=ctx.author.display_name,
            user_id=ctx.author.id,
            reason=reason,
            since=since,
            returning=False,
            user=ctx.author,
        )

    @commands.command(name="afkcheck")
    async def afk_check(self, ctx, member: discord.Member):
        """Check if a user is currently AFK without pinging them."""
        entry = self._is_afk(ctx.guild.id, member.id)
        if not entry:
            embed = discord.Embed(
                description=f"✅ **{member.display_name}** is not AFK.",
                color=0x57F287,
            )
        else:
            elapsed = fmt_duration(time.time() - entry["since"])
            embed = discord.Embed(
                description=f"💤 **{member.display_name}** is AFK for **{elapsed}**: {entry['reason']}",
                color=0xFFA500,
            )
        await ctx.send(embed=embed)

    @commands.command(name="afklist")
    @commands.has_permissions(manage_messages=True)
    async def afk_list(self, ctx):
        """Staff command — show all currently AFK users in this server."""
        guild_afks = [
            (uid, data)
            for (gid, uid), data in self._cache.items()
            if gid == str(ctx.guild.id)
        ]

        if not guild_afks:
            embed = discord.Embed(description="No users are currently AFK.", color=0xFFA500)
            return await ctx.send(embed=embed)

        lines = []
        for user_id, data in guild_afks:
            elapsed = fmt_duration(time.time() - data["since"])
            lines.append(f"<@{user_id}> — **{elapsed}** — {data['reason']}")

        embed = discord.Embed(
            title=f"AFK Users in {ctx.guild.name} ({len(guild_afks)})",
            description="\n".join(lines[:25]),
            color=0xFFA500,
        )
        await ctx.send(embed=embed)

    # ─── Listener ─────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return

        ctx = await self.bot.get_context(message)
        if ctx.valid:
            return

        # Return from AFK
        entry = self._is_afk(message.guild.id, message.author.id)
        if entry:
            elapsed = fmt_duration(time.time() - entry["since"])
            cleared = await self._clear_afk(message.guild.id, message.author.id)

            # Strip [AFK] nickname tag
            if message.author.display_name.startswith("[AFK] "):
                try:
                    new_nick = message.author.display_name[6:] or None
                    await message.author.edit(nick=new_nick)
                except (discord.Forbidden, discord.HTTPException):
                    pass

            fallback = discord.Embed(
                description=f"👋 Welcome back {message.author.mention}! You were AFK for **{elapsed}**.",
                color=0xFFA500,
            )
            await self._send_card(
                message.channel, fallback,
                delete_after=8,
                card_type="afk",
                user_name=message.author.display_name,
                user_id=message.author.id,
                reason=cleared["reason"] if cleared else "AFK",
                since=cleared["since"] if cleared else time.time() - 1,
                returning=True,
                user=message.author,
            )

        # Notify about mentioned AFK users
        for mention in message.mentions:
            if mention.id == message.author.id:
                continue
            afk_entry = self._is_afk(message.guild.id, mention.id)
            if afk_entry:
                elapsed = fmt_duration(time.time() - afk_entry["since"])
                fallback = discord.Embed(
                    description=f"💤 **{mention.display_name}** is AFK ({elapsed}): {afk_entry['reason']}",
                    color=0xFFA500,
                )
                await self._send_card(
                    message.channel, fallback,
                    card_type="afk",
                    user_name=mention.display_name,
                    user_id=mention.id,
                    reason=afk_entry["reason"],
                    since=afk_entry["since"],
                    returning=False,
                    user=mention,
                )


async def setup(bot):
    await bot.add_cog(AFK(bot))
