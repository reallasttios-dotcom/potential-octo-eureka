import discord
from discord.ext import commands, tasks
import math
import time
import aiohttp
from datetime import datetime
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from typing import Optional

def calculate_level(xp):
    return int(math.sqrt(xp) * 0.15)

def xp_for_level(level):
    return math.ceil((level / 0.15) ** 2)

LEVEL_ROLES = {
    5:  1486390516223316038,
    10: 1478270269310238776,
    20: 1478270269310238777,
    35: 1478270269301985333,
    50: 1478270269301985332,
}

class Leveling(commands.Cog):
    """XP and leveling system with imaging-rendered rank cards."""

    def __init__(self, bot):
        self.bot = bot
        self.cooldowns: dict[str, float] = {}
        self.base_xp = 15
        self.cooldown_sec = 5
        self.length_cap = 500
        self.xp_decay_task.start()

    def cog_unload(self):
        self.xp_decay_task.cancel()

    async def _get_image(self, url: str) -> Optional[Image.Image]:
        if not url:
            return None
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status == 200:
                        data = await resp.read()
                        img = Image.open(BytesIO(data))
                        # Ensure image is in RGBA mode to avoid "wrong mode" errors
                        return img.convert("RGBA")
        except Exception as e:
            print(f"[Leveling] Error fetching image {url}: {e}")
        return None

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        if hasattr(self.bot, 'imaging'):
            try:
                template = kwargs.pop("_template", "general")
                return await self.bot.imaging.render_and_send(
                    ctx_or_channel=reply_to or send_to,
                    template_name=template,
                    filename=f"{template}.png",
                    reply=(reply_to is not None),
                    embed_title=fallback_embed.title if fallback_embed else f"Leveling: {template.replace('_', ' ').title()}",
                    embed_description=fallback_embed.description if fallback_embed else None,
                    embed_color=fallback_embed.color.value if fallback_embed else 0x5865F2,
                    **kwargs
                )
            except Exception as exc:
                print(f"[Leveling imaging] {exc}")
        if reply_to: return await reply_to.reply(embed=fallback_embed)
        return await send_to.send(embed=fallback_embed)

    @tasks.loop(hours=24)
    async def xp_decay_task(self):
        """Optional: small XP decay for inactive users."""
        await self.bot.db.execute("UPDATE levels SET xp = CAST(xp * 0.99 AS INTEGER) WHERE xp > 100")
        await self.bot.db.commit()

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild: return
        uid, gid = str(message.author.id), str(message.guild.id)
        key = f"{gid}:{uid}"
        now = time.time()
        if key in self.cooldowns and now - self.cooldowns[key] < self.cooldown_sec: return
        self.cooldowns[key] = now

        content_len = min(len(message.content), self.length_cap)
        gain = self.base_xp + (content_len // 20)
        
        async with self.bot.db.execute("SELECT xp FROM levels WHERE user = ? AND guild = ?", (uid, gid)) as cursor:
            row = await cursor.fetchone()
        
        if not row:
            await self.bot.db.execute("INSERT INTO levels (user, guild, xp) VALUES (?, ?, ?)", (uid, gid, gain))
            new_xp = gain
        else:
            new_xp = row["xp"] + gain
            await self.bot.db.execute("UPDATE levels SET xp = ? WHERE user = ? AND guild = ?", (new_xp, uid, gid))
        await self.bot.db.commit()

        old_lvl = calculate_level(new_xp - gain)
        new_lvl = calculate_level(new_xp)
        if new_lvl > old_lvl:
            for lvl, role_id in LEVEL_ROLES.items():
                if new_lvl >= lvl:
                    role = message.guild.get_role(role_id)
                    if role and role not in message.author.roles:
                        try: await message.author.add_roles(role, reason="Level up reward")
                        except: pass
            embed = discord.Embed(title="Level Up!", description=f"Congratulations {message.author.mention}, you reached **Level {new_lvl}**!", color=0x5865F2)
            
            # Fetch avatar and banner for level up card
            avatar_img = await self._get_image(message.author.display_avatar.url)
            banner_img = None
            
            # discord.py requires fetching the user to get the banner if it's not cached
            if not message.author.banner:
                try:
                    user = await self.bot.fetch_user(message.author.id)
                    if user.banner:
                        banner_img = await self._get_image(user.banner.url)
                except:
                    pass
            elif message.author.banner:
                banner_img = await self._get_image(message.author.banner.url)
            
            await self._send_card(message.channel, embed, _template="levelup", 
                                  user=message.author, new_level=new_lvl, 
                                  total_xp=new_xp, avatar_image=avatar_img, 
                                  banner_image=banner_img)

    # ─── Leveling Sub-Cog ──────────────────────────────────────────────

    @commands.group(name="xp", aliases=["level", "rank"], invoke_without_command=True)
    async def xp_group(self, ctx, member: discord.Member = None):
        """Check your or someone else's level and XP."""
        member = member or ctx.author
        uid, gid = str(member.id), str(ctx.guild.id)
        async with self.bot.db.execute("SELECT xp FROM levels WHERE user = ? AND guild = ?", (uid, gid)) as cursor:
            row = await cursor.fetchone()
        xp = row["xp"] if row else 0
        lvl = calculate_level(xp)
        current_lvl_xp = xp_for_level(lvl)
        next_lvl_xp = xp_for_level(lvl + 1)
        needed = next_lvl_xp - current_lvl_xp
        progress = xp - current_lvl_xp
        async with self.bot.db.execute("SELECT COUNT(*) as pos FROM levels WHERE guild = ? AND xp > ?", (gid, xp)) as cursor:
            rank_row = await cursor.fetchone()
        rank_pos = rank_row["pos"] + 1
        
        # Fetch avatar and banner for rank card
        avatar_img = await self._get_image(member.display_avatar.url)
        banner_img = None
        
        # discord.py requires fetching the user to get the banner if it's not cached
        if not member.banner:
            try:
                member = await self.bot.fetch_user(member.id)
            except Exception as e:
                print(f"[Leveling] Failed to fetch user {member.id} for banner: {e}")

        if member.banner:
            banner_img = await self._get_image(member.banner.url)

        embed = discord.Embed(title=f"Rank Card - {member}", color=member.color)
        embed.add_field(name="Level", value=str(lvl), inline=True)
        embed.add_field(name="Rank", value=f"#{rank_pos}", inline=True)
        embed.add_field(name="XP", value=f"{xp:,} / {next_lvl_xp:,}", inline=False)
        
        await self._send_card(ctx, embed, _template="rank_card", 
                              user=member, level=lvl, total_xp=xp, 
                              progress_xp=progress, needed_xp=needed, 
                              rank_pos=rank_pos, avatar_image=avatar_img, 
                              banner_image=banner_img)

    @xp_group.command(name="leaderboard", aliases=["lb", "top"])
    async def leaderboard(self, ctx):
        """Show the top users in the server."""
        gid = str(ctx.guild.id)
        async with self.bot.db.execute("SELECT user, xp FROM levels WHERE guild = ? ORDER BY xp DESC LIMIT 10", (gid,)) as cursor:
            rows = await cursor.fetchall()
        if not rows: return await ctx.send("No one has earned any XP yet!")
        
        from .imaging.templates.leaderboard import LeaderboardEntry
        entries = []
        embed = discord.Embed(title=f"Leaderboard - {ctx.guild.name}", color=0x5865F2)
        
        for i, row in enumerate(rows):
            uid = int(row["user"])
            xp = row["xp"]
            lvl = calculate_level(xp)
            
            current_lvl_xp = xp_for_level(lvl)
            next_lvl_xp = xp_for_level(lvl + 1)
            needed = next_lvl_xp - current_lvl_xp
            progress = xp - current_lvl_xp
            
            member = ctx.guild.get_member(uid)
            if not member:
                try:
                    member = await ctx.guild.fetch_member(uid)
                except:
                    member = None
            
            name = str(member) if member else f"Unknown ({uid})"
            embed.add_field(name=f"{i+1}. {name}", value=f"Level {lvl} ({xp:,} XP)", inline=False)
            
            if member:
                # Fetch avatar and banner for each entry
                avatar_img = await self._get_image(member.display_avatar.url)
                banner_img = None

                # discord.py requires fetching the user to get the banner if it's not cached
                if not member.banner:
                    try:
                        member = await self.bot.fetch_user(member.id)
                    except:
                        pass

                if member.banner:
                    banner_img = await self._get_image(member.banner.url)
                
                entries.append(LeaderboardEntry(
                    user=member, 
                    level=lvl, 
                    total_xp=xp, 
                    rank=i+1,
                    current_xp=progress,
                    needed_xp=needed,
                    avatar_image=avatar_img,
                    banner_image=banner_img
                ))
        
        # Fetch guild icon and banner
        guild_icon = await self._get_image(ctx.guild.icon.url) if ctx.guild.icon else None
        guild_banner = await self._get_image(ctx.guild.banner.url) if ctx.guild.banner else None
        
        await self._send_card(ctx, embed, _template="leaderboard", 
                              guild=ctx.guild, entries=entries, 
                              icon_image=guild_icon, banner_image=guild_banner)

    @xp_group.command(name="set")
    @commands.has_permissions(administrator=True)
    async def set_xp(self, ctx, member: discord.Member, amount: int):
        """Set a user's XP amount."""
        uid, gid = str(member.id), str(ctx.guild.id)
        await self.bot.db.execute("INSERT OR REPLACE INTO levels (user, guild, xp) VALUES (?, ?, ?)", (uid, gid, amount))
        await self.bot.db.commit()
        await ctx.send(f"✅ Set {member.mention}'s XP to {amount:,}.")

    @xp_group.command(name="reset")
    @commands.has_permissions(administrator=True)
    async def reset_xp(self, ctx, member: discord.Member):
        """Reset a user's XP to 0."""
        uid, gid = str(member.id), str(ctx.guild.id)
        await self.bot.db.execute("DELETE FROM levels WHERE user = ? AND guild = ?", (uid, gid))
        await self.bot.db.commit()
        await ctx.send(f"✅ Reset XP for {member.mention}.")

async def setup(bot):
    await bot.add_cog(Leveling(bot))
