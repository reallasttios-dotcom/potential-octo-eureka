import discord
from discord.ext import commands, tasks
import json
import time
import re
from collections import defaultdict
from pathlib import Path

# Use absolute path to avoid working directory issues
CONFIG_FILE = Path(__file__).parent / "antinuke_config.json"

def is_manager():
    async def predicate(ctx):
        if not ctx.guild:
            raise commands.NoPrivateMessage()
        # Guild owner is always a manager
        if ctx.author == ctx.guild.owner:
            return True
        if ctx.author.guild_permissions.administrator:
            return True
        manager_roles = ctx.cog.config.get("managers", [])
        if any(role.id in manager_roles for role in ctx.author.roles):
            return True
        raise commands.MissingPermissions(["Administrator or AntiNuke Manager"])
    return commands.check(predicate)


class AntiNuke(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = {
            "watched_roles": [],
            "quarantine_role_id": None,
            "quarantined_users": {},
            "role_perms": {},
            "managers": [],
            "log_channel_id": None,
            "whitelist_users": [],
            "whitelist_roles": [],
            "time_window": 15,
            "max_restores_per_minute": 5,
            "mass_ping_threshold": 5,
            "appeal_url": "https://discord.gg/example"
        }
        self.load_config()

        self.pending_restores = defaultdict(list)
        self.restores_this_minute = defaultdict(int)
        self.reset_restore_limit.start()

        self.trackers = {
            "role_assign": defaultdict(list),
            "delete": defaultdict(list),
            "mention": defaultdict(list),
            "mod_action": defaultdict(list)
        }
        # Store role assignments per culprit: {culprit_id: [(target_id, role_id, timestamp), ...]}
        self.role_assignments = defaultdict(list)
        self.clean_trackers.start()

        self.TIERS = {
            "none":   {"role_assign": float('inf'), "delete": float('inf'), "mention": float('inf'), "mod_action": float('inf')},
            "min":    {"role_assign": float('inf'), "delete": 10,            "mention": 5,            "mod_action": 10},
            "low":    {"role_assign": 5,            "delete": 7,             "mention": 3,            "mod_action": 5},
            "medium": {"role_assign": 1,            "delete": 5,             "mention": 2,            "mod_action": 3},
            "high":   {"role_assign": 0,            "delete": 2,             "mention": 5,            "mod_action": 2}
        }

        self._em = None

    @property
    def em(self):
        if self._em is None:
            self._em = self.bot.get_cog("EmojiManager")
        return self._em

    def e(self, key):
        return self.em.get_emoji("AntiNuke", key) if self.em else ""

    def cog_unload(self):
        self.reset_restore_limit.cancel()
        self.clean_trackers.cancel()

    # --------------------------------------------------------------------------
    # Helper methods
    # --------------------------------------------------------------------------
    def _embed(self, description, color=0xFF6600):
        return discord.Embed(description=f"{self.e('check')} {description}", color=color)

    def load_config(self):
        if not CONFIG_FILE.exists():
            return
        try:
            data = json.loads(CONFIG_FILE.read_text())
            for key, value in data.items():
                if key in self.config:
                    self.config[key] = value
        except Exception as e:
            print("Failed to load antinuke config:", e)

    def save_config(self):
        try:
            CONFIG_FILE.write_text(json.dumps(self.config, indent=2))
        except Exception as e:
            print("Failed to save antinuke config:", e)

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[AntiNuke imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    async def log(self, guild, message, color=0xFF6600, perpetrator=None):
        if not self.config["log_channel_id"]:
            return
        channel = guild.get_channel(self.config["log_channel_id"])
        if channel and channel.permissions_for(guild.me).send_messages:
            embed = self._embed(message, color)
            sev = "critical" if color == 0xFF0000 else "warning"
            await self._send_card(channel, embed,
                card_type="alert", alert_type="antinuke",
                title="AntiNuke Alert", description=message,
                severity=sev,
                perpetrator=perpetrator or self.bot.user,
            )

    def is_whitelisted(self, member: discord.Member) -> bool:
        if member.id in self.config["whitelist_users"]:
            return True
        if any(r.id in self.config["whitelist_roles"] for r in member.roles):
            return True
        return False

    def is_manager_role(self, member: discord.Member) -> bool:
        """Check if member has any role marked as manager."""
        if member == member.guild.owner:
            return True
        if member.guild_permissions.administrator:
            return True
        return any(role.id in self.config["managers"] for role in member.roles)

    def get_user_limits(self, member: discord.Member):
        # Managers are completely exempt (unlimited)
        if self.is_manager_role(member):
            return self.TIERS["none"]

        if self.is_whitelisted(member):
            return self.TIERS["none"]

        for role in sorted(member.roles, key=lambda r: r.position, reverse=True):
            if str(role.id) in self.config["role_perms"]:
                tier = self.config["role_perms"][str(role.id)]
                return self.TIERS.get(tier, self.TIERS["medium"])
        return self.TIERS["medium"]

    async def check_trigger(self, member: discord.Member, action_type: str):
        limits = self.get_user_limits(member)
        limit = limits[action_type]
        if limit == float('inf'):
            return False
        if limit == 0:
            return True

        now = time.time()
        window = self.config["time_window"]
        self.trackers[action_type][member.id].append(now)
        self.trackers[action_type][member.id] = [
            t for t in self.trackers[action_type][member.id] if now - t <= window
        ]

        if len(self.trackers[action_type][member.id]) >= limit:
            self.trackers[action_type][member.id].clear()
            return True
        return False

    async def revert_role_assignments(self, guild, culprit: discord.Member):
        """Remove all watched roles that this culprit assigned within the time window."""
        now = time.time()
        window = self.config["time_window"]
        assignments = self.role_assignments.get(culprit.id, [])
        # Keep only recent ones
        recent = [(tgt, rid, ts) for (tgt, rid, ts) in assignments if now - ts <= window]
        if not recent:
            return

        for target_id, role_id, _ in recent:
            target = guild.get_member(target_id)
            role = guild.get_role(role_id)
            if target and role and role in target.roles:
                try:
                    await target.remove_roles(role, reason="AntiNuke: Reverting dangerous role assignment")
                except discord.Forbidden:
                    pass
        # Clear all assignments for this culprit
        self.role_assignments[culprit.id].clear()

    async def execute_quarantine(self, guild, member: discord.Member, reason: str, moderator: discord.Member = None):
        if self.is_manager_role(member):
            return False, f"{member.mention} is a manager and cannot be quarantined."
        if self.is_whitelisted(member):
            return False, f"{member.mention} is whitelisted and cannot be quarantined."

        if not self.config["quarantine_role_id"]:
            return False, "Quarantine role not configured."
        death_role = guild.get_role(self.config["quarantine_role_id"])
        if not death_role:
            return False, "Quarantine role not found."

        if member.id == guild.owner_id or member.top_role >= guild.me.top_role:
            return False, "Hierarchy constraint: Cannot quarantine this user."

        if str(member.id) in self.config["quarantined_users"]:
            return False, f"{member.mention} is already quarantined."

        roles_to_remove = [
            r for r in member.roles
            if r.name != "@everyone"
            and not r.is_premium_subscriber()
            and r.id != death_role.id
        ]
        self.config["quarantined_users"][str(member.id)] = [r.id for r in roles_to_remove]
        self.save_config()

        try:
            await member.remove_roles(*roles_to_remove, reason=f"AntiNuke: {reason}")
            await member.add_roles(death_role, reason="Quarantined")

            try:
                dm_embed = discord.Embed(
                    title=f"{self.e('check')} Quarantined",
                    description=f"You have been placed in the quarantine role in **{guild.name}**.",
                    color=0xFF0000
                )
                dm_embed.add_field(name="Reason", value=reason, inline=False)
                dm_embed.add_field(name="Appeal", value=f"[Click here to appeal]({self.config['appeal_url']})")
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass

            await self.log(guild, f"Quarantined {member.mention} – {reason}", 0xFF0000, perpetrator=moderator)
            return True, f"Quarantined {member.mention} for: {reason}"
        except discord.Forbidden:
            return False, "Missing Discord permissions to manage roles."

    async def process_restores(self, guild, culprit_id):
        items = self.pending_restores.pop(culprit_id, [])
        for item_type, item in items:
            if self.restores_this_minute[guild.id] >= self.config["max_restores_per_minute"]:
                continue
            self.restores_this_minute[guild.id] += 1
            try:
                if item_type == "channel":
                    new_channel = await item.clone(reason="AntiNuke: Auto-restore after punishment")
                    await self.log(guild, f"Restored channel `{new_channel.name}`")
                elif item_type == "role":
                    position = item.position
                    new_role = await guild.create_role(
                        name=item.name,
                        permissions=item.permissions,
                        color=item.color,
                        hoist=item.hoist,
                        mentionable=item.mentionable,
                        reason="AntiNuke: Auto-restore after punishment"
                    )
                    await new_role.edit(position=position)
                    await self.log(guild, f"Restored role `{new_role.name}`")
            except Exception as e:
                print(f"Failed to restore {item_type}: {e}")

    @tasks.loop(minutes=1)
    async def reset_restore_limit(self):
        self.restores_this_minute.clear()

    @tasks.loop(minutes=5)
    async def clean_trackers(self):
        """Prevent memory leak by removing old timestamps."""
        now = time.time()
        window = self.config["time_window"]
        for tracker in self.trackers.values():
            for uid in list(tracker.keys()):
                tracker[uid] = [t for t in tracker[uid] if now - t <= window]
                if not tracker[uid]:
                    del tracker[uid]
        # Clean role assignments as well
        for culprit_id in list(self.role_assignments.keys()):
            self.role_assignments[culprit_id] = [
                (tgt, rid, ts) for (tgt, rid, ts) in self.role_assignments[culprit_id] if now - ts <= window
            ]
            if not self.role_assignments[culprit_id]:
                del self.role_assignments[culprit_id]

    @reset_restore_limit.before_loop
    @clean_trackers.before_loop
    async def before_tasks(self):
        await self.bot.wait_until_ready()

    # --------------------------------------------------------------------------
    # Commands
    # --------------------------------------------------------------------------
    @commands.group(invoke_without_command=True)
    @is_manager()
    async def antinuke(self, ctx):
        """Main AntiNuke command group."""
        await ctx.send_help(ctx.command)

    @antinuke.command(name="settings")
    @is_manager()
    async def settings_cmd(self, ctx):
        """Show current AntiNuke configuration."""
        embed = discord.Embed(title=f"{self.e('check')} AntiNuke Settings", color=0xFF6600)
        embed.add_field(name="Quarantine Role", value=f"<@&{self.config['quarantine_role_id']}>" if self.config['quarantine_role_id'] else "Not set", inline=False)
        embed.add_field(name="Watched Roles", value=", ".join(f"<@&{r}>" for r in self.config['watched_roles']) or "None", inline=False)
        embed.add_field(name="Log Channel", value=f"<#{self.config['log_channel_id']}>" if self.config['log_channel_id'] else "Not set", inline=False)
        embed.add_field(name="Time Window (sec)", value=self.config['time_window'], inline=True)
        embed.add_field(name="Max Restores/min", value=self.config['max_restores_per_minute'], inline=True)
        embed.add_field(name="Mass Ping Threshold", value=self.config['mass_ping_threshold'], inline=True)
        embed.add_field(name="Appeal URL", value=self.config['appeal_url'], inline=False)
        embed.add_field(name="Whitelisted Users", value=", ".join(f"<@{u}>" for u in self.config['whitelist_users']) or "None", inline=False)
        embed.add_field(name="Whitelisted Roles", value=", ".join(f"<@&{r}>" for r in self.config['whitelist_roles']) or "None", inline=False)

        if self.config["role_perms"]:
            perms_list = "\n".join(f"<@&{rid}> → `{tier}`" for rid, tier in self.config["role_perms"].items())
            embed.add_field(name="Role Tiers", value=perms_list, inline=False)
        await self._send_card(ctx, embed,
            card_type="info",
            title="AntiNuke Settings",
            fields=[
                ("Quarantine Role", f"ID: {self.config['quarantine_role_id'] or 'Not set'}", True),
                ("Time Window", f"{self.config['time_window']}s", True),
                ("Max Restores/min", str(self.config['max_restores_per_minute']), True),
                ("Mass Ping Threshold", str(self.config['mass_ping_threshold']), True),
                ("Watched Roles", str(len(self.config['watched_roles'])), True),
                ("Whitelisted Users", str(len(self.config['whitelist_users'])), True),
            ],
        )

    @antinuke.command(name="uploadconfig")
    @is_manager()
    async def upload_config(self, ctx):
        """Upload a JSON file to replace the current AntiNuke configuration."""
        if not ctx.message.attachments:
            return await ctx.send(embed=self._embed("Please attach a JSON configuration file.", 0xFF0000))
    
        attachment = ctx.message.attachments[0]
        if not attachment.filename.endswith('.json'):
            return await ctx.send(embed=self._embed("File must be a JSON file.", 0xFF0000))
    
        try:
            content = await attachment.read()
            new_config = json.loads(content.decode('utf-8'))
        
            required_fields = ["watched_roles", "quarantine_role_id", "role_perms", "managers"]
            for field in required_fields:
                if field not in new_config:
                    return await ctx.send(embed=self._embed(f"Missing required field: `{field}`", 0xFF0000))
        
            old_quarantined = self.config.get("quarantined_users", {})
            self.config.update(new_config)
        
            if "quarantined_users" not in new_config:
                self.config["quarantined_users"] = old_quarantined
        
            self.save_config()
            await ctx.send(embed=self._embed(f"Configuration uploaded and applied successfully from `{attachment.filename}`."))
        
        except json.JSONDecodeError as e:
            await ctx.send(embed=self._embed(f"Invalid JSON format: {str(e)}", 0xFF0000))
        except Exception as e:
            await ctx.send(embed=self._embed(f"Error loading config: {str(e)}", 0xFF0000))

    @antinuke.command(name="setlog")
    @is_manager()
    async def setlog(self, ctx, channel: discord.TextChannel):
        self.config["log_channel_id"] = channel.id
        self.save_config()
        await ctx.send(embed=self._embed(f"Logging channel set to {channel.mention}"))

    @antinuke.command(name="setwindow")
    @is_manager()
    async def setwindow(self, ctx, seconds: int):
        if seconds < 1:
            return await ctx.send(embed=self._embed("Window must be at least 1 second.", 0xFF0000))
        self.config["time_window"] = seconds
        self.save_config()
        await ctx.send(embed=self._embed(f"Rate limit window set to {seconds} seconds."))

    @antinuke.command(name="setmaxrestores")
    @is_manager()
    async def setmaxrestores(self, ctx, amount: int):
        if amount < 1:
            return await ctx.send(embed=self._embed("Amount must be at least 1.", 0xFF0000))
        self.config["max_restores_per_minute"] = amount
        self.save_config()
        await ctx.send(embed=self._embed(f"Max restores per minute set to {amount}."))

    @antinuke.command(name="setpingthreshold")
    @is_manager()
    async def setpingthreshold(self, ctx, amount: int):
        if amount < 1:
            return await ctx.send(embed=self._embed("Threshold must be at least 1.", 0xFF0000))
        self.config["mass_ping_threshold"] = amount
        self.save_config()
        await ctx.send(embed=self._embed(f"Mass ping threshold set to {amount} mentions."))

    @antinuke.command(name="setappeal")
    @is_manager()
    async def setappeal(self, ctx, url: str):
        """Set the appeal URL sent in quarantine DMs."""
        self.config["appeal_url"] = url
        self.save_config()
        await ctx.send(embed=self._embed(f"Appeal URL set to {url}"))

    @antinuke.group(name="whitelist", invoke_without_command=True)
    @is_manager()
    async def whitelist_group(self, ctx):
        """Manage whitelist (use subcommands)."""
        await ctx.send_help(ctx.command)

    @whitelist_group.command(name="add")
    @is_manager()
    async def whitelist_add(self, ctx, target_type: str, *, target: str):
        """Add a user or role to whitelist. Usage: antinuke whitelist add user @User"""
        if target_type.lower() == "user":
            member = await commands.MemberConverter().convert(ctx, target)
            if member.id in self.config["whitelist_users"]:
                await ctx.send(embed=self._embed(f"{member.mention} is already whitelisted.", 0xFF0000))
                return
            self.config["whitelist_users"].append(member.id)
            self.save_config()
            await ctx.send(embed=self._embed(f"Added {member.mention} to whitelist. They will never be quarantined."))
        elif target_type.lower() == "role":
            role = await commands.RoleConverter().convert(ctx, target)
            if role.id in self.config["whitelist_roles"]:
                await ctx.send(embed=self._embed(f"{role.mention} is already whitelisted.", 0xFF0000))
                return
            self.config["whitelist_roles"].append(role.id)
            self.save_config()
            await ctx.send(embed=self._embed(f"Added {role.mention} to whitelist. Members with this role will never be quarantined."))
        else:
            await ctx.send(embed=self._embed("Invalid target type. Use `user` or `role`.", 0xFF0000))

    @whitelist_group.command(name="remove")
    @is_manager()
    async def whitelist_remove(self, ctx, target_type: str, *, target: str):
        """Remove a user or role from whitelist."""
        if target_type.lower() == "user":
            member = await commands.MemberConverter().convert(ctx, target)
            if member.id not in self.config["whitelist_users"]:
                await ctx.send(embed=self._embed(f"{member.mention} is not whitelisted.", 0xFF0000))
                return
            self.config["whitelist_users"].remove(member.id)
            self.save_config()
            await ctx.send(embed=self._embed(f"Removed {member.mention} from whitelist."))
        elif target_type.lower() == "role":
            role = await commands.RoleConverter().convert(ctx, target)
            if role.id not in self.config["whitelist_roles"]:
                await ctx.send(embed=self._embed(f"{role.mention} is not whitelisted.", 0xFF0000))
                return
            self.config["whitelist_roles"].remove(role.id)
            self.save_config()
            await ctx.send(embed=self._embed(f"Removed {role.mention} from whitelist."))
        else:
            await ctx.send(embed=self._embed("Invalid target type. Use `user` or `role`.", 0xFF0000))

    @antinuke.command(name="manager")
    @is_manager()
    async def manager_cmd(self, ctx, *, role_name: str):
        clean_target = role_name.replace("<@&", "").replace(">", "").strip()
        role = discord.utils.find(
            lambda r: r.name.lower() == clean_target.lower() or str(r.id) == clean_target,
            ctx.guild.roles
        )
        if not role:
            return await ctx.send(embed=self._embed(f"Role `{role_name}` not found.", 0xFF0000))

        if role.id in self.config["managers"]:
            self.config["managers"].remove(role.id)
            self.config["role_perms"].pop(str(role.id), None)
            await ctx.send(embed=self._embed(f"Removed {role.mention} from managers. Tier reset to MEDIUM."))
        else:
            self.config["managers"].append(role.id)
            self.config["role_perms"][str(role.id)] = "none"
            await ctx.send(embed=self._embed(f"Added {role.mention} as manager. Tier set to NONE."))
        self.save_config()

    @antinuke.command(name="setperm")
    @is_manager()
    async def setperm(self, ctx, tier: str, *, role_name: str = None):
        tier = tier.lower()
        valid = ["none", "min", "low", "medium", "high", "reset"]
        if tier not in valid:
            return await ctx.send(embed=self._embed(f"Invalid tier. Use: {', '.join(valid)}", 0xFF0000))
        if not role_name:
            return await ctx.send(embed=self._embed("Please provide a role name.", 0xFF0000))

        clean_target = role_name.replace("<@&", "").replace(">", "").strip()
        role = discord.utils.find(
            lambda r: r.name.lower() == clean_target.lower() or str(r.id) == clean_target,
            ctx.guild.roles
        )
        if not role:
            return await ctx.send(embed=self._embed(f"Role `{role_name}` not found.", 0xFF0000))

        if tier == "reset":
            self.config["role_perms"].pop(str(role.id), None)
            self.save_config()
            return await ctx.send(embed=self._embed(f"Reset {role.mention} to default MEDIUM tier."))

        self.config["role_perms"][str(role.id)] = tier
        self.save_config()
        await ctx.send(embed=self._embed(f"Set {role.mention} to `{tier.upper()}` tier."))

    @antinuke.command(name="setdeathrole")
    @is_manager()
    async def setdeathrole(self, ctx, role: discord.Role):
        self.config["quarantine_role_id"] = role.id
        self.save_config()
        await ctx.send(embed=self._embed(f"Quarantine role set to {role.mention}"))

    @antinuke.command(name="watchrole")
    @is_manager()
    async def watchrole(self, ctx, role: discord.Role):
        if role.id in self.config["watched_roles"]:
            self.config["watched_roles"].remove(role.id)
            await ctx.send(embed=self._embed(f"Stopped watching {role.mention}"))
        else:
            self.config["watched_roles"].append(role.id)
            await ctx.send(embed=self._embed(f"Now watching {role.mention}"))
        self.save_config()

    @antinuke.command(name="quarantine")
    @is_manager()
    async def quarantine_cmd(self, ctx, member: discord.Member, *, reason: str = "Manual quarantine"):
        success, msg = await self.execute_quarantine(ctx.guild, member, reason, ctx.author)
        color = 0xFF6600 if success else 0xFF0000
        await ctx.send(embed=self._embed(msg, color))

    @antinuke.command(name="unquarantine")
    @is_manager()
    async def unquarantine(self, ctx, member: discord.Member):
        if str(member.id) not in self.config["quarantined_users"]:
            return await ctx.send(embed=self._embed(f"{member.mention} is not quarantined.", 0xFF0000))

        death_role = ctx.guild.get_role(self.config["quarantine_role_id"])
        saved_role_ids = self.config["quarantined_users"][str(member.id)]
        roles_to_restore = [ctx.guild.get_role(rid) for rid in saved_role_ids if ctx.guild.get_role(rid)]

        try:
            if death_role and death_role in member.roles:
                await member.remove_roles(death_role)
            if roles_to_restore:
                await member.add_roles(*roles_to_restore)
            del self.config["quarantined_users"][str(member.id)]
            self.save_config()
            await self.log(ctx.guild, f"Unquarantined {member.mention}")
            await ctx.send(embed=self._embed(f"Unquarantined {member.mention}."))
        except discord.Forbidden:
            await ctx.send(embed=self._embed("Hierarchy error: could not restore all roles.", 0xFF0000))

    # --------------------------------------------------------------------------
    # Event listeners (triggers)
    # --------------------------------------------------------------------------
    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        added_roles = [r for r in after.roles if r not in before.roles]
        watched_added = [r for r in added_roles if r.id in self.config["watched_roles"]]
        if not watched_added:
            return

        culprit = None
        try:
            async for entry in after.guild.audit_logs(limit=3, action=discord.AuditLogAction.member_role_update):
                if entry.target.id == after.id:
                    culprit = entry.user
                    break
        except (discord.Forbidden, discord.HTTPException):
            pass

        # If no culprit found or culprit is bot/whitelisted/manager -> just remove the role and stop
        if culprit is None or culprit.bot or self.is_whitelisted(culprit) or self.is_manager_role(culprit):
            if culprit is not None and self.is_manager_role(culprit):
                # Managers are allowed to assign watched roles
                return
            # Otherwise remove the dangerous role and do nothing else
            await after.remove_roles(*watched_added, reason="AntiNuke: dangerous role assign (culprit unknown/whitelisted)")
            return

        # Record this assignment for potential later revert
        now = time.time()
        for role in watched_added:
            self.role_assignments[culprit.id].append((after.id, role.id, now))

        # Check if this triggers a quarantine
        if await self.check_trigger(culprit, "role_assign"):
            # Quarantine the culprit first
            success, _ = await self.execute_quarantine(after.guild, culprit, "Exceeded dangerous role assignment limits")
            if success:
                # Revert all recent role assignments made by this culprit
                await self.revert_role_assignments(after.guild, culprit)
                # Also remove the role that was just added (already covered by revert)
        else:
            # If threshold not reached, still remove the role to prevent damage? 
            # User requested: only reassign/deassign when threshold reached.
            # So we do NOT remove the role now. We allow the assignment to stay.
            # But for safety, we should at least log it.
            await self.log(after.guild, f"{culprit.mention} assigned dangerous role {', '.join(r.mention for r in watched_added)} to {after.mention}. (Limit not reached)", 0xFFAA00, perpetrator=culprit)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return

        # Managers are exempt
        if self.is_manager_role(message.author):
            return

        typed_pings = re.findall(r'<@!?(\d+)>|<@&(\d+)>', message.content)
        total_pings = len(typed_pings)
        threshold = self.config["mass_ping_threshold"]
        has_many_mentions = total_pings > threshold or message.mention_everyone

        if total_pings > 0 or message.mention_everyone:
            limits = self.get_user_limits(message.author)
            if limits["mention"] != float('inf'):
                if has_many_mentions:
                    if message.channel.permissions_for(message.guild.me).manage_messages:
                        try:
                            await message.delete()
                        except discord.Forbidden:
                            pass

                if await self.check_trigger(message.author, "mention"):
                    await self.execute_quarantine(message.guild, message.author, "Exceeded mass ping limits", moderator=self.bot.user)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        culprit = None
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
                culprit = entry.user
                break
        except (discord.Forbidden, discord.HTTPException):
            pass

        # Managers are exempt: no queue, no quarantine
        if culprit and self.is_manager_role(culprit):
            return

        if culprit is None or culprit.bot or self.get_user_limits(culprit)["delete"] == float('inf'):
            return

        self.pending_restores[culprit.id].append(("channel", channel))
        if await self.check_trigger(culprit, "delete"):
            success, _ = await self.execute_quarantine(channel.guild, culprit, "Exceeded channel deletion limits", moderator=self.bot.user)
            if success:
                await self.process_restores(channel.guild, culprit.id)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        culprit = None
        try:
            async for entry in role.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_delete):
                culprit = entry.user
                break
        except (discord.Forbidden, discord.HTTPException):
            pass

        if culprit and self.is_manager_role(culprit):
            return

        if culprit is None or culprit.bot or self.get_user_limits(culprit)["delete"] == float('inf'):
            return

        self.pending_restores[culprit.id].append(("role", role))
        if await self.check_trigger(culprit, "delete"):
            success, _ = await self.execute_quarantine(role.guild, culprit, "Exceeded role deletion limits", moderator=self.bot.user)
            if success:
                await self.process_restores(role.guild, culprit.id)

    @commands.Cog.listener()
    async def on_command_completion(self, ctx):
        """Track moderation commands and trigger quarantine if limits exceeded."""
        if not ctx.guild or ctx.author.bot:
            return

        # Managers are exempt
        if self.is_manager_role(ctx.author):
            return

        MOD_ACTIONS = {
            "ban", "kick", "mute", "unmute", "hardmute", "unhardmute",
            "nuke", "purge", "vmute", "vunmute", "nick", "temprole", "role"
        }

        if ctx.command and ctx.command.name in MOD_ACTIONS:
            if await self.check_trigger(ctx.author, "mod_action"):
                await self.execute_quarantine(
                    ctx.guild,
                    ctx.author,
                    f"Exceeded moderation action limits (command: {ctx.command.name})",
                    moderator=self.bot.user
                )


async def setup(bot):
    await bot.add_cog(AntiNuke(bot))