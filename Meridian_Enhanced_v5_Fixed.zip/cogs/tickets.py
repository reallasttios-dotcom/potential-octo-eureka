import discord
from discord.ext import commands, tasks
import aiosqlite
import chat_exporter
import io
import re
import datetime
import config

def safe_channel_name(name: str) -> str:
    name = re.sub(r"\s+", "-", name.lower())
    return re.sub(r"[^a-z0-9\-⤷｜]", "", name)[:90] or "ticket"

class TicketDropdown(discord.ui.Select):
    def __init__(self, cog):
        self.cog = cog
        options = [discord.SelectOption(label=m["label"], value=k) for k, m in config.TICKET_CATEGORIES.items()]
        super().__init__(placeholder="Select a category…", min_values=1, max_values=1, options=options, custom_id="ticket:dropdown")

    async def callback(self, interaction: discord.Interaction):
        await self.cog.create_ticket(interaction, self.values[0])

class TicketDropdownView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.add_item(TicketDropdown(cog))

class TicketControlsView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(label="Close", style=discord.ButtonStyle.danger, custom_id="ticket:close", emoji="🔒")
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.cog.close_ticket(interaction)

    @discord.ui.button(label="Claim", style=discord.ButtonStyle.success, custom_id="ticket:claim", emoji="🙋‍♂️")
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.cog.claim_ticket(interaction)

class Tickets(commands.Cog):
    """Advanced ticket system with categories, logging, and chat exports."""
    def __init__(self, bot):
        self.bot = bot

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        if hasattr(self.bot, 'imaging'):
            try:
                template = kwargs.pop("_template", "general")
                return await self.bot.imaging.render_and_send(
                    ctx_or_channel=reply_to or send_to,
                    template_name=template,
                    filename=f"{kwargs.get('card_type', template)}.png",
                    reply=(reply_to is not None),
                    embed_title=fallback_embed.title if fallback_embed else f"Ticket: {template.replace('_', ' ').title()}",
                    embed_description=fallback_embed.description if fallback_embed else None,
                    embed_color=fallback_embed.color.value if fallback_embed else 0x5865F2,
                    **kwargs
                )
            except Exception as exc:
                print(f"[Tickets imaging] {exc}")
        if reply_to: return await reply_to.reply(embed=fallback_embed)
        return await send_to.send(embed=fallback_embed)

    async def cog_load(self):
        await self.ticket_db_init()
        self.bot.add_view(TicketDropdownView(self))
        self.bot.add_view(TicketControlsView(self))
        if not self.auto_archive_task.is_running():
            self.auto_archive_task.start()

    async def ticket_db_init(self):
        async with aiosqlite.connect(config.TICKET_DB_PATH) as db:
            await db.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                owner_id INTEGER NOT NULL,
                category_key TEXT NOT NULL,
                ticket_number INTEGER NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                last_activity TEXT NOT NULL,
                assigned_staff_id INTEGER
            )
            """)
            await db.commit()

    async def create_ticket(self, interaction, category_key):
        category_data = config.TICKET_CATEGORIES[category_key]
        guild = interaction.guild
        owner = interaction.user

        async with aiosqlite.connect(config.TICKET_DB_PATH) as db:
            async with db.execute("SELECT MAX(ticket_number) FROM tickets WHERE guild_id = ?", (guild.id,)) as cursor:
                row = await cursor.fetchone()
                ticket_number = (row[0] or 0) + 1

        channel_name = safe_channel_name(f"{category_data['label']}-{ticket_number}")
        category = guild.get_channel(category_data.get("parent_id") or config.TICKET_CATEGORY_ID)
        
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            owner: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True)
        }
        
        channel = await guild.create_text_channel(name=channel_name, category=category, overwrites=overwrites)
        
        async with aiosqlite.connect(config.TICKET_DB_PATH) as db:
            await db.execute(
                "INSERT INTO tickets (guild_id, channel_id, owner_id, category_key, ticket_number, status, created_at, last_activity) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (guild.id, channel.id, owner.id, category_key, ticket_number, "open", datetime.datetime.utcnow().isoformat(), datetime.datetime.utcnow().isoformat())
            )
            await db.commit()

        embed = discord.Embed(title=f"Ticket #{ticket_number}", description=f"Welcome {owner.mention}! Staff will be with you shortly.\nCategory: **{category_data['label']}**", color=0x5865F2)
        if hasattr(self.bot, 'imaging'):
            await self.bot.imaging.render_and_send(
                ctx_or_channel=channel,
                template_name="ticket",
                filename=f"ticket_{ticket_number}.png",
                embed_title=f"Ticket #{ticket_number}",
                view=TicketControlsView(self),
                ticket_id=str(ticket_number), user=owner, status="open",
                priority="medium", subject=category_data['label']
            )
        else:
            await channel.send(embed=embed, view=TicketControlsView(self))
            
        await interaction.response.send_message(f"✅ Ticket created: {channel.mention}", ephemeral=True)

    async def close_ticket(self, interaction):
        channel = interaction.channel
        async with aiosqlite.connect(config.TICKET_DB_PATH) as db:
            async with db.execute("SELECT * FROM tickets WHERE channel_id = ?", (channel.id,)) as cursor:
                ticket = await cursor.fetchone()
        
        if not ticket: return await interaction.response.send_message("This channel is not a ticket.", ephemeral=True)
        
        await interaction.response.send_message("🔒 Closing ticket and exporting transcript...", ephemeral=True)
        
        transcript = await chat_exporter.export(channel)
        if transcript:
            file = discord.File(io.BytesIO(transcript.encode()), filename=f"transcript-{channel.name}.html")
            log_channel = interaction.guild.get_channel(config.TICKET_LOG_CHANNEL_ID)
            if log_channel:
                await log_channel.send(f"Ticket #{ticket[5]} closed by {interaction.user.mention}.", file=file)
        
        await channel.delete(reason=f"Ticket closed by {interaction.user}")
        async with aiosqlite.connect(config.TICKET_DB_PATH) as db:
            await db.execute("UPDATE tickets SET status = ? WHERE channel_id = ?", ("closed", channel.id))
            await db.commit()

    async def claim_ticket(self, interaction):
        channel = interaction.channel
        async with aiosqlite.connect(config.TICKET_DB_PATH) as db:
            await db.execute("UPDATE tickets SET assigned_staff_id = ? WHERE channel_id = ?", (interaction.user.id, channel.id))
            await db.commit()
        await interaction.response.send_message(f"🙋‍♂️ Ticket claimed by {interaction.user.mention}!", ephemeral=False)

    @tasks.loop(minutes=10)
    async def auto_archive_task(self):
        await self.bot.wait_until_ready()

    # ─── Tickets Sub-Cog ──────────────────────────────────────────────

    @commands.group(name="ticket", invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    async def ticket_group(self, ctx):
        """Ticket system management."""
        await ctx.send_help(ctx.command)

    @ticket_group.command(name="panel")
    async def ticket_panel(self, ctx):
        """Post the ticket creation panel."""
        embed = discord.Embed(title="🎫 Support System", description="Select a category below to open a support ticket.", color=0x5865F2)
        if hasattr(self.bot, 'imaging'):
            await self.bot.imaging.render_and_send(
                ctx_or_channel=ctx.channel,
                template_name="ticket",
                filename="ticket_panel.png",
                embed_title="Support System",
                embed_description="Select a category below to open a ticket.",
                view=TicketDropdownView(self),
                ticket_id="PANEL", user=ctx.author, status="open",
                priority="low", subject="Support Center"
            )
        else:
            await ctx.send(embed=embed, view=TicketDropdownView(self))

    @ticket_group.command(name="add")
    async def add_user(self, ctx, member: discord.Member):
        """Add a user to the current ticket."""
        await ctx.channel.set_permissions(member, read_messages=True, send_messages=True)
        await ctx.send(f"✅ Added {member.mention} to the ticket.")

    @ticket_group.command(name="remove")
    async def remove_user(self, ctx, member: discord.Member):
        """Remove a user from the current ticket."""
        await ctx.channel.set_permissions(member, overwrite=None)
        await ctx.send(f"✅ Removed {member.mention} from the ticket.")

async def setup(bot):
    await bot.add_cog(Tickets(bot))
