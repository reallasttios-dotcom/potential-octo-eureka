import discord
from discord.ext import commands
from discord.ext import tasks
import asyncio
import time

DISBOARD_ID = 302050872383242240
BUMP_COOLDOWN = 7200  # 2 hours in seconds


class BumpReminder(commands.Cog):
    """DISBOARD bump reminders with leaderboard and restart persistence."""

    def __init__(self, bot):
        self.bot = bot
        self._pending: dict[int, asyncio.Task] = {}

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[BumpReminder imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    async def cog_load(self):
        """Restore pending bump reminders from DB after restart."""
        await self.bot.wait_until_ready()
        now = time.time()
        async with self.bot.db.execute("SELECT guild, next_bump_time FROM bump_schedule") as cursor:
            rows = await cursor.fetchall()
        for row in rows:
            guild_id = int(row["guild"])
            next_time = row["next_bump_time"]
            remaining = max(0, next_time - now)
            guild = self.bot.get_guild(guild_id)
            if guild:
                task = asyncio.create_task(self._delayed_reminder(guild, None, remaining))
                self._pending[guild_id] = task

    async def _delayed_reminder(self, guild: discord.Guild, bumper: discord.Member | None, delay: float):
        await asyncio.sleep(delay)
        # Find a suitable channel (first text channel the bot can send in)
        send_channel = None
        for ch in guild.text_channels:
            if ch.permissions_for(guild.me).send_messages:
                send_channel = ch
                break
        if not send_channel:
            return

        content = bumper.mention if bumper else ""
        embed = discord.Embed(
            title="⏰ Time to Bump!",
            description="It's been 2 hours! Use `/bump` to keep the server growing.",
            color=0xFFA500,
        )
        await self._send_card(send_channel, embed,
            card_type="bump",
            bumper_name=bumper.display_name if bumper else "Unknown",
            bumper_id=bumper.id if bumper else 0,
            bump_count=0,
            next_bump_in="Now!",
            guild_name=guild.name,
        )

        # Clear schedule from DB
        await self.bot.db.execute("DELETE FROM bump_schedule WHERE guild = ?", (str(guild.id),))
        await self.bot.db.commit()
        self._pending.pop(guild.id, None)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.id != DISBOARD_ID:
            return
        if not message.embeds:
            return
        desc = message.embeds[0].description or ""
        if "Bump done!" not in desc:
            return

        bumper = message.interaction.user if message.interaction else None
        guild = message.guild

        # Acknowledge bump
        mention = bumper.mention if bumper else "someone"
        ack_embed = discord.Embed(
            description=f"🎉 **Bump received!** Thanks {mention}. I'll remind you in 2 hours.",
            color=0xFFA500,
        )
        bump_count = 0
        if bumper and guild:
            async with self.bot.db.execute(
                "SELECT count FROM bump_log WHERE guild = ? AND user_id = ?",
                (str(guild.id), str(bumper.id)),
            ) as cur:
                r = await cur.fetchone()
                bump_count = (r["count"] if r else 0) + 1
        await self._send_card(message.channel, ack_embed,
            card_type="bump",
            bumper_name=bumper.display_name if bumper else "someone",
            bumper_id=bumper.id if bumper else 0,
            bump_count=bump_count,
            next_bump_in="2 hours",
            guild_name=guild.name if guild else None,
        )

        # Record bump in leaderboard
        if bumper and guild:
            await self.bot.db.execute(
                """INSERT INTO bump_log (guild, user_id, count) VALUES (?, ?, 1)
                   ON CONFLICT(guild, user_id) DO UPDATE SET count = count + 1""",
                (str(guild.id), str(bumper.id)),
            )
            # Save next bump time for restart survival
            next_time = time.time() + BUMP_COOLDOWN
            await self.bot.db.execute(
                "INSERT OR REPLACE INTO bump_schedule (guild, next_bump_time) VALUES (?, ?)",
                (str(guild.id), next_time),
            )
            await self.bot.db.commit()

        # Cancel existing reminder task if any
        if guild and guild.id in self._pending:
            self._pending[guild.id].cancel()

        # Schedule new reminder
        if guild:
            task = asyncio.create_task(self._delayed_reminder(guild, bumper, BUMP_COOLDOWN))
            self._pending[guild.id] = task

    @commands.command(name="bumplb", aliases=["bumpleaderboard"])
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def bumplb(self, ctx):
        """Show the bump leaderboard for this server."""
        async with self.bot.db.execute(
            "SELECT user_id, count FROM bump_log WHERE guild = ? ORDER BY count DESC LIMIT 10",
            (str(ctx.guild.id),),
        ) as cursor:
            rows = await cursor.fetchall()

        if not rows:
            return await ctx.send(embed=discord.Embed(description="No bumps recorded yet.", color=0xFFA500))

        medals = ["🥇", "🥈", "🥉"]
        lines = []
        for i, row in enumerate(rows):
            medal = medals[i] if i < 3 else f"**#{i + 1}**"
            lines.append(f"{medal} <@{row['user_id']}> — **{row['count']}** bump{'s' if row['count'] != 1 else ''}")

        embed = discord.Embed(
            title=f"🏆 Bump Leaderboard — {ctx.guild.name}",
            description="\n".join(lines),
            color=0xFFA500,
        )
        stats_pairs = []
        for i, row in enumerate(rows):
            medal = medals[i] if i < 3 else f"#{i + 1}"
            user = self.bot.get_user(int(row['user_id']))
            name = user.display_name if user else f"User {row['user_id']}"
            stats_pairs.append((f"{medal} {name}", str(row['count'])))
        await self._send_card(ctx, embed,
            card_type="stats",
            title=f"Bump Leaderboard — {ctx.guild.name}",
            stats=stats_pairs,
            footer=f"Top {len(rows)} bumpers",
        )


async def setup(bot):
    await bot.add_cog(BumpReminder(bot))
