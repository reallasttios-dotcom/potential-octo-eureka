import discord
from discord.ext import commands
import io
import zipfile
import re
import asyncio

class EmojiMaker(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.valid_exts = ('.jpg', '.jpeg', '.png', '.gif')

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[Emoji imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    def clean_name(self, filename):
        # Remove extension and clean special characters
        name = filename.rsplit('.', 1)[0]
        name = re.sub(r'[^a-zA-Z0-9_]', '_', name)
        return name if len(name) >= 2 else f"emoji_{name}"

    async def process_emoji(self, ctx, name, image_bytes):
        try:
            await ctx.guild.create_custom_emoji(
                name=name,
                image=image_bytes,
                reason=f"Bulk upload by {ctx.author}"
            )
            return True
        except Exception:
            return False

    @commands.command(name="uploademojis")
    @commands.has_permissions(manage_expressions=True)
    async def upload_emojis(self, ctx):
        if not ctx.message.attachments:
            return await ctx.send("Attach images or a ZIP file!")

        status_msg = await ctx.send("⌛ Processing... this might take a bit to avoid rate limits.")
        success_count = 0
        total_attempted = 0
        
        for attachment in ctx.message.attachments:
            if total_attempted >= 50: break

            # Handle ZIP Files
            if attachment.filename.endswith('.zip'):
                zip_data = await attachment.read()
                with zipfile.ZipFile(io.BytesIO(zip_data)) as archive:
                    for file in archive.namelist():
                        if total_attempted >= 50: break
                        if file.lower().endswith(self.valid_exts) and not file.startswith('__MACOSX'):
                            with archive.open(file) as f:
                                img_data = f.read()
                                if await self.process_emoji(ctx, self.clean_name(file), img_data):
                                    success_count += 1
                                total_attempted += 1
                                await asyncio.sleep(1.5) # The "Don't Ban Me" pause

            # Handle Direct Image Attachments
            elif attachment.filename.lower().endswith(self.valid_exts):
                img_data = await attachment.read()
                if await self.process_emoji(ctx, self.clean_name(attachment.filename), img_data):
                    success_count += 1
                total_attempted += 1
                await asyncio.sleep(1.5)

        embed = discord.Embed(
            title="Emoji Upload Complete",
            description=f"Added **{success_count}** emojis out of **{total_attempted}** attempted.",
            color=0x57F287 if success_count == total_attempted else 0xFFA500,
        )
        await status_msg.delete()
        await self._send_card(
            ctx, embed,
            card_type="stats",
            title="Emoji Upload Complete",
            stats=[("Successful", str(success_count)), ("Attempted", str(total_attempted)), ("Failed", str(total_attempted - success_count))],
        )

async def setup(bot):
    await bot.add_cog(EmojiMaker(bot))
