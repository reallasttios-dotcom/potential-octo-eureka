import discord
from discord.ext import commands

class Security(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.authorized_guilds = [1478270269285073018, 1490239101721378866]

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[Security imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        if guild.id not in self.authorized_guilds:
            print(f"Unauthorized invite attempt: {guild.name} ({guild.id})")
            
            try:
                target_channel = next((x for x in guild.text_channels if x.permissions_for(guild.me).send_messages), None)
                if target_channel:
                    fallback = discord.Embed(
                        title="Unauthorized Server Detected",
                        description="This bot is private property of Meridian. Self-destructing...",
                        color=0xFF0000,
                    )
                    await self._send_card(
                        target_channel, fallback,
                        card_type="info",
                        title="Unauthorized Server Detected",
                        description="This bot is private property of Meridian. Self-destructing...",
                    )
            except Exception:
                pass

            await guild.leave()

    @commands.Cog.listener()
    async def on_ready(self):
        # Double check on startup in case someone added it while the bot was offline
        for guild in self.bot.guilds:
            if guild.id not in self.authorized_guilds:
                print(f"Cleaning up unauthorized server: {guild.name}")
                await guild.leave()

async def setup(bot):
    await bot.add_cog(Security(bot))