import discord
from discord.ext import commands
import re


def err(text):
    return discord.Embed(description=f"❌ {text}", color=0xED4245)


def ok(text):
    return discord.Embed(description=f"✅ {text}", color=0x57F287)


def normalize_emoji(emoji: str) -> str:
    """Normalize an emoji string for consistent DB storage."""
    # Strip variation selectors
    return emoji.strip()


class ReactionRoles(commands.Cog):
    """Reaction role system — assign roles when members react to a message."""

    def __init__(self, bot):
        self.bot = bot
        self._cache: dict[tuple[str, str, str], int] = {}

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[ReactionRoles imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    async def cog_load(self):
        async with self.bot.db.execute(
            "SELECT guild, message_id, emoji, role_id FROM reaction_roles"
        ) as cursor:
            rows = await cursor.fetchall()
        for row in rows:
            self._cache[(row["guild"], row["message_id"], row["emoji"])] = int(row["role_id"])

    def _get_role_id(self, guild_id: str, message_id: str, emoji: str) -> int | None:
        return self._cache.get((guild_id, str(message_id), normalize_emoji(emoji)))

    # ─── Listeners ────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        if not payload.guild_id or payload.user_id == self.bot.user.id:
            return
        emoji = normalize_emoji(str(payload.emoji))
        role_id = self._get_role_id(str(payload.guild_id), str(payload.message_id), emoji)
        if not role_id:
            return
        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        role = guild.get_role(role_id)
        if not role:
            return
        member = guild.get_member(payload.user_id) or await guild.fetch_member(payload.user_id)
        if not member or member.bot:
            return
        try:
            await member.add_roles(role, reason="Reaction role")
        except discord.Forbidden:
            pass

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        if not payload.guild_id or payload.user_id == self.bot.user.id:
            return
        emoji = normalize_emoji(str(payload.emoji))
        role_id = self._get_role_id(str(payload.guild_id), str(payload.message_id), emoji)
        if not role_id:
            return
        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        role = guild.get_role(role_id)
        if not role:
            return
        member = guild.get_member(payload.user_id) or await guild.fetch_member(payload.user_id)
        if not member or member.bot:
            return
        try:
            await member.remove_roles(role, reason="Reaction role removed")
        except discord.Forbidden:
            pass

    # ─── Setup commands ────────────────────────────────────────────────────

    @commands.group(name="rr", aliases=["reactionrole"], invoke_without_command=True)
    @commands.has_permissions(manage_roles=True)
    async def rr(self, ctx):
        """Reaction roles management. Subcommands: add, remove, list, clear."""
        embed = discord.Embed(
            title="⚙️ Reaction Roles",
            description=(
                "`!rr add <message_id> <emoji> @role` — bind an emoji to a role\n"
                "`!rr remove <message_id> <emoji>` — remove a binding\n"
                "`!rr list` — list all bindings in this server\n"
                "`!rr clear <message_id>` — remove all bindings for a message"
            ),
            color=0x5865F2,
        )
        await self._send_card(ctx, embed,
            card_type="info",
            title="⚙️ Reaction Roles",
            description="add · remove · list · clear")

    @rr.command(name="add")
    @commands.has_permissions(manage_roles=True)
    async def rr_add(self, ctx, message_id: int, emoji: str, role: discord.Role):
        """Add a reaction role binding.
        Usage: !rr add <message_id> <emoji> @role"""
        guild_id = str(ctx.guild.id)
        msg_id = str(message_id)
        e = normalize_emoji(emoji)

        # Verify the message exists (try current channel first, then all channels)
        msg = None
        try:
            msg = await ctx.channel.fetch_message(message_id)
        except discord.NotFound:
            for channel in ctx.guild.text_channels:
                if channel == ctx.channel:
                    continue
                try:
                    msg = await channel.fetch_message(message_id)
                    break
                except Exception:
                    continue
        except Exception:
            pass

        if not msg:
            return await ctx.send(embed=err(f"Could not find message `{message_id}` in this server."))

        # Check role hierarchy
        if role >= ctx.guild.me.top_role:
            return await ctx.send(embed=err("I can't assign that role — it's higher than or equal to my top role."))

        await self.bot.db.execute(
            "INSERT OR REPLACE INTO reaction_roles (guild, message_id, emoji, role_id) VALUES (?, ?, ?, ?)",
            (guild_id, msg_id, e, str(role.id)),
        )
        await self.bot.db.commit()
        self._cache[(guild_id, msg_id, e)] = role.id

        # React to the message so users can see what to click
        try:
            await msg.add_reaction(emoji)
        except Exception:
            pass

        await ctx.send(embed=ok(f"Bound {emoji} → {role.mention} on [that message]({msg.jump_url})."), delete_after=10)

    @rr.command(name="remove")
    @commands.has_permissions(manage_roles=True)
    async def rr_remove(self, ctx, message_id: int, emoji: str):
        """Remove a reaction role binding."""
        guild_id = str(ctx.guild.id)
        msg_id = str(message_id)
        e = normalize_emoji(emoji)

        key = (guild_id, msg_id, e)
        if key not in self._cache:
            return await ctx.send(embed=err("No binding found for that message + emoji combination."))

        del self._cache[key]
        await self.bot.db.execute(
            "DELETE FROM reaction_roles WHERE guild = ? AND message_id = ? AND emoji = ?",
            (guild_id, msg_id, e),
        )
        await self.bot.db.commit()
        await ctx.send(embed=ok(f"Removed binding for {emoji} on message `{message_id}`."), delete_after=10)

    @rr.command(name="list")
    @commands.has_permissions(manage_roles=True)
    async def rr_list(self, ctx):
        """List all reaction role bindings in this server."""
        guild_id = str(ctx.guild.id)
        async with self.bot.db.execute(
            "SELECT message_id, emoji, role_id FROM reaction_roles WHERE guild = ? ORDER BY message_id",
            (guild_id,),
        ) as cursor:
            rows = await cursor.fetchall()

        if not rows:
            return await ctx.send(embed=discord.Embed(description="No reaction roles configured in this server.", color=0x5865F2))

        lines = []
        prev_msg_id = None
        for row in rows:
            msg_id = row["message_id"]
            if msg_id != prev_msg_id:
                lines.append(f"\n**Message `{msg_id}`**")
                prev_msg_id = msg_id
            role = ctx.guild.get_role(int(row["role_id"]))
            role_str = role.mention if role else f"*(deleted role {row['role_id']})*"
            lines.append(f"  {row['emoji']} → {role_str}")

        embed = discord.Embed(
            title=f"⚙️ Reaction Roles — {ctx.guild.name}",
            description="\n".join(lines)[:4000],
            color=0x5865F2,
        )
        await self._send_card(ctx, embed,
            card_type="info",
            title=f"⚙️ Reaction Roles — {ctx.guild.name}",
            description="\n".join(lines)[:500])

    @rr.command(name="clear")
    @commands.has_permissions(manage_roles=True)
    async def rr_clear(self, ctx, message_id: int):
        """Remove ALL reaction role bindings for a specific message."""
        guild_id = str(ctx.guild.id)
        msg_id = str(message_id)

        # Remove from cache
        keys_to_remove = [(g, m, e) for (g, m, e) in list(self._cache.keys()) if g == guild_id and m == msg_id]
        for key in keys_to_remove:
            del self._cache[key]

        await self.bot.db.execute(
            "DELETE FROM reaction_roles WHERE guild = ? AND message_id = ?",
            (guild_id, msg_id),
        )
        await self.bot.db.commit()
        await ctx.send(embed=ok(f"Cleared **{len(keys_to_remove)}** binding(s) for message `{message_id}`."), delete_after=10)


async def setup(bot):
    await bot.add_cog(ReactionRoles(bot))
