import discord
from discord.ext import commands
import asyncio

class AppealButton(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Open Appeal Case", 
        style=discord.ButtonStyle.danger, 
        custom_id="meridian_appeal_btn"
    )
    async def open_appeal(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        
        guild = interaction.guild
        user = interaction.user
        
        channel_name = f"𝖢𝖺𝗌𝖾-{user.name.lower()}".replace(" ", "-")
        existing_channel = discord.utils.get(guild.channels, name=channel_name)
        
        if existing_channel:
            return await interaction.followup.send(f"You already have a case open: {existing_channel.mention}", ephemeral=True)

        staff_role = discord.utils.get(guild.roles, name="Staff")

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
        }
        if staff_role:
            overwrites[staff_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True)

        try:
            channel = await guild.create_text_channel(name=channel_name, overwrites=overwrites)
            await interaction.followup.send(f"Case created at {channel.mention}", ephemeral=True)
            
            embed = discord.Embed(
                title="MERIDIAN CHECKPOINT: INTERROGATION",
                description=f"Welcome {user.mention}. Provide your ID, reason for punishment, and your defense. Staff will review shortly.",
                color=0xff6600
            )
            
            await channel.send(
                content="<@&1490239435256758303>", 
                embed=embed, 
                view=CloseCaseView()
            )
        except Exception as e:
            await interaction.followup.send(f"An error occurred while creating the channel: {e}", ephemeral=True)

class CloseCaseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Archive Case", style=discord.ButtonStyle.secondary, custom_id="archive_case_btn")
    async def archive_case(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.manage_channels:
            return await interaction.response.send_message("Only staff can archive cases.", ephemeral=True)
            
        guild = interaction.guild
        channel = interaction.channel
        
        archive_cat = discord.utils.get(guild.categories, name="ARCHIVES")
        if not archive_cat:
            archive_cat = await guild.create_category("ARCHIVES")

        await interaction.response.send_message("Archiving channel...", ephemeral=True)

        staff_role = discord.utils.get(guild.roles, name="Staff")
        
        new_overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
        }
        if staff_role:
            new_overwrites[staff_role] = discord.PermissionOverwrite(read_messages=True, send_messages=False)

        await channel.edit(category=archive_cat, overwrites=new_overwrites, name=f"closed-{channel.name}")
        await channel.send("─── **CASE CLOSED & ARCHIVED** ───")

class Appeals(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.em = bot.get_cog("EmojiManager")
    def e(self, key):
        return self.em.get_emoji("Appeals", key) if self.em else ""

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        """Try imaging render; silently fall back to embed on failure."""
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        if hasattr(self.bot, 'imaging'):
            try:
                b = await self.bot.imaging.render("general", **kwargs)
                f = self.bot.imaging.make_file(b, f"{kwargs.get('card_type', 'card')}.png")
                if reply_to is not None:
                    return await reply_to.reply(file=f, mention_author=False, **extra)
                return await send_to.send(file=f, **extra)
            except Exception as exc:
                print(f"[Appeals imaging] {exc}")
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    @commands.command(name="postpanel")
    @commands.has_permissions(administrator=True)
    async def postpanel(self, ctx):
        charter = discord.Embed(
            title=f"{self.e('ping_4')} THE MERIDIAN CHARTER",
            description="Educational, historical, religious, and analytical content is permitted, provided it does **NOT** promote, glorify, or advocate harm or extremist groups.",
            color=0xff6600
        )
        charter.set_image(url="https://cdn.discordapp.com/attachments/1483902517988294757/1489841389083557979/Untitled79_20260323214410.png")

        infractions = discord.Embed(
            title=f"{self.e('emoji_62')} INFRACTIONS & SEVERITY",
            description="**LEVEL 1: Verbal Warn / Deletion**\n-# • Pointless debates\n-# • Off-topic spam\n-# • Ping spam\n-# • Low-effort posting\n\n**LEVEL 2: Warn / Short Mute (1-10m)**\n-# • Insults\n-# • Harassment\n-# • Uncivilized debates\n\n**LEVEL 3: Mute / Kick / Warn**\n-# • NSFW outside proper channels\n-# • Gore/shock edits\n-# • Death packs\n-# • Symbolic extremist imagery\n-# • E-sexting/dating\n\n**LEVEL 4: Kick / Ban / Discord Report**\n-# • Promoting self-harm\n-# • Self-promotion\n-# • Extremist/Pedo/Incest jokes\n\n**LEVEL 5: Immediate Permaban / Discord Report**\n-# • Pedo/Incest/Zoophilia\n-# • Real extremist advocacy\n-# • Doxxing/IRL threats\n-# • Alt evasion\n-# • Mass DMing\n\n**>>> AUTOMATIC STRIKES**\n<a:ping_4:1480403789058937015> 3 Warnings = Mute\n<a:ping_4:1480403789058937015> 6 Warnings = Timeout\n<a:ping_4:1480403789058937015> 9 Warnings = Kick\n<a:ping_4:1480403789058937015> 12+ Warnings = Ban Review",
            color=0xff6600
        )
        infractions.set_image(url="https://cdn.discordapp.com/attachments/1483902517988294757/1489841390014959717/Untitled79_20260323214339.png")

        process = discord.Embed(
            title="HOW TO APPEAL",
            description="Click the button below to start a private case. Lying or trolling will result in a permanent blacklist.",
            color=0xff6600
        )

        await ctx.send(embeds=[charter, infractions, process], view=AppealButton())
        try:
            await ctx.message.delete()
        except Exception:
            pass

async def setup(bot):
    bot.add_view(AppealButton()) 
    bot.add_view(CloseCaseView())
    await bot.add_cog(Appeals(bot))