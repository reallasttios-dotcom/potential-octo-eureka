import discord
from discord.ext import commands
from discord.gateway import DiscordWebSocket

# --- THE STABLE WRAPPER ---
async def identify_patch(self):
    # Store the original send_as_json method for this instance
    original_send = self.send_as_json

    async def hooked_send(data):
        # Intercept the identify payload (Opcode 2)
        if data.get('op') == self.IDENTIFY:
            # Inject the mobile spoofing
            data['d']['properties']['$browser'] = 'Discord Android'
            data['d']['properties']['$os'] = 'android'
        
        # Pass the (potentially modified) data to the real send method
        await original_send(data)

    # Swap the instance's send method with our hook
    self.send_as_json = hooked_send
    
    # Now call the original identify logic. 
    # It will build the payload and call our hooked_send.
    await self._old_identify()

# Apply the patch to the class
if not hasattr(DiscordWebSocket, '_old_identify'):
    DiscordWebSocket._old_identify = DiscordWebSocket.identify
    DiscordWebSocket.identify = identify_patch

class ActivityCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _send_card(self, target, fallback_embed, reply_to=None, delete_after=None, **kwargs):
        send_to = target if hasattr(target, 'send') else getattr(target, 'channel', target)
        extra = {"delete_after": delete_after} if delete_after is not None else {}
        
        if hasattr(self.bot, 'imaging'):
            try:
                # Use the enhanced render_and_send method
                return await self.bot.imaging.render_and_send(
                    ctx_or_channel=reply_to or send_to,
                    template_name="general",
                    filename=f"{kwargs.get('card_type', 'card')}.png",
                    reply=(reply_to is not None),
                    embed_title=kwargs.get("title"),
                    embed_description=kwargs.get("description"),
                    embed_color=fallback_embed.color.value if fallback_embed else None,
                    **kwargs
                )
            except Exception as exc:
                print(f"[Activity imaging] {exc}")
        
        if reply_to is not None:
            return await reply_to.reply(embed=fallback_embed, mention_author=False, **extra)
        return await send_to.send(embed=fallback_embed, **extra)

    @commands.command(name="botstatus")
    @commands.is_owner()
    async def botstatus(self, ctx):
        """Show the current bot activity and status."""
        activity = self.bot.activity
        a_name = activity.name if activity else "None"
        a_type = activity.type.name if activity else "N/A"
        embed = discord.Embed(
            title="Bot Status",
            description=f"**Activity:** {a_type.capitalize()} {a_name}\n**Latency:** {round(self.bot.latency * 1000)}ms\n**Guilds:** {len(self.bot.guilds)}",
            color=0xFF6600,
        )
        await self._send_card(
            ctx, embed,
            card_type="info",
            title="Bot Status",
            description=f"Activity: {a_type.capitalize()} {a_name}\nLatency: {round(self.bot.latency * 1000)}ms\nGuilds: {len(self.bot.guilds)}",
        )

    @commands.Cog.listener()
    async def on_ready(self):
        # Configure your Rich Presence
        # 'WATCHING' status with buttons and images
        activity = discord.Activity(
            type=discord.ActivityType.watching,
            name="MERIDIAN",
            details="Currently online, looking for commands",
            state="",
            assets={
                "large_image": "server", # Asset name from Dev Portal
                "large_text": "The server icon"
            },
            buttons=[
                {"label": "Redirect to Meridian", "url": "https://discord.gg/meri"}
            ]
        )

        await self.bot.change_presence(status=discord.Status.online, activity=activity)
        print(f"Activity Loaded | Spoof: Android | User: {self.bot.user}")

async def setup(bot):
    await bot.add_cog(ActivityCog(bot))
