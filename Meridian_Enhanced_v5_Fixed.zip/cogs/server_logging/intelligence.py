import discord
from discord.ext import commands
from typing import Dict, List, Optional, Tuple, Any, Set, Union
from datetime import datetime, timedelta
from collections import defaultdict
import asyncio
import math
from enum import Enum


class RiskLevel(Enum):
    """Risk level enumeration"""
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"


class AnomalyType(Enum):
    """Types of anomalies that can be detected"""
    RAPID_JOIN = "rapid_join"
    RAPID_LEAVE = "rapid_leave"
    MASS_ROLE_ASSIGN = "mass_role_assign"
    MASS_CHANNEL_CREATE = "mass_channel_create"
    MASS_WEBHOOK_CREATE = "mass_webhook_create"
    SUSPICIOUS_PATTERN = "suspicious_pattern"
    ACTION_CHAIN = "action_chain"
    PERMISSION_ESCALATION = "permission_escalation"


class IntelligenceCog(commands.Cog):
    """Advanced intelligence, risk scoring, behavior analysis, and anomaly detection"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logging_cog = None
        
        self.user_behavior: Dict[int, Dict[str, Any]] = {}
        self.user_risk_history: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
        self.user_action_timeline: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
        self.high_risk_watchlist: Dict[int, Dict[str, Any]] = {}
        
        server_default = {
            "risk_score": 0,
            "anomaly_count": 0,
            "suspicious_events": [],
            "last_raid_attempt": None,
            "raid_probability": 0,
            "heatmap_data": defaultdict(int),
            "activity_peaks": [],
            "mod_leaderboard": defaultdict(int),
            "risk_trend": [],
            "anomaly_history": []
        }
        self.server_intelligence: Dict[int, Dict[str, Any]] = defaultdict(lambda: server_default.copy())
        
        self.suspicious_patterns: Dict[str, List[str]] = {
            "join_spam": ["member_join", "member_join", "member_join"],
            "raid_pattern": ["member_join", "role_assign", "channel_create", "webhook_create"],
            "nuke_pattern": ["channel_create", "channel_create", "role_assign_admin", "permission_change"],
            "backdoor_pattern": ["bot_add", "role_assign_admin", "webhook_create"],
            "griefing_pattern": ["member_join", "message_delete_mass", "member_leave"]
        }
        
        self.risk_escalation: Dict[int, List[Tuple[datetime, int, str]]] = defaultdict(list)
        
        self.heatmap_data: Dict[int, Dict[int, int]] = defaultdict(lambda: defaultdict(int))
        
        self.anomaly_thresholds = {
            "join_rate": 15,
            "leave_rate": 15,
            "role_change_rate": 10,
            "channel_create_rate": 8,
            "message_delete_rate": 20,
            "permission_change_rate": 5
        }
        
    async def cog_load(self):
        """Initialize cog and get reference to main logging cog"""
        await self.bot.wait_until_ready()
        self.logging_cog = self.bot.get_cog("LoggingCog")
        
        asyncio.create_task(self.risk_escalation_monitor())
        asyncio.create_task(self.heatmap_updater())
        asyncio.create_task(self.anomaly_scanner())
        
    def get_emoji(self, key: str) -> str:
        """Get emoji from main logging cog"""
        if self.logging_cog and hasattr(self.logging_cog, 'get_emoji'):
            return self.logging_cog.get_emoji(key)
        return ""
    
    async def should_run_intelligence(self) -> bool:
        """Check if intelligence features should run"""
        return True
    
    def calculate_risk_level(self, risk_score: int) -> RiskLevel:
        """Convert numeric risk score to risk level"""
        if risk_score >= 75:
            return RiskLevel.CRITICAL
        elif risk_score >= 50:
            return RiskLevel.HIGH
        elif risk_score >= 25:
            return RiskLevel.MEDIUM
        else:
            return RiskLevel.LOW
    
    async def update_user_behavior(self, user_id: int, action: str, details: Dict[str, Any]):
        """Update user behavior profile with new action"""
        if user_id not in self.user_behavior:
            self.user_behavior[user_id] = {
                "first_seen": datetime.now(),
                "action_count": 0,
                "action_types": defaultdict(int),
                "risk_score": 0,
                "flags": [],
                "trust_score": 100,
                "pattern_matches": [],
                "last_activity": datetime.now(),
                "action_timeline": []
            }
        
        behavior = self.user_behavior[user_id]
        behavior["action_count"] += 1
        behavior["action_types"][action] += 1
        behavior["last_activity"] = datetime.now()
        
        behavior["action_timeline"].append({
            "action": action,
            "timestamp": datetime.now(),
            "details": details
        })
        if len(behavior["action_timeline"]) > 100:
            behavior["action_timeline"] = behavior["action_timeline"][-100:]
        
        risk_increment = self.get_action_risk_weight(action)
        old_risk = behavior["risk_score"]
        behavior["risk_score"] = min(100, behavior["risk_score"] + risk_increment)
        
        if behavior["risk_score"] > old_risk and behavior["risk_score"] > 50:
            self.risk_escalation[user_id].append((datetime.now(), behavior["risk_score"], action))
            
            recent_escalations = [e for e in self.risk_escalation[user_id]
                                 if (datetime.now() - e[0]).total_seconds() < 300]
            if len(recent_escalations) >= 3:
                await self.alert_risk_escalation(user_id, behavior["risk_score"], recent_escalations)
        
        if behavior["risk_score"] >= 70 and user_id not in self.high_risk_watchlist:
            self.high_risk_watchlist[user_id] = {
                "risk_score": behavior["risk_score"],
                "added_at": datetime.now(),
                "flags": behavior["flags"].copy(),
                "last_action": action
            }
            await self.alert_high_risk_user(user_id, behavior["risk_score"], behavior["flags"])
    
    def get_action_risk_weight(self, action: str) -> int:
        """Get risk weight for different action types"""
        risk_weights = {
            "member_join": 2,
            "member_leave": 1,
            "message_edit": 1,
            "message_delete": 2,
            "message_delete_mass": 15,
            "role_assign": 5,
            "role_assign_admin": 25,
            "role_assign_dangerous": 20,
            "role_remove": 3,
            "channel_create": 10,
            "channel_delete": 15,
            "channel_create_mass": 30,
            "webhook_create": 20,
            "webhook_create_mass": 40,
            "bot_add": 35,
            "permission_change": 15,
            "permission_dangerous": 30,
            "ban": 20,
            "unban": 10,
            "kick": 15,
            "timeout": 5,
            "nickname_change": 2,
            "voice_join": 1,
            "voice_move": 1
        }
        return risk_weights.get(action, 1)
    
    async def detect_anomaly(self, guild_id: int, action_type: str, rate: int) -> Tuple[bool, Optional[AnomalyType], str]:
        """Detect anomalies based on action rates"""
        thresholds = self.anomaly_thresholds
        
        if action_type == "join" and rate >= thresholds["join_rate"]:
            return True, AnomalyType.RAPID_JOIN, f"Rapid join rate: {rate}/min"
        elif action_type == "leave" and rate >= thresholds["leave_rate"]:
            return True, AnomalyType.RAPID_LEAVE, f"Rapid leave rate: {rate}/min"
        elif action_type == "role_change" and rate >= thresholds["role_change_rate"]:
            return True, AnomalyType.MASS_ROLE_ASSIGN, f"Mass role changes: {rate}/min"
        elif action_type == "channel_create" and rate >= thresholds["channel_create_rate"]:
            return True, AnomalyType.MASS_CHANNEL_CREATE, f"Mass channel creation: {rate}/min"
        elif action_type == "webhook_create" and rate >= thresholds["channel_create_rate"]:
            return True, AnomalyType.MASS_WEBHOOK_CREATE, f"Mass webhook creation: {rate}/min"
        elif action_type == "permission_change" and rate >= thresholds["permission_change_rate"]:
            return True, AnomalyType.PERMISSION_ESCALATION, f"Mass permission changes: {rate}/min"
        
        return False, None, ""
    
    async def detect_suspicious_pattern(self, user_id: int, recent_actions: List[str]) -> Tuple[bool, str]:
        """Detect suspicious action patterns from user"""
        for pattern_name, pattern_actions in self.suspicious_patterns.items():
            pattern_length = len(pattern_actions)
            for i in range(len(recent_actions) - pattern_length + 1):
                if recent_actions[i:i+pattern_length] == pattern_actions:
                    return True, pattern_name
        
        return False, ""
    
    async def analyze_action_chain(self, user_id: int, actions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze action chains for complex attack patterns"""
        analysis = {
            "is_suspicious": False,
            "chain_type": None,
            "risk_contribution": 0,
            "explanation": []
        }
        
        action_types = [a["action"] for a in actions[-10:]]
        
        if "member_join" in action_types and "role_assign_admin" in action_types and "channel_create" in action_types:
            analysis["is_suspicious"] = True
            analysis["chain_type"] = "raid_attempt"
            analysis["risk_contribution"] = 40
            analysis["explanation"].append("User joined, received admin role, and created channels - classic raid pattern")
        
        if "webhook_create" in action_types and "permission_dangerous" in action_types:
            analysis["is_suspicious"] = True
            analysis["chain_type"] = "backdoor_attempt"
            analysis["risk_contribution"] = 50
            analysis["explanation"].append("Created webhooks and modified permissions - potential backdoor setup")
        
        if action_types.count("message_delete_mass") >= 3:
            analysis["is_suspicious"] = True
            analysis["chain_type"] = "griefing"
            analysis["risk_contribution"] = 35
            analysis["explanation"].append("Multiple mass message deletions - griefing behavior detected")
        
        role_changes = [a for a in actions if "role" in a["action"]]
        if len(role_changes) >= 5:
            analysis["is_suspicious"] = True
            analysis["chain_type"] = "role_hopping"
            analysis["risk_contribution"] = 25
            analysis["explanation"].append(f"Frequent role changes ({len(role_changes)} in short period)")
        
        return analysis
    
    async def calculate_raid_probability(self, guild_id: int) -> Tuple[int, List[str]]:
        """Calculate probability of ongoing raid"""
        probability = 0
        factors = []
        
        server_data = self.server_intelligence[guild_id]
        
        join_rate = server_data.get("recent_join_rate", 0)
        if join_rate >= 10:
            probability += 30
            factors.append(f"High join rate: {join_rate}/min")
        
        channel_rate = server_data.get("recent_channel_rate", 0)
        if channel_rate >= 5:
            probability += 25
            factors.append(f"Rapid channel creation: {channel_rate}/min")
        
        role_rate = server_data.get("recent_role_rate", 0)
        if role_rate >= 8:
            probability += 20
            factors.append(f"Mass role changes: {role_rate}/min")
        
        webhook_rate = server_data.get("recent_webhook_rate", 0)
        if webhook_rate >= 3:
            probability += 25
            factors.append(f"Mass webhook creation: {webhook_rate}/min")
        
        guild = self.bot.get_guild(guild_id)
        if guild:
            high_risk_users = len([u for u in self.high_risk_watchlist if u in [m.id for m in guild.members]])
            if high_risk_users >= 3:
                probability += 20
                factors.append(f"{high_risk_users} high-risk users active")
        
        probability = min(probability, 100)
        
        server_data["raid_probability"] = probability
        server_data["raid_factors"] = factors
        
        return probability, factors
    
    async def update_heatmap(self, guild_id: int, action_type: str):
        """Update activity heatmap data"""
        current_hour = datetime.now().hour
        self.heatmap_data[guild_id][current_hour] += 1
        
        current_day = datetime.now().weekday()
        heatmap_key = f"day_{current_day}_hour_{current_hour}"
        self.server_intelligence[guild_id]["heatmap_data"][heatmap_key] += 1
    
    async def update_mod_leaderboard(self, guild_id: int, moderator_id: int, action: str):
        """Update moderator activity leaderboard"""
        self.server_intelligence[guild_id]["mod_leaderboard"][moderator_id] += 1
    
    async def generate_risk_trend(self, guild_id: int) -> List[Dict[str, Any]]:
        """Generate risk trend data"""
        server_data = self.server_intelligence[guild_id]
        trends = server_data.get("risk_trend", [])
        
        current_time = datetime.now()
        trends = [t for t in trends if (current_time - t["timestamp"]).total_seconds() < 86400]
        
        return trends
    
    async def detect_smart_anomaly(self, guild_id: int) -> Tuple[bool, str, int]:
        """Advanced anomaly detection using multiple factors"""
        server_data = self.server_intelligence[guild_id]
        anomaly_score = 0
        reasons = []
        
        join_rate = server_data.get("recent_join_rate", 0)
        leave_rate = server_data.get("recent_leave_rate", 0)
        
        if join_rate > 0 and leave_rate > 0:
            ratio = join_rate / leave_rate
            if ratio > 3:
                anomaly_score += 20
                reasons.append(f"Unusual join/leave ratio: {ratio:.1f}:1")
        
        mod_rate = server_data.get("recent_mod_rate", 0)
        if mod_rate > 10:
            anomaly_score += 25
            reasons.append(f"Spike in moderation actions: {mod_rate}/min")
        
        perm_rate = server_data.get("recent_perm_rate", 0)
        if perm_rate > 3:
            anomaly_score += 30
            reasons.append(f"Frequent permission changes: {perm_rate}/min")
        
        new_account_actions = server_data.get("new_account_actions", 0)
        if new_account_actions > 5:
            anomaly_score += 25
            reasons.append(f"High activity from new accounts: {new_account_actions} actions")
        
        is_anomaly = anomaly_score >= 50
        return is_anomaly, ", ".join(reasons), anomaly_score
    
    async def alert_risk_escalation(self, user_id: int, current_risk: int, escalations: List[Tuple[datetime, int, str]]):
        """Alert when user risk escalates rapidly"""
        if not await self.should_run_intelligence():
            return
        
        if not self.logging_cog:
            return
        
        user = self.bot.get_user(user_id)
        if not user:
            return
        
        title = "⚠️ Risk Escalation Detected"
        description = f"User {user.mention} is showing rapid risk escalation"
        
        escalation_text = "\n".join([f"- {e[2]}: Risk +{e[1]}" for e in escalations[-3:]])
        
        fields = [
            ("User", f"{user.mention}\n`{user}`", True),
            ("User ID", f"`{user_id}`", True),
            ("Current Risk", f"**{current_risk}/100**", True),
            ("Escalation Events", escalation_text, False),
            ("❓ Why Flagged?", "Rapid risk score increase indicates potentially malicious behavior", False)
        ]
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity="CRITICAL" if current_risk >= 75 else "WARNING",
            fields=fields,
            footer=f"Risk Level: {self.calculate_risk_level(current_risk).value}",
            risk_score=current_risk,
            perpetrator=user
        )
        
        await self.logging_cog.send_log("security", embed, "CRITICAL" if current_risk >= 75 else "WARNING")
    
    async def alert_high_risk_user(self, user_id: int, risk_score: int, flags: List[str]):
        """Alert when user enters high-risk watchlist"""
        if not await self.should_run_intelligence():
            return
        
        if not self.logging_cog:
            return
        
        user = self.bot.get_user(user_id)
        if not user:
            return
        
        title = "🚨 High-Risk User Detected"
        description = f"User {user.mention} has been added to the high-risk watchlist"
        
        fields = [
            ("User", f"{user.mention}\n`{user}`", True),
            ("User ID", f"`{user_id}`", True),
            ("Risk Score", f"**{risk_score}/100**", True),
            ("Risk Level", self.calculate_risk_level(risk_score).value, True),
            ("Flags", "\n".join(flags[:5]) if flags else "None", False)
        ]
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity="CRITICAL",
            fields=fields,
            footer="User will be monitored closely",
            risk_score=risk_score,
            perpetrator=user
        )
        
        await self.logging_cog.send_log("security", embed, "CRITICAL")
    
    async def risk_escalation_monitor(self):
        """Background task to monitor risk escalation"""
        await self.bot.wait_until_ready()
        
        while not self.bot.is_closed():
            await asyncio.sleep(60)
            
            if not await self.should_run_intelligence():
                continue
            
            for user_id, behavior in self.user_behavior.items():
                risk_score = behavior.get("risk_score", 0)
                
                recent_escalations = [e for e in self.risk_escalation[user_id]
                                     if (datetime.now() - e[0]).total_seconds() < 300]
                
                if len(recent_escalations) >= 5 and risk_score >= 60:
                    await self.alert_risk_escalation(user_id, risk_score, recent_escalations)
    
    async def heatmap_updater(self):
        """Background task to update heatmap data"""
        await self.bot.wait_until_ready()
        
        while not self.bot.is_closed():
            await asyncio.sleep(3600)
            
            if not await self.should_run_intelligence():
                continue
            
            for guild_id, heatmap in self.heatmap_data.items():
                guild = self.bot.get_guild(guild_id)
                if guild and self.logging_cog:
                    await self.generate_heatmap_report(guild, dict(heatmap))
    
    async def anomaly_scanner(self):
        """Background task to scan for anomalies"""
        await self.bot.wait_until_ready()
        
        while not self.bot.is_closed():
            await asyncio.sleep(30)
            
            if not await self.should_run_intelligence():
                continue
            
            for guild_id, server_data in self.server_intelligence.items():
                is_anomaly, reason, score = await self.detect_smart_anomaly(guild_id)
                
                if is_anomaly:
                    server_data["anomaly_history"].append({
                        "timestamp": datetime.now(),
                        "reason": reason,
                        "score": score
                    })
                    
                    if len(server_data["anomaly_history"]) > 50:
                        server_data["anomaly_history"] = server_data["anomaly_history"][-50:]
                    
                    if score >= 70:
                        await self.alert_anomaly_detected(guild_id, reason, score)
    
    async def alert_anomaly_detected(self, guild_id: int, reason: str, score: int):
        """Alert when anomaly is detected"""
        if not await self.should_run_intelligence():
            return
        
        if not self.logging_cog:
            return
        
        guild = self.bot.get_guild(guild_id)
        if not guild:
            return
        
        title = "🔍 Smart Anomaly Detected"
        description = "Advanced anomaly detection has identified unusual activity"
        
        fields = [
            ("Server", guild.name, True),
            ("Anomaly Score", f"{score}/100", True),
            ("Detection", reason, False),
            ("❓ Why Flagged?", "Multiple factors indicate anomalous behavior pattern", False)
        ]
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity="WARNING",
            fields=fields,
            footer="Smart anomaly detection - Review activity",
            risk_score=score,
            perpetrator=None
        )
        
        await self.logging_cog.send_log("security", embed, "WARNING")
    
    async def generate_heatmap_report(self, guild: discord.Guild, heatmap_data: Dict[int, int]):
        """Generate heatmap visualization of activity"""
        if not heatmap_data or not self.logging_cog:
            return
        
        sorted_hours = sorted(heatmap_data.items(), key=lambda x: x[1], reverse=True)
        peak_hours = [(f"{hour}:00", count) for hour, count in sorted_hours[:5]]
        
        title = "📊 Activity Heatmap"
        description = "Activity distribution across hours"
        
        fields = [
            ("Peak Activity Hours", "\n".join([f"{hour}: {count} events" for hour, count in peak_hours]), False)
        ]
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity="INFO",
            fields=fields,
            footer="Based on last 24 hours of activity"
        )
        
        await self.logging_cog.send_log("server", embed, "INFO")
    
    @commands.command(name="user-risk")
    @commands.has_permissions(administrator=True)
    async def user_risk(self, ctx: commands.Context, user: discord.User):
        """Check risk score and behavior analysis for a user"""
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Intelligence system not ready")
            return
        
        behavior = self.user_behavior.get(user.id, {})
        risk_score = behavior.get("risk_score", 0)
        risk_level = self.calculate_risk_level(risk_score)
        
        embed = discord.Embed(
            title=f"{self.get_emoji('user')} User Risk Analysis: {user.display_name}",
            color=0xe74c3c if risk_score >= 50 else 0x3498db,
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Risk Score", value=f"**{risk_score}/100**", inline=True)
        embed.add_field(name="Risk Level", value=f"**{risk_level.value}**", inline=True)
        embed.add_field(name="User ID", value=f"`{user.id}`", inline=True)
        
        if behavior:
            embed.add_field(name="Total Actions", value=str(behavior.get("action_count", 0)), inline=True)
            embed.add_field(name="First Seen", value=behavior.get("first_seen", datetime.now()).strftime("%Y-%m-%d"), inline=True)
            
            action_types = behavior.get("action_types", {})
            if action_types:
                top_actions = sorted(action_types.items(), key=lambda x: x[1], reverse=True)[:5]
                actions_text = "\n".join([f"- {action}: {count}" for action, count in top_actions])
                embed.add_field(name="Top Actions", value=actions_text, inline=False)
            
            flags = behavior.get("flags", [])
            if flags:
                embed.add_field(name="⚠️ Flags", value="\n".join(flags[:5]), inline=False)
            
            if risk_score >= 50:
                explanation = self.get_risk_explanation(user.id, behavior)
                embed.add_field(name="❓ Why Flagged?", value=explanation, inline=False)
        
        if user.id in self.high_risk_watchlist:
            embed.add_field(name="🚨 Watchlist Status", value="User is on HIGH-RISK watchlist", inline=False)
            embed.color = 0xe74c3c
        
        await ctx.send(embed=embed)
    
    def get_risk_explanation(self, user_id: int, behavior: Dict[str, Any]) -> str:
        """Generate detailed explanation of why user is flagged"""
        explanations = []
        
        risk_score = behavior.get("risk_score", 0)
        
        if risk_score >= 75:
            explanations.append("🔴 **CRITICAL RISK** - Immediate action recommended")
        elif risk_score >= 50:
            explanations.append("🟠 **HIGH RISK** - Monitor closely")
        
        action_types = behavior.get("action_types", {})
        
        if action_types.get("role_assign_admin", 0) > 0:
            explanations.append("• Received administrator role (high privilege escalation)")
        
        if action_types.get("webhook_create_mass", 0) > 0 or action_types.get("webhook_create", 0) > 3:
            explanations.append("• Created multiple webhooks (potential backdoor)")
        
        if action_types.get("channel_create_mass", 0) > 0 or action_types.get("channel_create", 0) > 5:
            explanations.append("• Created many channels rapidly (potential raid/nuke)")
        
        if action_types.get("permission_dangerous", 0) > 0:
            explanations.append("• Granted dangerous permissions to self or others")
        
        if action_types.get("message_delete_mass", 0) > 0:
            explanations.append("• Mass message deletion detected (griefing behavior)")
        
        if action_types.get("bot_add", 0) > 0:
            explanations.append("• Added bots to server (potential backdoor)")
        
        recent_escalations = [e for e in self.risk_escalation[user_id]
                             if (datetime.now() - e[0]).total_seconds() < 300]
        if len(recent_escalations) >= 3:
            explanations.append(f"• Rapid risk escalation ({len(recent_escalations)} increases in 5 minutes)")
        
        pattern_matches = behavior.get("pattern_matches", [])
        if pattern_matches:
            explanations.append(f"• Suspicious pattern detected: {pattern_matches[0]}")
        
        if not explanations:
            explanations.append("No specific flags - risk score is based on overall activity")
        
        return "\n".join(explanations[:8])
    
    @commands.command(name="watchlist")
    @commands.has_permissions(administrator=True)
    async def show_watchlist(self, ctx: commands.Context):
        """Show high-risk user watchlist"""
        if not self.high_risk_watchlist:
            await ctx.send(f"{self.get_emoji('info')} No users on high-risk watchlist")
            return
        
        embed = discord.Embed(
            title=f"{self.get_emoji('warning')} High-Risk User Watchlist",
            description=f"{len(self.high_risk_watchlist)} users currently being monitored",
            color=0xe74c3c,
            timestamp=datetime.now()
        )
        
        watchlist_text = []
        for user_id, data in list(self.high_risk_watchlist.items())[:15]:
            user = self.bot.get_user(user_id)
            if user:
                added_ago = (datetime.now() - data["added_at"]).total_seconds() / 60
                watchlist_text.append(
                    f"• {user.mention} (`{user_id}`)\n"
                    f"  Risk: {data['risk_score']}/100 | Added: {int(added_ago)}m ago\n"
                    f"  Last action: {data.get('last_action', 'Unknown')}"
                )
        
        if watchlist_text:
            embed.add_field(name="Watchlisted Users", value="\n\n".join(watchlist_text[:10]), inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name="server-risk")
    @commands.has_permissions(administrator=True)
    async def server_risk(self, ctx: commands.Context):
        """Get server-wide risk assessment"""
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Intelligence system not ready")
            return
        
        server_data = self.server_intelligence[ctx.guild.id]
        raid_prob, factors = await self.calculate_raid_probability(ctx.guild.id)
        
        embed = discord.Embed(
            title=f"{self.get_emoji('settings')} Server Risk Assessment",
            color=0xe74c3c if raid_prob >= 50 else 0x3498db,
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Raid Probability", value=f"**{raid_prob}%**", inline=True)
        embed.add_field(name="Anomaly Count", value=str(server_data.get("anomaly_count", 0)), inline=True)
        embed.add_field(name="High-Risk Users", value=str(len(self.high_risk_watchlist)), inline=True)
        
        if factors:
            embed.add_field(name="Risk Factors", value="\n".join(factors), inline=False)
        
        risk_trend = await self.generate_risk_trend(ctx.guild.id)
        if risk_trend:
            recent_scores = [t["risk_score"] for t in risk_trend[-10:]]
            trend_direction = "↑ Increasing" if len(recent_scores) > 1 and recent_scores[-1] > recent_scores[0] else "↓ Stable/Decreasing"
            embed.add_field(name="Risk Trend", value=trend_direction, inline=True)
        
        mod_leaderboard = server_data.get("mod_leaderboard", {})
        if mod_leaderboard:
            top_mods = sorted(mod_leaderboard.items(), key=lambda x: x[1], reverse=True)[:5]
            mod_text = "\n".join([f"• <@{mod_id}>: {count} actions" for mod_id, count in top_mods])
            embed.add_field(name="Top Moderators", value=mod_text, inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name="user-timeline")
    @commands.has_permissions(manage_messages=True)
    async def user_timeline(self, ctx: commands.Context, user: discord.User, limit: int = 20):
        """Show user action timeline"""
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Intelligence system not ready")
            return
        
        behavior = self.user_behavior.get(user.id, {})
        timeline = behavior.get("action_timeline", [])[-limit:]
        
        if not timeline:
            await ctx.send(f"{self.get_emoji('info')} No actions recorded for {user.mention}")
            return
        
        embed = discord.Embed(
            title=f"{self.get_emoji('list')} User Timeline: {user.display_name}",
            description=f"Last {len(timeline)} actions recorded",
            color=0x3498db,
            timestamp=datetime.now()
        )
        
        timeline_text = []
        for action in reversed(timeline[-15:]):
            timestamp = action["timestamp"].strftime("%H:%M:%S")
            action_name = action["action"].replace("_", " ").title()
            timeline_text.append(f"`{timestamp}` - {action_name}")
        
        embed.add_field(name="Action History", value="\n".join(timeline_text), inline=False)
        
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    """Setup function for the cog"""
    cog = IntelligenceCog(bot)
    await bot.add_cog(cog)
