import discord
from discord.ext import commands
from typing import Dict, List, Optional, Tuple, Any, Set, Union
from datetime import datetime, timedelta
from collections import defaultdict
import asyncio


class VoiceLogsCog(commands.Cog):
    """Handle voice channel activity tracking, join/leave/move events, and voice state monitoring"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logging_cog = None
        self.voice_session_tracker: Dict[int, Dict[str, Any]] = {}
        self.voice_join_buffer: Dict[int, List[datetime]] = defaultdict(list)
        self.voice_move_buffer: Dict[int, List[Tuple[datetime, str, str]]] = defaultdict(list)
        self.user_voice_history: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
        self.channel_voice_activity: Dict[int, Dict[str, Any]] = defaultdict(lambda: {"join_count": 0, "total_duration": 0, "peak_users": 0})
        self.voice_raid_detection: Dict[int, List[datetime]] = defaultdict(list)
        self.priority_voice_channels: Set[int] = set()
        
    async def cog_load(self):
        await self.bot.wait_until_ready()
        self.logging_cog = self.bot.get_cog("LoggingCog")
        asyncio.create_task(self.voice_activity_summary_loop())
        
    def get_emoji(self, key: str) -> str:
        if self.logging_cog and hasattr(self.logging_cog, 'get_emoji'):
            return self.logging_cog.get_emoji(key)
        return ""

    async def _fetch_avatar(self, user: discord.User) -> "Optional[Any]":
        if not hasattr(self.bot, 'imaging'):
            return None
        try:
            avatar_bytes = await user.display_avatar.with_size(128).read()
            from PIL import Image
            import io
            return Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
        except Exception:
            return None

    async def _fetch_voice_move_executor(self, guild: discord.Guild, member: discord.Member) -> Optional[discord.User]:
        """Look up audit log to find who moved a member between voice channels."""
        try:
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.member_move):
                if (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    return entry.user
        except (discord.Forbidden, Exception):
            pass
        return None

    async def _fetch_voice_disconnect_executor(self, guild: discord.Guild, member: discord.Member) -> Optional[discord.User]:
        """Look up audit log to find who disconnected a member from voice."""
        try:
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.member_disconnect):
                if (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    return entry.user
        except (discord.Forbidden, Exception):
            pass
        return None

    async def _fetch_server_mute_executor(self, guild: discord.Guild, member: discord.Member) -> Optional[discord.User]:
        """Look up audit log to find who server-muted/unmuted a member."""
        try:
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.member_update):
                if entry.target.id == member.id:
                    if (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                        for change in (entry.changes or []):
                            if change.name in ("mute", "deaf"):
                                return entry.user
        except (discord.Forbidden, Exception):
            pass
        return None
    
    async def should_log_voice_events(self) -> bool:
        if not self.logging_cog:
            return True
        return self.logging_cog.config.is_category_enabled("voice_logs")
    
    def detect_voice_raid(self, guild_id: int, channel_id: int) -> Tuple[bool, int]:
        current_time = datetime.now()
        self.voice_raid_detection[guild_id] = [
            t for t in self.voice_raid_detection[guild_id]
            if (current_time - t).total_seconds() < 10
        ]
        self.voice_raid_detection[guild_id].append(current_time)
        if len(self.voice_raid_detection[guild_id]) >= 10:
            return True, len(self.voice_raid_detection[guild_id])
        return False, 0
    
    def format_duration(self, seconds: int) -> str:
        if seconds < 60:
            return f"{seconds}s"
        elif seconds < 3600:
            minutes = seconds // 60
            remaining_seconds = seconds % 60
            return f"{minutes}m {remaining_seconds}s"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{hours}h {minutes}m"
    
    async def log_voice_join(self, member: discord.Member, channel: discord.VoiceChannel):
        if not await self.should_log_voice_events():
            return
        if not self.logging_cog:
            return
        
        is_raid, raid_count = self.detect_voice_raid(member.guild.id, channel.id)
        risk_score = 0
        reasons = []
        if is_raid:
            risk_score += 60
            reasons.append(f"Voice channel raid detected - {raid_count} joins in 10 seconds")
        account_age = (datetime.now() - member.created_at.replace(tzinfo=None)).days
        if account_age < 7:
            risk_score += 15
            reasons.append(f"New account ({account_age} days old) joining voice")
        risk_score = min(risk_score, 100)
        
        self.voice_session_tracker[member.id] = {
            "channel_id": channel.id, "channel_name": channel.name,
            "joined_at": datetime.now(), "guild_id": member.guild.id
        }
        self.channel_voice_activity[channel.id]["join_count"] += 1
        self.user_voice_history[member.id].append({
            "action": "join", "channel_id": channel.id,
            "channel_name": channel.name, "timestamp": datetime.now()
        })
        
        title = "Voice Channel Join"
        description = f"{self.get_emoji('mic')} {member.mention} joined voice channel {channel.mention}"
        fields = [
            ("User", f"{member.mention}\n`{member}`", True),
            ("User ID", f"`{member.id}`", True),
            ("Channel", channel.mention, True),
            ("Current Users", str(len(channel.members)), True)
        ]
        if is_raid:
            fields.insert(1, ("⚠️ RAID DETECTED", f"{raid_count} users joined voice in 10 seconds", False))
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        severity = "CRITICAL" if is_raid else "WARNING" if risk_score > 30 else "INFO"
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity=severity, fields=fields,
            footer=f"Risk Score: {risk_score}/100 | Channel: #{channel.name}", risk_score=risk_score,
            perpetrator=None
        )

        avatar_img = await self._fetch_avatar(member)
        extra_fields = [("Channel", f"#{channel.name}"), ("Current Users", str(len(channel.members)))]
        await self.logging_cog.send_image_log(
            channel_type="voice", template_name="logging_card",
            embed_fallback=embed, filename="voice_join.png", event_type="voice_join",
            user=member, channel=channel,
            content=f"Joined voice channel #{channel.name}",
            extra_fields=extra_fields, severity=severity,
            avatar_image=avatar_img, timestamp=datetime.now(),
        )
        if is_raid:
            await self.alert_voice_raid(member.guild, channel, raid_count)
    
    async def log_voice_leave(self, member: discord.Member, channel: discord.VoiceChannel = None):
        if not await self.should_log_voice_events():
            return
        if not self.logging_cog:
            return
        
        session = self.voice_session_tracker.pop(member.id, None)
        if not session:
            duration = 0
            channel_name = channel.name if channel else "Unknown"
        else:
            duration = (datetime.now() - session["joined_at"]).total_seconds()
            channel_name = session["channel_name"]
            channel = channel or self.bot.get_channel(session["channel_id"])

        executor = await self._fetch_voice_disconnect_executor(member.guild, member)
        disconnected_by_mod = executor is not None and executor.id != member.id
        
        if channel:
            self.channel_voice_activity[channel.id]["total_duration"] += duration
            if channel.members:
                current_users = len(channel.members)
                if current_users > self.channel_voice_activity[channel.id]["peak_users"]:
                    self.channel_voice_activity[channel.id]["peak_users"] = current_users
        
        self.user_voice_history[member.id].append({
            "action": "leave", "channel_id": session.get("channel_id") if session else None,
            "channel_name": channel_name, "duration": duration, "timestamp": datetime.now()
        })
        
        risk_score = 0
        reasons = []
        if duration < 30 and duration > 0:
            risk_score += 10
            reasons.append(f"Very short voice session ({int(duration)}s) - possible join/leave spam")
        if disconnected_by_mod:
            risk_score += 5
            reasons.append(f"Disconnected by moderator: {executor}")
        risk_score = min(risk_score, 100)
        
        title = "Voice Channel Leave"
        if disconnected_by_mod:
            description = f"{self.get_emoji('endcall')} {member.mention} was disconnected from voice by {executor.mention}"
        else:
            description = f"{self.get_emoji('endcall')} {member.mention} left voice channel"
        
        fields = [
            ("User", f"{member.mention}\n`{member}`", True),
            ("User ID", f"`{member.id}`", True),
            ("Channel", channel.mention if channel else channel_name, True),
            ("Duration", self.format_duration(int(duration)), True)
        ]
        if disconnected_by_mod:
            fields.insert(0, ("Disconnected By", f"{executor.mention}\n`{executor}`", True))
        if duration < 30 and duration > 0:
            fields.insert(1 if not disconnected_by_mod else 2, ("⚠️ Short Session", f"User stayed for only {int(duration)} seconds", False))
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "WARNING" if risk_score > 30 or disconnected_by_mod else "INFO"
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity=severity, fields=fields,
            footer=f"Session Duration: {self.format_duration(int(duration))} | Risk Score: {risk_score}/100",
            risk_score=risk_score
        )

        avatar_img = await self._fetch_avatar(member)
        extra_fields = [("Channel", f"#{channel_name}"), ("Duration", self.format_duration(int(duration)))]
        
        await self.logging_cog.send_image_log(
            channel_type="voice", template_name="logging_card",
            embed_fallback=embed, filename="voice_leave.png", event_type="voice_leave",
            user=member, channel=channel,
            content=f"Left voice channel #{channel_name} after {self.format_duration(int(duration))}",
            extra_fields=extra_fields, severity=severity,
            perpetrator=executor if disconnected_by_mod else None,
            avatar_image=avatar_img, timestamp=datetime.now(),
        )
    
    async def log_voice_move(self, member: discord.Member, before: discord.VoiceChannel, after: discord.VoiceChannel):
        if not await self.should_log_voice_events():
            return
        if not self.logging_cog:
            return

        executor = await self._fetch_voice_move_executor(member.guild, member)
        moved_by_mod = executor is not None and executor.id != member.id
        
        risk_score = 0
        reasons = []
        current_time = datetime.now()
        self.voice_move_buffer[member.id].append((current_time, before.name, after.name))
        self.voice_move_buffer[member.id] = [
            m for m in self.voice_move_buffer[member.id]
            if (current_time - m[0]).total_seconds() < 30
        ]
        if len(self.voice_move_buffer[member.id]) > 5:
            risk_score += 30
            reasons.append(f"Rapid channel switching detected ({len(self.voice_move_buffer[member.id])} moves in 30s)")
        risk_score = min(risk_score, 100)
        
        self.user_voice_history[member.id].append({
            "action": "move", "from_channel": before.name,
            "to_channel": after.name, "timestamp": datetime.now()
        })
        
        title = "Voice Channel Move"
        if moved_by_mod:
            description = f"{self.get_emoji('right')} {member.mention} was moved by {executor.mention}"
        else:
            description = f"{self.get_emoji('right')} {member.mention} moved between voice channels"
        
        fields = [
            ("User", f"{member.mention}\n`{member}`", True),
            ("User ID", f"`{member.id}`", True),
            ("From", before.mention, True),
            ("To", after.mention, True)
        ]
        if moved_by_mod:
            fields.insert(0, ("Moved By", f"{executor.mention}\n`{executor}`", True))
        if len(self.voice_move_buffer[member.id]) > 5:
            fields.insert(1 if not moved_by_mod else 2, ("⚠️ Rapid Movement", f"{len(self.voice_move_buffer[member.id])} moves in last 30 seconds", False))
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "WARNING" if risk_score > 30 or moved_by_mod else "INFO"
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity=severity,
            fields=fields, footer=f"Risk Score: {risk_score}/100", risk_score=risk_score,
            perpetrator=executor if (disconnected_by_mod if 'disconnected_by_mod' in locals() else moved_by_mod if 'moved_by_mod' in locals() else False) else None
        )

        avatar_img = await self._fetch_avatar(member)
        extra_fields = [("From", f"#{before.name}"), ("To", f"#{after.name}")]

        await self.logging_cog.send_image_log(
            channel_type="voice", template_name="logging_card",
            embed_fallback=embed, filename="voice_move.png", event_type="voice_move",
            user=member, channel=after,
            content=f"Moved from #{before.name} to #{after.name}",
            extra_fields=extra_fields, severity=severity,
            perpetrator=executor if moved_by_mod else None,
            avatar_image=avatar_img, timestamp=datetime.now(),
        )
    
    async def log_voice_stream(self, member: discord.Member, channel: discord.VoiceChannel, is_streaming: bool):
        if not await self.should_log_voice_events():
            return
        if not self.logging_cog:
            return
        action = "started" if is_streaming else "stopped"
        emoji = self.get_emoji("video") if is_streaming else self.get_emoji("images")
        title = f"Streaming {action.capitalize()}"
        description = f"{emoji} {member.mention} {action} streaming in {channel.mention}"
        fields = [
            ("User", f"{member.mention}\n`{member}`", True),
            ("User ID", f"`{member.id}`", True),
            ("Channel", channel.mention, True)
        ]
        self.user_voice_history[member.id].append({
            "action": f"stream_{action}", "channel_id": channel.id, "timestamp": datetime.now()
        })
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity="INFO",
            fields=fields, footer=f"User ID: {member.id}"
        )
        avatar_img = await self._fetch_avatar(member)
        extra_fields = [("Channel", f"#{channel.name}"), ("Action", action.capitalize())]
        await self.logging_cog.send_image_log(
            channel_type="voice", template_name="logging_card",
            embed_fallback=embed, filename="voice_stream.png",
            event_type=f"stream_{action}", user=member, channel=channel,
            content=f"{action.capitalize()} streaming in #{channel.name}",
            extra_fields=extra_fields, severity="INFO",
            avatar_image=avatar_img, timestamp=datetime.now(),
        )
    
    async def log_voice_mute(self, member: discord.Member, channel: discord.VoiceChannel, is_muted: bool, is_server_mute: bool = False):
        if not await self.should_log_voice_events():
            return
        if not self.logging_cog:
            return
        
        mute_type = "server" if is_server_mute else "self"
        action = "muted" if is_muted else "unmuted"
        emoji = self.get_emoji("mute") if is_muted else self.get_emoji("unmute")

        executor = None
        if is_server_mute:
            executor = await self._fetch_server_mute_executor(member.guild, member)
        
        title = f"{mute_type.capitalize()} {action.capitalize()}"
        if executor and executor.id != member.id:
            description = f"{emoji} {member.mention} was {action} ({mute_type} mute) by {executor.mention} in {channel.mention}"
        else:
            description = f"{emoji} {member.mention} was {action} ({mute_type} mute) in {channel.mention}"
        
        fields = [
            ("User", f"{member.mention}\n`{member}`", True),
            ("User ID", f"`{member.id}`", True),
            ("Channel", channel.mention, True),
            ("Mute Type", mute_type.capitalize(), True)
        ]
        if executor and executor.id != member.id:
            fields.insert(0, ("Actioned By", f"{executor.mention}\n`{executor}`", True))
        
        severity = "WARNING" if is_server_mute and executor and executor.id != member.id else "INFO"
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity=severity,
            fields=fields, footer=f"User ID: {member.id}",
            perpetrator=executor if (is_server_mute if 'is_server_mute' in locals() else False) else None
        )

        avatar_img = await self._fetch_avatar(member)
        extra_fields = [("Channel", f"#{channel.name}"), ("Mute Type", mute_type.capitalize())]
        if executor and executor.id != member.id:
            extra_fields.insert(0, ("Actioned By", str(executor)))

        await self.logging_cog.send_image_log(
            channel_type="voice", template_name="logging_card",
            embed_fallback=embed, filename="voice_mute.png",
            event_type=f"voice_{action}", user=member, channel=channel,
            content=f"{action.capitalize()} ({mute_type} mute) in #{channel.name}",
            extra_fields=extra_fields, avatar_image=avatar_img, timestamp=datetime.now(),
        )
    
    async def alert_voice_raid(self, guild: discord.Guild, channel: discord.VoiceChannel, raid_count: int):
        if not self.logging_cog:
            return
        title = "🚨 VOICE CHANNEL RAID DETECTED 🚨"
        description = f"{self.get_emoji('warning')} **Potential raid detected in voice channel**"
        fields = [
            ("Channel", channel.mention, True),
            ("Users Joined", str(raid_count), True),
            ("Time Window", "10 seconds", True),
            ("Action Required", "Monitor voice channel activity and consider limiting access", False)
        ]
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity="CRITICAL",
            fields=fields, footer="⚠️ Immediate attention recommended", risk_score=80
        )
        extra_fields = [("Channel", f"#{channel.name}"), ("Users Joined", str(raid_count)), ("Time Window", "10 seconds")]
        await self.logging_cog.send_image_log(
            channel_type="security", template_name="logging_card", severity="CRITICAL",
            embed_fallback=embed, filename="voice_raid_alert.png",
            event_type="voice_raid", channel=channel,
            content=f"Voice channel raid detected — {raid_count} users joined in 10 seconds",
            extra_fields=extra_fields, timestamp=datetime.now(),
        )
    
    async def voice_activity_summary_loop(self):
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            await asyncio.sleep(3600)
            if not self.logging_cog or not await self.should_log_voice_events():
                continue
            for guild in self.bot.guilds:
                await self.generate_voice_summary(guild)
    
    async def generate_voice_summary(self, guild: discord.Guild):
        if not self.channel_voice_activity:
            return
        if not self.logging_cog:
            return
        active_channels = []
        for channel_id, stats in self.channel_voice_activity.items():
            channel = guild.get_channel(channel_id)
            if channel and isinstance(channel, discord.VoiceChannel):
                if stats["join_count"] > 0:
                    active_channels.append((channel, stats))
        if not active_channels:
            return
        active_channels.sort(key=lambda x: x[1]["join_count"], reverse=True)
        title = f"{self.get_emoji('mic')} Voice Activity Summary"
        description = "Voice channel activity in the last hour"
        fields = []
        for channel, stats in active_channels[:5]:
            peak_users = stats.get("peak_users", 0)
            total_duration_min = stats.get("total_duration", 0) / 60
            fields.append((
                channel.name,
                f"Joins: {stats['join_count']} | Peak: {peak_users} users | Total time: {int(total_duration_min)}m",
                False
            ))
        if fields:
            embed = await self.logging_cog.create_log_embed(
                title=title, description=description, severity="INFO",
                fields=fields, footer="Summary generated automatically"
            )
            extra_fields = []
            for ch, stats in active_channels[:5]:
                extra_fields.append((f"#{ch.name}", f"{stats['join_count']} joins"))
            await self.logging_cog.send_image_log(
                channel_type="voice", template_name="logging_card", severity="INFO",
                embed_fallback=embed, filename="voice_summary.png",
                event_type="voice_summary",
                content="Hourly voice activity summary",
                extra_fields=extra_fields, timestamp=datetime.now(),
            )
            for channel_id in self.channel_voice_activity:
                self.channel_voice_activity[channel_id] = {"join_count": 0, "total_duration": 0, "peak_users": 0}
    
    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState, after: discord.VoiceState):
        if not await self.should_log_voice_events():
            return
        if self.logging_cog and self.logging_cog.config.should_ignore_bot(member):
            return
        if self.logging_cog:
            cooldown_key = f"voice_state:{member.id}"
            if self.logging_cog.check_cooldown("voice_state", cooldown_key):
                return
            self.logging_cog.update_cooldown("voice_state", cooldown_key)
        
        if before.channel is None and after.channel is not None:
            await self.log_voice_join(member, after.channel)
        elif before.channel is not None and after.channel is None:
            await self.log_voice_leave(member, before.channel)
        elif before.channel is not None and after.channel is not None and before.channel != after.channel:
            await self.log_voice_move(member, before.channel, after.channel)
        
        if before.self_stream != after.self_stream:
            channel = after.channel or before.channel
            if channel:
                await self.log_voice_stream(member, channel, after.self_stream)
        
        if before.self_mute != after.self_mute:
            channel = after.channel or before.channel
            if channel:
                await self.log_voice_mute(member, channel, after.self_mute, False)
        
        if before.mute != after.mute:
            channel = after.channel or before.channel
            if channel:
                await self.log_voice_mute(member, channel, after.mute, True)
    
    @commands.command(name="voice-stats")
    @commands.has_permissions(manage_channels=True)
    async def voice_stats(self, ctx: commands.Context, member: discord.Member = None):
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Logging system not ready")
            return
        target = member or ctx.author
        history = self.user_voice_history.get(target.id, [])
        if not history:
            await ctx.send(f"{self.get_emoji('info')} No voice activity recorded for {target.mention}")
            return
        total_joins = len([h for h in history if h["action"] == "join"])
        total_moves = len([h for h in history if h["action"] == "move"])
        total_streams = len([h for h in history if "stream" in h.get("action", "")])
        total_duration = sum([h.get("duration", 0) for h in history if h["action"] == "leave"])
        embed = discord.Embed(
            title=f"{self.get_emoji('mic')} Voice Statistics for {target.display_name}",
            color=0x3498db, timestamp=datetime.now()
        )
        embed.add_field(name="Total Joins", value=str(total_joins), inline=True)
        embed.add_field(name="Total Moves", value=str(total_moves), inline=True)
        embed.add_field(name="Streams Started", value=str(total_streams), inline=True)
        embed.add_field(name="Total Voice Time", value=self.format_duration(int(total_duration)), inline=True)
        if total_joins > 0:
            avg_duration = total_duration / total_joins
            embed.add_field(name="Average Session Length", value=self.format_duration(int(avg_duration)), inline=True)
        await ctx.send(embed=embed)
    
    @commands.command(name="voice-activity")
    @commands.has_permissions(manage_channels=True)
    async def voice_activity(self, ctx: commands.Context, channel: discord.VoiceChannel = None):
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Logging system not ready")
            return
        target_channel = channel or (ctx.author.voice.channel if ctx.author.voice else None)
        if not target_channel:
            await ctx.send(f"{self.get_emoji('info')} Please specify a voice channel or join one first")
            return
        members = target_channel.members
        embed = discord.Embed(
            title=f"{self.get_emoji('mic')} Voice Activity: {target_channel.name}",
            color=0x3498db, timestamp=datetime.now()
        )
        embed.add_field(name="Current Users", value=str(len(members)), inline=True)
        embed.add_field(name="User Limit", value=str(target_channel.user_limit) if target_channel.user_limit else "Unlimited", inline=True)
        embed.add_field(name="Bitrate", value=f"{target_channel.bitrate // 1000}kbps", inline=True)
        if members:
            member_list = []
            for m in members[:20]:
                status = ""
                if m.voice.self_stream:
                    status += " 📹"
                if m.voice.self_mute:
                    status += " 🔇"
                member_list.append(f"• {m.display_name}{status}")
            embed.add_field(name="Members", value="\n".join(member_list), inline=False)
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    cog = VoiceLogsCog(bot)
    await bot.add_cog(cog)
