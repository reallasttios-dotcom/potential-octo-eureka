import discord
from discord.ext import commands
from typing import Dict, List, Optional, Tuple, Any, Set, Union
from datetime import datetime, timedelta
from collections import defaultdict
import asyncio


class MemberLogsCog(commands.Cog):
    """Handle member join/leave/nickname changes and activity tracking"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logging_cog = None
        self.join_spam_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.leave_spam_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.nickname_history: Dict[int, List[Tuple[datetime, str, str]]] = defaultdict(list)
        self.join_leave_pairs: Dict[int, Tuple[datetime, datetime]] = {}
        self.suspicious_join_tracker: Dict[int, Dict[str, Any]] = {}
        
        # Invite tracking state
        self.invites: Dict[int, Dict[str, discord.Invite]] = {}
        self.vanity_uses: Dict[int, int] = {}
        
    async def cog_load(self):
        """Initialize cog and get reference to main logging cog"""
        await self.bot.wait_until_ready()
        self.logging_cog = self.bot.get_cog("LoggingCog")
        
        # Initial invite cache
        for guild in self.bot.guilds:
            invs, v_uses = await self.fetch_invites(guild)
            self.invites[guild.id] = invs
            self.vanity_uses[guild.id] = v_uses
            
    def get_emoji(self, key: str) -> str:
        """Get emoji from main logging cog"""
        if self.logging_cog and hasattr(self.logging_cog, 'get_emoji'):
            return self.logging_cog.get_emoji(key)
        return ""

    async def _fetch_avatar(self, user: discord.User) -> "Optional[Any]":
        """Fetch user avatar as PIL Image for imaging templates."""
        if not hasattr(self.bot, 'imaging'):
            return None
        try:
            avatar_bytes = await user.display_avatar.with_size(128).read()
            from PIL import Image
            import io
            return Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
        except Exception:
            return None
    
    async def should_log_member_events(self) -> bool:
        """Check if member events should be logged"""
        if not self.logging_cog:
            return True
        return self.logging_cog.config.is_category_enabled("member_logs")

    async def fetch_invites(self, guild):
        """Fetches standard invites and current vanity use count."""
        try:
            invs = {inv.code: inv for inv in await guild.invites()}
            vanity = await guild.vanity_invite()
            return invs, vanity.uses if vanity else 0
        except Exception:
            return {}, 0
    
    def calculate_account_age_severity(self, created_at: datetime) -> Tuple[int, str]:
        """Calculate risk based on account age"""
        age = (datetime.now() - created_at.replace(tzinfo=None)).days
        if age < 1: return 40, "CRITICAL"
        elif age < 7: return 20, "WARNING"
        elif age < 30: return 10, "INFO"
        return 0, "INFO"
    
    def detect_join_spam(self, guild_id: int, user_id: int) -> Tuple[bool, int]:
        """Detect if user is part of a join spam/raid"""
        current_time = datetime.now()
        self.join_spam_tracker[guild_id] = [t for t in self.join_spam_tracker[guild_id] if (current_time - t).total_seconds() < 60]
        self.join_spam_tracker[guild_id].append(current_time)
        threshold = self.logging_cog.config.get("rapid_join_threshold", 5) if self.logging_cog else 5
        recent_joins = [t for t in self.join_spam_tracker[guild_id] if (current_time - t).total_seconds() < 10]
        if len(recent_joins) >= threshold:
            return True, 80 if len(recent_joins) >= threshold * 2 else 50
        return False, 0
    
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Log member join event with invite tracking"""
        if not await self.should_log_member_events():
            return
        
        guild = member.guild
        old_invs = self.invites.get(guild.id, {})
        old_vanity = self.vanity_uses.get(guild.id, 0)
        
        new_invs, new_vanity = await self.fetch_invites(guild)
        self.invites[guild.id] = new_invs
        self.vanity_uses[guild.id] = new_vanity
        
        invite_info = "Unknown"
        inviter = None
        
        if new_vanity > old_vanity:
            invite_info = f"Vanity URL (`.gg/{guild.vanity_url_code}`)"
        else:
            for code, inv in new_invs.items():
                if code in old_invs and inv.uses > old_invs[code].uses:
                    invite_info = f"Invite code `{code}`"
                    inviter = inv.inviter
                    break
        
        is_spam, spam_severity = self.detect_join_spam(guild.id, member.id)
        account_age = (datetime.now() - member.created_at.replace(tzinfo=None)).days
        risk_score = spam_severity if is_spam else 0
        if account_age < 7: risk_score += 30
        
        severity = "CRITICAL" if risk_score > 60 else "WARNING" if risk_score > 30 else "INFO"
        
        fields = [
            ("User", f"{member.mention}\n`{member.id}`", True),
            ("Invite Info", invite_info, True),
            ("Inviter", inviter.mention if inviter else "Unknown", True),
            ("Account Age", f"{account_age} days", True)
        ]
        
        embed = await self.logging_cog.create_log_embed(
            title="Member Joined", description=f"{member.mention} joined the server",
            severity=severity, fields=fields, risk_score=risk_score
        )
        
        avatar_img = await self._fetch_avatar(member)
        
        # Log to member channel
        await self.logging_cog.send_image_log(
            channel_type="member", template_name="logging_card", severity=severity,
            embed_fallback=embed, filename="member_join.png",
            user=member, content=f"Joined via {invite_info}",
            avatar_image=avatar_img, timestamp=datetime.now()
        )
        
        # Log to invite channel if enabled
        if self.logging_cog.config.is_category_enabled("invite_logs"):
            await self.logging_cog.send_image_log(
                channel_type="invite", template_name="general", severity="INFO",
                embed_fallback=embed, filename="invite_use.png",
                card_type="invite",
                inviter_name=str(inviter) if inviter else "Unknown", inviter_id=inviter.id if inviter else 0,
                invited_name=member.display_name, invited_id=member.id,
                invite_code=invite_info, total_uses=new_vanity if "Vanity" in invite_info else (next((inv.uses for inv in new_invs.values() if inv.code in invite_info), 0)),
                joined_at=member.joined_at
            )

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        """Log member leave/kick/ban event"""
        if not await self.should_log_member_events():
            return
        
        action_type = "left"
        executor = None
        reason = None
        
        try:
            async for entry in member.guild.audit_logs(limit=5):
                if entry.target.id == member.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 15:
                    if entry.action == discord.AuditLogAction.kick:
                        action_type = "kicked"
                        executor = entry.user
                        reason = entry.reason
                    elif entry.action == discord.AuditLogAction.ban:
                        action_type = "banned"
                        executor = entry.user
                        reason = entry.reason
                    break
        except Exception: pass
        
        fields = [
            ("User", f"{member.mention}\n`{member.id}`", True),
            ("Action", action_type.capitalize(), True),
            ("Reason", reason or "No reason provided", False)
        ]
        
        embed = await self.logging_cog.create_log_embed(
            title=f"Member {action_type.capitalize()}",
            description=f"{member.mention} has {action_type} the server",
            severity="WARNING" if action_type != "left" else "INFO",
            fields=fields, perpetrator=executor
        )
        
        await self.logging_cog.send_image_log(
            channel_type="member", template_name="logging_card",
            severity="WARNING" if action_type != "left" else "INFO",
            embed_fallback=embed, filename="member_leave.png",
            user=member, content=f"Member {action_type}",
            timestamp=datetime.now()
        )

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """Log nickname changes and other member updates"""
        if before.display_name != after.display_name:
            embed = await self.logging_cog.create_log_embed(
                title="Nickname Changed",
                description=f"{after.mention} changed their nickname",
                fields=[
                    ("Before", before.display_name, True),
                    ("After", after.display_name, True)
                ],
                perpetrator=after # User changed their own nick usually
            )
            await self.logging_cog.send_log("member", embed, "INFO")

    # Poll Logging
    @commands.Cog.listener()
    async def on_poll_vote_add(self, user: discord.User, answer: discord.PollAnswer):
        """Log when a user votes in a poll"""
        if not self.logging_cog or not self.logging_cog.config.is_category_enabled("poll_logs"):
            return
        
        embed = await self.logging_cog.create_log_embed(
            title="Poll Vote Added",
            description=f"{user.mention} voted in a poll",
            fields=[
                ("User", f"{user.mention} (`{user.id}`)", True),
                ("Answer", answer.text, True),
                ("Poll ID", f"`{answer.poll.message.id}`", True)
            ],
            severity="INFO"
        )
        await self.logging_cog.send_log("poll", embed, "INFO")

    @commands.Cog.listener()
    async def on_poll_vote_remove(self, user: discord.User, answer: discord.PollAnswer):
        """Log when a user removes their vote from a poll"""
        if not self.logging_cog or not self.logging_cog.config.is_category_enabled("poll_logs"):
            return
        
        embed = await self.logging_cog.create_log_embed(
            title="Poll Vote Removed",
            description=f"{user.mention} removed their vote from a poll",
            fields=[
                ("User", f"{user.mention} (`{user.id}`)", True),
                ("Answer", answer.text, True)
            ],
            severity="INFO"
        )
        await self.logging_cog.send_log("poll", embed, "INFO")

async def setup(bot: commands.Bot):
    await bot.add_cog(MemberLogsCog(bot))
