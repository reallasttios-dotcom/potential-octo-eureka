import discord
from discord.ext import commands
from typing import Dict, List, Optional, Tuple, Any, Set, Union
from datetime import datetime, timedelta
from collections import defaultdict
import asyncio


class RoleLogsCog(commands.Cog):
    """Handle role creation/deletion/assignment and permission tracking"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logging_cog = None
        self.role_assignment_buffer: Dict[int, List[Tuple[datetime, discord.Member, List[discord.Role], List[discord.Role]]]] = defaultdict(list)
        self.role_snapshots: Dict[int, Dict[str, Any]] = {}
        self.permission_history: Dict[int, List[Tuple[datetime, Dict[str, bool], Dict[str, bool]]]] = defaultdict(list)
        self.mass_role_assignments: Dict[int, List[datetime]] = defaultdict(list)
        self.dangerous_role_assignments: Dict[int, List[Tuple[datetime, discord.Role, discord.Member]]] = defaultdict(list)

        self.admin_role_ids: Set[int] = set()
        self.dangerous_permissions = {
            "administrator": "Administrator",
            "manage_guild": "Manage Server",
            "manage_channels": "Manage Channels",
            "manage_roles": "Manage Roles",
            "manage_webhooks": "Manage Webhooks",
            "manage_emojis": "Manage Emojis",
            "kick_members": "Kick Members",
            "ban_members": "Ban Members",
            "mention_everyone": "Mention @everyone",
            "manage_nicknames": "Manage Nicknames"
        }
        
    async def cog_load(self):
        """Initialize cog and get reference to main logging cog"""
        await self.bot.wait_until_ready()
        self.logging_cog = self.bot.get_cog("LoggingCog")
        
    def get_emoji(self, key: str) -> str:
        """Get emoji from main logging cog"""
        if self.logging_cog and hasattr(self.logging_cog, 'get_emoji'):
            return self.logging_cog.get_emoji(key)
        return ""

    async def _fetch_avatar(self, user: discord.User) -> "Optional[Any]":
        """Fetch user avatar as PIL Image for imaging templates."""
        if not hasattr(self.bot, 'imaging'):
            return None
        try:
            avatar_bytes = await user.display_avatar.with_size(128).read()
            from PIL import Image
            import io
            return Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
        except Exception:
            return None
    
    async def should_log_role_events(self) -> bool:
        """Check if role events should be logged"""
        if not self.logging_cog:
            return True
        return self.logging_cog.config.is_category_enabled("role_logs")
    
    def get_role_permissions_snapshot(self, role: discord.Role) -> Dict[str, bool]:
        """Get snapshot of role permissions"""
        permissions = role.permissions
        return {
            "administrator": permissions.administrator,
            "manage_guild": permissions.manage_guild,
            "manage_channels": permissions.manage_channels,
            "manage_roles": permissions.manage_roles,
            "manage_webhooks": permissions.manage_webhooks,
            "manage_emojis": permissions.manage_emojis,
            "kick_members": permissions.kick_members,
            "ban_members": permissions.ban_members,
            "mention_everyone": permissions.mention_everyone,
            "manage_nicknames": permissions.manage_nicknames,
            "view_audit_log": permissions.view_audit_log,
            "priority_speaker": permissions.priority_speaker,
            "move_members": permissions.move_members,
            "mute_members": permissions.mute_members,
            "deafen_members": permissions.deafen_members
        }
    
    def get_dangerous_permissions(self, permissions: Dict[str, bool]) -> List[str]:
        """Get list of dangerous permissions from a permission dict"""
        dangerous = []
        for perm_key, perm_name in self.dangerous_permissions.items():
            if permissions.get(perm_key, False):
                dangerous.append(perm_name)
        return dangerous
    
    def format_permission_diff(self, before_perms: Dict[str, bool], after_perms: Dict[str, bool]) -> str:
        """Format permission differences with color coding"""
        changes = []
        
        for perm_key, perm_name in self.dangerous_permissions.items():
            before = before_perms.get(perm_key, False)
            after = after_perms.get(perm_key, False)
            
            if before != after:
                if after and not before:
                    changes.append(f"+ {perm_name} (Added)")
                elif before and not after:
                    changes.append(f"- {perm_name} (Removed)")
        
        return "\n".join(changes) if changes else "No dangerous permission changes"
    
    async def log_role_create(self, role: discord.Role):
        """Log role creation"""
        if not self.logging_cog:
            return
        if not await self.should_log_role_events():
            return
        
        executor = None
        reason = None
        
        try:
            async for entry in role.guild.audit_logs(limit=5, action=discord.AuditLogAction.role_create):
                if entry.target.id == role.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    executor = entry.user
                    reason = entry.reason
                    break
        except Exception:
            pass
        
        permissions = self.get_role_permissions_snapshot(role)
        dangerous_perms = self.get_dangerous_permissions(permissions)
        
        risk_score = 0
        reasons = []
        
        if dangerous_perms:
            risk_score += 40
            reasons.append(f"Role has dangerous permissions: {', '.join(dangerous_perms[:3])}")
        
        if role.mentionable:
            risk_score += 10
            reasons.append("Role is mentionable (can be @everyone mentioned)")
        
        if role.hoist:
            risk_score += 5
            reasons.append("Role is hoisted (appears separately in member list)")
        
        if role.position >= role.guild.me.top_role.position:
            risk_score += 25
            reasons.append(f"Role position ({role.position}) is above or equal to bot's highest role")
        
        risk_score = min(risk_score, 100)
        
        title = "Role Created"
        description = f"{self.get_emoji('add')} New role created: {role.mention}"
        
        fields = [
            ("Role Name", role.name, True),
            ("Role ID", f"`{role.id}`", True),
            ("Color", str(role.color) if role.color.value else "Default", True),
            ("Position", str(role.position), True),
            ("Mentionable", "Yes" if role.mentionable else "No", True),
            ("Hoisted", "Yes" if role.hoist else "No", True)
        ]
        
        if executor:
            fields.insert(0, ("Created By", executor.mention, True))
        
        if reason:
            fields.append(("Reason", reason, False))
        
        if dangerous_perms:
            fields.append(("⚠️ Dangerous Permissions", "\n".join(dangerous_perms), False))
        
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "CRITICAL" if risk_score > 60 else "WARNING" if risk_score > 30 else "INFO"
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity=severity,
            fields=fields,
            footer=f"Risk Score: {risk_score}/100",
            risk_score=risk_score,
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor) if executor else None

        extra_fields = [
            ("Role", role.name),
            ("Color", str(role.color) if role.color.value else "Default"),
            ("Risk Score", f"{risk_score}/100"),
        ]
        if dangerous_perms:
            extra_fields.append(("Dangerous Perms", ", ".join(dangerous_perms[:3])))

        await self.logging_cog.send_image_log(
            channel_type="role",
            template_name="logging_card",
            severity=severity,
            embed_fallback=embed,
            filename="role_create.png",
            event_type="role_add",
            user=executor, perpetrator=executor,
            content=f"New role created: {role.name}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now())
        
        self.role_snapshots[role.id] = {
            "name": role.name,
            "permissions": permissions,
            "created_at": datetime.now()
        }
    
    async def log_role_delete(self, role: discord.Role):
        """Log role deletion with snapshot"""
        if not self.logging_cog:
            return
        if not await self.should_log_role_events():
            return
        
        executor = None
        reason = None
        
        try:
            async for entry in role.guild.audit_logs(limit=5, action=discord.AuditLogAction.role_delete):
                if entry.target.id == role.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    executor = entry.user
                    reason = entry.reason
                    break
        except Exception:
            pass
        
        snapshot = self.role_snapshots.get(role.id, {})
        permissions = snapshot.get("permissions", {})
        dangerous_perms = self.get_dangerous_permissions(permissions)
        
        risk_score = 0
        reasons = []
        
        if dangerous_perms:
            risk_score += 30
            reasons.append("Deleted role had dangerous permissions")
        
        members_with_role = len([m for m in role.guild.members if role in m.roles])
        if members_with_role > 0:
            risk_score += 15
            reasons.append(f"Role had {members_with_role} members at time of deletion")
        
        risk_score = min(risk_score, 100)
        
        title = "Role Deleted"
        description = f"{self.get_emoji('unadd')} Role deleted: `{role.name}`"
        
        fields = [
            ("Role Name", role.name, True),
            ("Role ID", f"`{role.id}`", True),
            ("Members with Role", str(members_with_role), True)
        ]
        
        if executor:
            fields.insert(0, ("Deleted By", executor.mention, True))
        
        if reason:
            fields.append(("Reason", reason, False))
        
        if dangerous_perms:
            fields.append(("⚠️ Deleted Role Had Dangerous Permissions", "\n".join(dangerous_perms), False))
        
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "CRITICAL" if risk_score > 60 else "WARNING" if risk_score > 30 else "INFO"
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity=severity,
            fields=fields,
            footer=f"Risk Score: {risk_score}/100",
            risk_score=risk_score,
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor) if executor else None

        extra_fields = [
            ("Role", role.name),
            ("Members Affected", str(members_with_role)),
            ("Risk Score", f"{risk_score}/100"),
        ]

        await self.logging_cog.send_image_log(
            channel_type="role",
            template_name="logging_card",
            severity=severity,
            embed_fallback=embed,
            filename="role_delete.png",
            event_type="role_remove",
            user=executor, perpetrator=executor,
            content=f"Role deleted: {role.name}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now())
        
        if role.id in self.role_snapshots:
            del self.role_snapshots[role.id]
    
    async def log_role_update(self, before: discord.Role, after: discord.Role):
        """Log role updates (permission changes, name changes, etc.)"""
        if not self.logging_cog:
            return
        if not await self.should_log_role_events():
            return
        
        changes = []
        
        if before.name != after.name:
            changes.append(f"**Name:** `{before.name}` → `{after.name}`")
        
        if before.color != after.color:
            changes.append(f"**Color:** {before.color} → {after.color}")
        
        if before.mentionable != after.mentionable:
            status = "enabled" if after.mentionable else "disabled"
            changes.append(f"**Mentionable:** {status}")
        
        if before.hoist != after.hoist:
            status = "enabled" if after.hoist else "disabled"
            changes.append(f"**Hoisted:** {status}")
        
        before_perms = self.get_role_permissions_snapshot(before)
        after_perms = self.get_role_permissions_snapshot(after)
        
        perm_changes = self.format_permission_diff(before_perms, after_perms)
        if perm_changes != "No dangerous permission changes":
            changes.append(f"**Permission Changes:**\n{perm_changes}")
        
        if not changes:
            return
        
        executor = None
        reason = None
        
        try:
            async for entry in before.guild.audit_logs(limit=5, action=discord.AuditLogAction.role_update):
                if entry.target.id == before.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    executor = entry.user
                    reason = entry.reason
                    break
        except Exception:
            pass
        
        risk_score = 0
        reasons = []
        
        dangerous_added = []
        for perm_key, perm_name in self.dangerous_permissions.items():
            if after_perms.get(perm_key, False) and not before_perms.get(perm_key, False):
                dangerous_added.append(perm_name)
        
        if dangerous_added:
            risk_score += 45
            reasons.append(f"Dangerous permissions added: {', '.join(dangerous_added)}")
        
        if before.position != after.position:
            risk_score += 15
            reasons.append(f"Role position changed from {before.position} to {after.position}")
        
        risk_score = min(risk_score, 100)
        
        title = "Role Updated"
        description = f"{self.get_emoji('settings')} Role updated: {after.mention}"
        
        fields = [
            ("Role", after.mention, True),
            ("Role ID", f"`{after.id}`", True),
            ("Changes", "\n".join(changes), False)
        ]
        
        if executor:
            fields.insert(0, ("Updated By", executor.mention, True))
        
        if reason:
            fields.append(("Reason", reason, False))
        
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "CRITICAL" if risk_score > 70 else "WARNING" if risk_score > 30 else "INFO"
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity=severity,
            fields=fields,
            footer=f"Risk Score: {risk_score}/100",
            risk_score=risk_score,
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor) if executor else None

        changes_text = "; ".join(c.replace("**", "").replace("`", "") for c in changes[:3])
        extra_fields = [
            ("Role", after.name),
            ("Changes", changes_text[:80]),
            ("Risk Score", f"{risk_score}/100"),
        ]

        await self.logging_cog.send_image_log(
            channel_type="role",
            template_name="logging_card",
            severity=severity,
            embed_fallback=embed,
            filename="role_update.png",
            event_type="role_update",
            user=executor, perpetrator=executor,
            content=f"Role updated: {after.name}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now())
        
        self.role_snapshots[after.id] = {
            "name": after.name,
            "permissions": after_perms,
            "updated_at": datetime.now()
        }
    
    async def log_role_assignment(self, member: discord.Member, roles: List[discord.Role], 
                                  action_type: str, executor: Optional[discord.Member] = None):
        """Log role assignments or removals with mass detection"""
        if not self.logging_cog:
            return
        if not await self.should_log_role_events():
            return
        
        collapse = self.logging_cog.config.get("collapse_role_changes", True) if self.logging_cog else True
        
        current_time = datetime.now()
        self.mass_role_assignments[member.id].append(current_time)
        
        self.mass_role_assignments[member.id] = [
            t for t in self.mass_role_assignments[member.id]
            if (current_time - t).total_seconds() < 10
        ]
        
        is_mass = len(self.mass_role_assignments[member.id]) > 5
        
        admin_roles = []
        dangerous_roles = []
        
        for role in roles:
            perms = self.get_role_permissions_snapshot(role)
            dangerous_perms = self.get_dangerous_permissions(perms)
            
            if perms.get("administrator", False):
                admin_roles.append(role)
                self.admin_role_ids.add(role.id)
            elif dangerous_perms:
                dangerous_roles.append((role, dangerous_perms))
        
        risk_score = 0
        reasons = []
        
        if admin_roles:
            risk_score += 50
            reasons.append(f"Admin role(s) assigned: {', '.join([r.name for r in admin_roles])}")
        
        if dangerous_roles:
            risk_score += 30
            reasons.append(f"Dangerous role(s) assigned: {', '.join([r[0].name for r in dangerous_roles])}")
        
        if is_mass:
            risk_score += 20
            reasons.append(f"Mass role {'assignment' if action_type == 'add' else 'removal'} detected")
        
        if action_type == "remove" and admin_roles:
            risk_score += 25
            reasons.append("Admin role(s) removed - potential privilege revocation")
        
        risk_score = min(risk_score, 100)
        
        if risk_score > 50:
            self.dangerous_role_assignments[member.id].append((datetime.now(), roles[0] if roles else None, executor))
        
        if collapse and len(roles) > 3:
            role_list = f"{', '.join([r.mention for r in roles[:3]])} +{len(roles) - 3} more"
        else:
            role_list = ", ".join([r.mention for r in roles])
        
        action_verb = "assigned" if action_type == "add" else "removed"
        action_emoji = self.get_emoji("add") if action_type == "add" else self.get_emoji("unadd")
        
        title = f"Role{'s' if len(roles) > 1 else ''} {action_verb.capitalize()}"
        description = f"{action_emoji} {action_verb.capitalize()} {len(roles)} role{'s' if len(roles) > 1 else ''} {'to' if action_type == 'add' else 'from'} {member.mention}"
        
        fields = [
            ("User", member.mention, True),
            ("User ID", f"`{member.id}`", True),
            ("Roles", role_list, False)
        ]
        
        if executor and executor != member:
            fields.insert(0, ("Executor", executor.mention, True))
        
        if admin_roles:
            fields.append(("⚠️ Admin Roles", ", ".join([r.mention for r in admin_roles]), False))
        
        if dangerous_roles:
            dangerous_text = "\n".join([f"- {r[0].mention}: {', '.join(r[1][:2])}" for r in dangerous_roles[:3]])
            fields.append(("⚠️ Dangerous Roles", dangerous_text, False))
        
        if is_mass:
            fields.insert(1, ("⚠️ Mass Action", "Rapid successive role changes detected", False))
        
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "CRITICAL" if risk_score > 70 else "WARNING" if risk_score > 30 else "INFO"
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity=severity,
            fields=fields,
            footer=f"Risk Score: {risk_score}/100 | Action: {action_type.upper()}",
            risk_score=risk_score,
            perpetrator=executor
        )

        avatar_img = await self._fetch_avatar(member)

        role_names = ", ".join(r.name for r in roles[:5])
        event_type = "role_add" if action_type == "add" else "role_remove"
        extra_fields = [
            ("Roles", role_names),
            ("Action", action_type.upper()),
            ("Risk Score", f"{risk_score}/100"),
        ]

        await self.logging_cog.send_image_log(
            channel_type="role",
            template_name="logging_card",
            severity=severity,
            embed_fallback=embed,
            filename=f"role_{action_type}.png",
            event_type=event_type,
            user=member,
            perpetrator=executor,
            content=f"{action_verb.capitalize()} {len(roles)} role(s): {role_names}",
            extra_fields=extra_fields,
            avatar_image=avatar_img,
            timestamp=datetime.now())
    
    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        """Listener for role creation"""
        await self.log_role_create(role)
    
    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        """Listener for role deletion"""
        await self.log_role_delete(role)
    
    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role):
        """Listener for role updates"""
        await self.log_role_update(before, after)
    
    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """Track role assignments/removals"""
        if not await self.should_log_role_events():
            return
        
        before_roles = set(before.roles)
        after_roles = set(after.roles)
        
        added_roles = after_roles - before_roles
        removed_roles = before_roles - after_roles
        
        executor = None
        
        if added_roles or removed_roles:
            try:
                async for entry in after.guild.audit_logs(limit=5, action=discord.AuditLogAction.member_role_update):
                    if entry.target.id == after.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 5:
                        executor = entry.user
                        break
            except Exception:
                pass
        
        if added_roles:
            await self.log_role_assignment(after, list(added_roles), "add", executor)
        
        if removed_roles:
            await self.log_role_assignment(after, list(removed_roles), "remove", executor)
    
    @commands.command(name="role-info")
    @commands.has_permissions(manage_roles=True)
    async def role_info(self, ctx: commands.Context, role: discord.Role):
        """Get detailed information about a role"""
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Logging system not ready")
            return
        
        permissions = self.get_role_permissions_snapshot(role)
        dangerous_perms = self.get_dangerous_permissions(permissions)
        
        members_with_role = len([m for m in ctx.guild.members if role in m.roles])
        
        embed = discord.Embed(
            title=f"{self.get_emoji('key')} Role Information: {role.name}",
            color=role.color if role.color.value else 0x3498db,
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Role ID", value=f"`{role.id}`", inline=True)
        embed.add_field(name="Position", value=str(role.position), inline=True)
        embed.add_field(name="Color", value=str(role.color) if role.color.value else "Default", inline=True)
        embed.add_field(name="Members", value=str(members_with_role), inline=True)
        embed.add_field(name="Mentionable", value="✅ Yes" if role.mentionable else "❌ No", inline=True)
        embed.add_field(name="Hoisted", value="✅ Yes" if role.hoist else "❌ No", inline=True)
        
        if dangerous_perms:
            embed.add_field(name="⚠️ Dangerous Permissions", value="\n".join(dangerous_perms), inline=False)
        
        if permissions.get("administrator", False):
            embed.add_field(name="🚨 CRITICAL", value="This role has **ADMINISTRATOR** permissions!", inline=False)
            embed.color = 0xe74c3c
        
        await ctx.send(embed=embed)
    
    @commands.command(name="role-snapshot")
    @commands.has_permissions(administrator=True)
    async def role_snapshot(self, ctx: commands.Context):
        """Take a snapshot of all current roles"""
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Logging system not ready")
            return
        
        embed = discord.Embed(
            title=f"{self.get_emoji('list')} Role Snapshot",
            description=f"Current roles in {ctx.guild.name}",
            color=0x3498db,
            timestamp=datetime.now()
        )
        
        admin_roles = []
        dangerous_roles = []
        normal_roles = []
        
        for role in ctx.guild.roles:
            perms = self.get_role_permissions_snapshot(role)
            dangerous_perms = self.get_dangerous_permissions(perms)
            
            if perms.get("administrator", False):
                admin_roles.append(role.name)
            elif dangerous_perms:
                dangerous_roles.append(f"{role.name} ({', '.join(dangerous_perms[:2])})")
            else:
                normal_roles.append(role.name)
        
        embed.add_field(name="🚨 Admin Roles", value="\n".join(admin_roles) if admin_roles else "None", inline=False)
        embed.add_field(name="⚠️ Dangerous Roles", value="\n".join(dangerous_roles[:10]) if dangerous_roles else "None", inline=False)
        embed.add_field(name="✅ Normal Roles", value=f"{len(normal_roles)} roles", inline=False)
        
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    """Setup function for the cog"""
    cog = RoleLogsCog(bot)
    await bot.add_cog(cog)
