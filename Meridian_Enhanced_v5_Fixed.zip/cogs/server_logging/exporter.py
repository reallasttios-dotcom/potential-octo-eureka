import discord
from discord.ext import commands
from typing import Dict, List, Optional, Tuple, Any, Union
from datetime import datetime, timedelta
import json
import csv
import os
import asyncio
import zipfile
from io import StringIO, BytesIO
from collections import defaultdict
import sqlite3
from pathlib import Path


class ExporterCog(commands.Cog):
    """Handle data export, backups, and log management"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logging_cog = None
        self.export_queue: List[Dict[str, Any]] = []
        self.backup_schedule: Dict[int, datetime] = {}
        self.db_connection: Optional[sqlite3.Connection] = None
        self.export_formats = ["json", "csv", "sqlite"]
        
        os.makedirs("logs/exports", exist_ok=True)
        os.makedirs("logs/backups", exist_ok=True)
        os.makedirs("logs/archives", exist_ok=True)
        
    async def cog_load(self):
        """Initialize cog and get reference to main logging cog"""
        await self.bot.wait_until_ready()
        self.logging_cog = self.bot.get_cog("LoggingCog")
        
        if self.logging_cog and self.logging_cog.config.get("use_sqlite", False):
            await self.init_sqlite()
        
        asyncio.create_task(self.backup_rotation_loop())
        
    def get_emoji(self, key: str) -> str:
        """Get emoji from main logging cog"""
        if self.logging_cog and hasattr(self.logging_cog, 'get_emoji'):
            return self.logging_cog.get_emoji(key)
        return ""
    
    async def should_allow_export(self, ctx: commands.Context) -> bool:
        """Check if user has permission to export"""
        return ctx.author.guild_permissions.administrator
    
    async def init_sqlite(self):
        """Initialize SQLite database for logging"""
        db_path = self.logging_cog.config.get("db_path", "logs/logging.db") if self.logging_cog else "logs/logging.db"
        
        self.db_connection = sqlite3.connect(db_path)
        cursor = self.db_connection.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT UNIQUE,
                guild_id INTEGER,
                channel_id INTEGER,
                user_id INTEGER,
                action_type TEXT,
                severity TEXT,
                details TEXT,
                risk_score INTEGER,
                timestamp DATETIME
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                guild_id INTEGER,
                action_type TEXT,
                details TEXT,
                risk_score INTEGER,
                timestamp DATETIME
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS exports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                export_type TEXT,
                format TEXT,
                file_path TEXT,
                created_by INTEGER,
                created_at DATETIME
            )
        """)
        
        self.db_connection.commit()
        
    async def log_to_sqlite(self, event_data: Dict[str, Any]):
        """Log event to SQLite database"""
        if not self.db_connection:
            return
        
        try:
            cursor = self.db_connection.cursor()
            cursor.execute("""
                INSERT INTO audit_logs (event_id, guild_id, channel_id, user_id, action_type, severity, details, risk_score, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                event_data.get("event_id"),
                event_data.get("guild_id"),
                event_data.get("channel_id"),
                event_data.get("user_id"),
                event_data.get("action_type"),
                event_data.get("severity"),
                json.dumps(event_data.get("details", {})),
                event_data.get("risk_score", 0),
                datetime.now()
            ))
            self.db_connection.commit()
        except Exception as e:
            print(f"SQLite logging error: {e}")
    
    async def export_to_json(self, data: List[Dict[str, Any]], filename: str) -> str:
        """Export data to JSON format"""
        filepath = f"logs/exports/{filename}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        def json_serializer(obj):
            if isinstance(obj, datetime):
                return obj.isoformat()
            raise TypeError(f"Type {type(obj)} not serializable")
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, default=json_serializer, indent=2, ensure_ascii=False)
        
        return filepath
    
    async def export_to_csv(self, data: List[Dict[str, Any]], filename: str) -> str:
        """Export data to CSV format"""
        filepath = f"logs/exports/{filename}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        if not data:
            raise ValueError("No data to export")
        
        fieldnames = set()
        for row in data:
            fieldnames.update(row.keys())
        fieldnames = sorted(list(fieldnames))
        
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            
            for row in data:
                row_copy = {}
                for key, value in row.items():
                    if isinstance(value, datetime):
                        row_copy[key] = value.isoformat()
                    elif isinstance(value, dict):
                        row_copy[key] = json.dumps(value)
                    else:
                        row_copy[key] = value
                writer.writerow(row_copy)
        
        return filepath
    
    async def create_zip_archive(self, files: List[str], archive_name: str) -> str:
        """Create ZIP archive of multiple files"""
        archive_path = f"logs/archives/{archive_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        
        with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for file in files:
                if os.path.exists(file):
                    zipf.write(file, os.path.basename(file))
        
        return archive_path
    
    async def collect_audit_logs(self, guild: discord.Guild, limit: int = 1000) -> List[Dict[str, Any]]:
        """Collect audit logs from Discord"""
        logs = []
        
        try:
            async for entry in guild.audit_logs(limit=limit):
                log_entry = {
                    "id": entry.id,
                    "action": str(entry.action),
                    "user_id": entry.user.id if entry.user else None,
                    "user_name": str(entry.user) if entry.user else "Unknown",
                    "target_id": entry.target.id if entry.target else None,
                    "target_type": str(type(entry.target).__name__) if entry.target else None,
                    "reason": entry.reason,
                    "created_at": entry.created_at.isoformat(),
                    "changes": [{"name": c.name, "before": c.before, "after": c.after} for c in entry.changes] if entry.changes else []
                }
                logs.append(log_entry)
        except Exception as e:
            print(f"Error collecting audit logs: {e}")
        
        return logs
    
    async def collect_user_actions(self, user_id: int, guild_id: int = None) -> List[Dict[str, Any]]:
        """Collect actions for a specific user"""
        actions = []
        
        if self.logging_cog and hasattr(self.logging_cog, 'risk_scorer'):
            risk_history = self.logging_cog.risk_scorer.risk_history.get(user_id, [])
            
            for entry in risk_history:
                actions.append({
                    "user_id": user_id,
                    "action": entry.get("action"),
                    "risk_score": entry.get("score"),
                    "reasons": entry.get("reasons", []),
                    "timestamp": entry.get("timestamp", datetime.now()).isoformat()
                })
        
        intelligence_cog = self.bot.get_cog("IntelligenceCog")
        if intelligence_cog and hasattr(intelligence_cog, 'user_behavior'):
            behavior = intelligence_cog.user_behavior.get(user_id, {})
            timeline = behavior.get("action_timeline", [])
            
            for action in timeline:
                actions.append({
                    "user_id": user_id,
                    "action": action.get("action"),
                    "details": action.get("details", {}),
                    "timestamp": action.get("timestamp", datetime.now()).isoformat()
                })
        
        return actions
    
    async def collect_date_range_logs(self, guild: discord.Guild, start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
        """Collect logs within date range"""
        logs = await self.collect_audit_logs(guild, limit=5000)
        
        filtered_logs = []
        for log in logs:
            log_date_str = log["created_at"]
            if log_date_str.endswith("+00:00"):
                log_date_str = log_date_str[:-6]
            log_date = datetime.fromisoformat(log_date_str)
            if start_date <= log_date <= end_date:
                filtered_logs.append(log)
        
        return filtered_logs
    
    async def perform_auto_backup(self, guild: discord.Guild) -> str:
        """Perform automatic backup of all critical data"""
        backup_dir = f"logs/backups/{guild.id}"
        os.makedirs(backup_dir, exist_ok=True)
        
        backup_files = []
        
        audit_logs = await self.collect_audit_logs(guild, limit=2000)
        if audit_logs:
            json_path = await self.export_to_json(audit_logs, f"backup_{guild.id}_audit")
            backup_files.append(json_path)
        
        server_snapshot = {
            "guild_id": guild.id,
            "guild_name": guild.name,
            "owner_id": guild.owner_id,
            "member_count": guild.member_count,
            "channel_count": len(guild.channels),
            "role_count": len(guild.roles),
            "backup_time": datetime.now().isoformat()
        }
        
        snapshot_path = f"{backup_dir}/server_snapshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(snapshot_path, 'w') as f:
            json.dump(server_snapshot, f, indent=2)
        backup_files.append(snapshot_path)
        
        archive_path = await self.create_zip_archive(backup_files, f"full_backup_{guild.id}")
        
        for file in backup_files:
            try:
                os.remove(file)
            except Exception:
                pass
        
        return archive_path
    
    async def rotate_backups(self, guild_id: int, max_backups: int = 10):
        """Rotate old backups"""
        backup_dir = f"logs/backups/{guild_id}"
        if not os.path.exists(backup_dir):
            return
        
        backups = []
        for file in os.listdir(backup_dir):
            if file.endswith('.zip'):
                filepath = os.path.join(backup_dir, file)
                backups.append((filepath, os.path.getmtime(filepath)))
        
        backups.sort(key=lambda x: x[1])
        
        while len(backups) > max_backups:
            old_file = backups.pop(0)[0]
            try:
                os.remove(old_file)
            except Exception:
                pass
    
    async def backup_rotation_loop(self):
        """Background task for automatic backup rotation"""
        await self.bot.wait_until_ready()
        
        while not self.bot.is_closed():
            await asyncio.sleep(86400)
            
            if not self.logging_cog:
                continue
            
            auto_backup = self.logging_cog.config.get("auto_backup", True)
            if not auto_backup:
                continue
            
            for guild in self.bot.guilds:
                await self.rotate_backups(guild.id)
    
    async def search_logs(self, guild: discord.Guild, keyword: str, limit: int = 100) -> List[Dict[str, Any]]:
        """Search logs for keywords"""
        results = []
        
        try:
            async for entry in guild.audit_logs(limit=limit):
                if keyword.lower() in str(entry.action).lower():
                    results.append({
                        "type": "audit_log",
                        "id": entry.id,
                        "action": str(entry.action),
                        "user": str(entry.user) if entry.user else "Unknown",
                        "reason": entry.reason,
                        "created_at": entry.created_at.isoformat()
                    })
                elif entry.reason and keyword.lower() in entry.reason.lower():
                    results.append({
                        "type": "audit_log",
                        "id": entry.id,
                        "action": str(entry.action),
                        "user": str(entry.user) if entry.user else "Unknown",
                        "reason": entry.reason,
                        "created_at": entry.created_at.isoformat()
                    })
        except Exception:
            pass
        
        return results
    
    async def send_file_to_user(self, user: discord.User, filepath: str, filename: str = None):
        """Send exported file to user via DM"""
        try:
            if not os.path.exists(filepath):
                raise FileNotFoundError(f"File not found: {filepath}")
            
            filename = filename or os.path.basename(filepath)
            with open(filepath, 'rb') as f:
                file = discord.File(f, filename=filename)
                await user.send(f"{self.get_emoji('success')} Here's your exported data:", file=file)
        except discord.Forbidden:
            raise
        finally:
            try:
                os.remove(filepath)
            except Exception:
                pass
    
    @commands.group(name="export")
    @commands.has_permissions(administrator=True)
    async def export_group(self, ctx: commands.Context):
        """Export logs and data"""
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title=f"{self.get_emoji('list')} Export Commands",
                description="Export logs in various formats",
                color=0x3498db
            )
            embed.add_field(
                name="Available Commands",
                value=(
                    "`!export json` - Export all logs as JSON\n"
                    "`!export csv` - Export all logs as CSV\n"
                    "`!export user @user` - Export logs for a specific user\n"
                    "`!export range YYYY-MM-DD YYYY-MM-DD` - Export logs within date range\n"
                    "`!export full` - Full server audit export\n"
                    "`!export search <keyword>` - Search logs for keyword"
                ),
                inline=False
            )
            await ctx.send(embed=embed)
    
    @export_group.command(name="json")
    async def export_json(self, ctx: commands.Context):
        """Export all logs as JSON"""
        await ctx.send(f"{self.get_emoji('info')} Collecting audit logs... This may take a moment.")
        
        try:
            logs = await self.collect_audit_logs(ctx.guild, limit=2000)
            filepath = await self.export_to_json(logs, f"export_{ctx.guild.id}")
            await self.send_file_to_user(ctx.author, filepath, f"audit_logs_{ctx.guild.name}.json")
            await ctx.send(f"{self.get_emoji('success')} Export complete! Check your DMs.")
        except Exception as e:
            await ctx.send(f"{self.get_emoji('error')} Export failed: {str(e)}")
    
    @export_group.command(name="csv")
    async def export_csv(self, ctx: commands.Context):
        """Export all logs as CSV"""
        await ctx.send(f"{self.get_emoji('info')} Collecting audit logs... This may take a moment.")
        
        try:
            logs = await self.collect_audit_logs(ctx.guild, limit=2000)
            filepath = await self.export_to_csv(logs, f"export_{ctx.guild.id}")
            await self.send_file_to_user(ctx.author, filepath, f"audit_logs_{ctx.guild.name}.csv")
            await ctx.send(f"{self.get_emoji('success')} Export complete! Check your DMs.")
        except Exception as e:
            await ctx.send(f"{self.get_emoji('error')} Export failed: {str(e)}")
    
    @export_group.command(name="user")
    async def export_user(self, ctx: commands.Context, user: discord.User):
        """Export logs for a specific user"""
        await ctx.send(f"{self.get_emoji('info')} Collecting actions for {user.display_name}...")
        
        try:
            actions = await self.collect_user_actions(user.id, ctx.guild.id)
            
            if not actions:
                await ctx.send(f"{self.get_emoji('info')} No actions found for {user.mention}")
                return
            
            filepath = await self.export_to_json(actions, f"user_{user.id}_{ctx.guild.id}")
            await self.send_file_to_user(ctx.author, filepath, f"user_{user.name}_actions.json")
            await ctx.send(f"{self.get_emoji('success')} Export complete! Found {len(actions)} actions.")
        except Exception as e:
            await ctx.send(f"{self.get_emoji('error')} Export failed: {str(e)}")
    
    @export_group.command(name="range")
    async def export_range(self, ctx: commands.Context, start_date: str, end_date: str):
        """Export logs within date range"""
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
            
            if start > end:
                await ctx.send(f"{self.get_emoji('error')} Start date must be before end date")
                return
            
            await ctx.send(f"{self.get_emoji('info')} Collecting logs from {start_date} to {end_date}...")
            
            logs = await self.collect_date_range_logs(ctx.guild, start, end)
            
            if not logs:
                await ctx.send(f"{self.get_emoji('info')} No logs found in the specified date range")
                return
            
            filepath = await self.export_to_json(logs, f"range_{ctx.guild.id}_{start_date}_to_{end_date}")
            await self.send_file_to_user(ctx.author, filepath, f"audit_logs_{start_date}_to_{end_date}.json")
            await ctx.send(f"{self.get_emoji('success')} Export complete! Found {len(logs)} logs.")
        except ValueError:
            await ctx.send(f"{self.get_emoji('error')} Invalid date format. Use YYYY-MM-DD")
        except Exception as e:
            await ctx.send(f"{self.get_emoji('error')} Export failed: {str(e)}")
    
    @export_group.command(name="full")
    async def export_full(self, ctx: commands.Context):
        """Full server audit export"""
        await ctx.send(f"{self.get_emoji('info')} Performing full server audit export... This may take several minutes.")
        
        try:
            export_data = {
                "server_info": {
                    "guild_id": ctx.guild.id,
                    "guild_name": ctx.guild.name,
                    "owner": str(ctx.guild.owner),
                    "member_count": ctx.guild.member_count,
                    "channel_count": len(ctx.guild.channels),
                    "role_count": len(ctx.guild.roles),
                    "export_time": datetime.now().isoformat()
                },
                "audit_logs": await self.collect_audit_logs(ctx.guild, limit=5000),
                "roles": [
                    {
                        "id": role.id,
                        "name": role.name,
                        "position": role.position,
                        "permissions": dict(role.permissions),
                        "member_count": len(role.members)
                    }
                    for role in ctx.guild.roles
                ],
                "channels": [
                    {
                        "id": channel.id,
                        "name": channel.name,
                        "type": str(channel.type),
                        "position": channel.position
                    }
                    for channel in ctx.guild.channels
                ]
            }
            
            filepath = await self.export_to_json([export_data], f"full_audit_{ctx.guild.id}")
            await self.send_file_to_user(ctx.author, filepath, f"full_audit_{ctx.guild.name}.json")
            await ctx.send(f"{self.get_emoji('success')} Full audit export complete! Check your DMs.")
        except Exception as e:
            await ctx.send(f"{self.get_emoji('error')} Export failed: {str(e)}")
    
    @export_group.command(name="search")
    async def export_search(self, ctx: commands.Context, *, keyword: str):
        """Search logs for keyword and export results"""
        await ctx.send(f"{self.get_emoji('search')} Searching for '{keyword}'...")
        
        try:
            results = await self.search_logs(ctx.guild, keyword, limit=500)
            
            if not results:
                await ctx.send(f"{self.get_emoji('info')} No results found for '{keyword}'")
                return
            
            filepath = await self.export_to_json(results, f"search_{ctx.guild.id}_{keyword.replace(' ', '_')}")
            await self.send_file_to_user(ctx.author, filepath, f"search_results_{keyword}.json")
            await ctx.send(f"{self.get_emoji('success')} Found {len(results)} results! Check your DMs.")
        except Exception as e:
            await ctx.send(f"{self.get_emoji('error')} Search failed: {str(e)}")
    
    @commands.command(name="backup")
    @commands.has_permissions(administrator=True)
    async def backup_now(self, ctx: commands.Context):
        """Create an emergency backup of all critical data"""
        await ctx.send(f"{self.get_emoji('info')} Creating emergency backup... This may take a moment.")
        
        try:
            backup_path = await self.perform_auto_backup(ctx.guild)
            
            with open(backup_path, 'rb') as f:
                file = discord.File(f, filename=f"emergency_backup_{ctx.guild.name}.zip")
                await ctx.author.send(f"{self.get_emoji('success')} Emergency backup created:", file=file)
            
            await ctx.send(f"{self.get_emoji('success')} Backup complete! Check your DMs.")
            
            try:
                os.remove(backup_path)
            except Exception:
                pass
        except Exception as e:
            await ctx.send(f"{self.get_emoji('error')} Backup failed: {str(e)}")
    
    @commands.command(name="restore-export")
    @commands.has_permissions(administrator=True)
    async def restore_export(self, ctx: commands.Context):
        """Generate restore export for emergency recovery"""
        await ctx.send(f"{self.get_emoji('info')} Generating restore export...")
        
        try:
            restore_data = {
                "guild_id": ctx.guild.id,
                "guild_name": ctx.guild.name,
                "export_time": datetime.now().isoformat(),
                "exported_by": str(ctx.author),
                "server_config": {
                    "verification_level": str(ctx.guild.verification_level),
                    "default_notifications": str(ctx.guild.default_notifications),
                    "explicit_content_filter": str(ctx.guild.explicit_content_filter),
                    "afk_timeout": ctx.guild.afk_timeout,
                    "system_channel_id": ctx.guild.system_channel_id,
                    "rules_channel_id": ctx.guild.rules_channel_id,
                    "public_updates_channel_id": ctx.guild.public_updates_channel_id
                },
                "roles": [
                    {
                        "name": role.name,
                        "permissions": dict(role.permissions),
                        "color": role.color.value,
                        "hoist": role.hoist,
                        "mentionable": role.mentionable
                    }
                    for role in ctx.guild.roles if role.name != "@everyone"
                ],
                "channels": [
                    {
                        "name": channel.name,
                        "type": str(channel.type),
                        "category_id": channel.category_id if hasattr(channel, 'category_id') else None,
                        "position": channel.position
                    }
                    for channel in ctx.guild.channels
                ]
            }
            
            filepath = await self.export_to_json([restore_data], f"restore_export_{ctx.guild.id}")
            await self.send_file_to_user(ctx.author, filepath, f"restore_export_{ctx.guild.name}.json")
            await ctx.send(f"{self.get_emoji('success')} Restore export generated! Check your DMs.")
        except Exception as e:
            await ctx.send(f"{self.get_emoji('error')} Restore export failed: {str(e)}")
    
    @commands.command(name="stats-export")
    @commands.has_permissions(administrator=True)
    async def stats_export(self, ctx: commands.Context):
        """Export server statistics"""
        await ctx.send(f"{self.get_emoji('info')} Gathering statistics...")
        
        try:
            intelligence_cog = self.bot.get_cog("IntelligenceCog")
            
            stats = {
                "server": ctx.guild.name,
                "export_time": datetime.now().isoformat(),
                "member_stats": {
                    "total_members": ctx.guild.member_count,
                    "bot_count": len([m for m in ctx.guild.members if m.bot]),
                    "human_count": len([m for m in ctx.guild.members if not m.bot])
                },
                "channel_stats": {
                    "text_channels": len(ctx.guild.text_channels),
                    "voice_channels": len(ctx.guild.voice_channels),
                    "categories": len(ctx.guild.categories)
                },
                "role_stats": {
                    "total_roles": len(ctx.guild.roles),
                    "admin_roles": len([r for r in ctx.guild.roles if r.permissions.administrator])
                },
                "activity_stats": {}
            }
            
            if intelligence_cog:
                heatmap = intelligence_cog.heatmap_data.get(ctx.guild.id, {})
                if heatmap:
                    stats["activity_stats"]["peak_hours"] = dict(sorted(heatmap.items(), key=lambda x: x[1], reverse=True)[:5])
                
                risk_trend = await intelligence_cog.generate_risk_trend(ctx.guild.id)
                if risk_trend:
                    stats["activity_stats"]["risk_trend"] = risk_trend[-10:]
                
                mod_leaderboard = intelligence_cog.server_intelligence[ctx.guild.id].get("mod_leaderboard", {})
                if mod_leaderboard:
                    top_mods = sorted(mod_leaderboard.items(), key=lambda x: x[1], reverse=True)[:10]
                    stats["activity_stats"]["top_moderators"] = [
                        {"user_id": uid, "action_count": count} for uid, count in top_mods
                    ]
            
            filepath = await self.export_to_json([stats], f"server_stats_{ctx.guild.id}")
            await self.send_file_to_user(ctx.author, filepath, f"server_stats_{ctx.guild.name}.json")
            await ctx.send(f"{self.get_emoji('success')} Statistics export complete! Check your DMs.")
        except Exception as e:
            await ctx.send(f"{self.get_emoji('error')} Stats export failed: {str(e)}")


async def setup(bot: commands.Bot):
    """Setup function for the cog"""
    cog = ExporterCog(bot)
    await bot.add_cog(cog)
