import discord
from discord.ext import commands
from typing import Dict, List, Optional, Tuple, Any, Set, Union
from datetime import datetime, timedelta
from collections import defaultdict
import asyncio
import re


class SecurityLogsCog(commands.Cog):
    """Handle security events, nuke attempts, webhook tracking, and raid detection"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logging_cog = None
        self.webhook_cache: Dict[int, Dict[str, Any]] = {}
        self.webhook_creation_buffer: Dict[int, List[datetime]] = defaultdict(list)
        self.bot_add_buffer: Dict[int, List[Tuple[datetime, discord.User, discord.Member]]] = defaultdict(list)
        self.raid_detection_state: Dict[int, Dict[str, Any]] = {}
        self.nuke_attempts: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
        self.ownership_transfer_tracker: Dict[int, Dict[str, Any]] = {}
        self.vanity_url_history: Dict[int, List[Tuple[datetime, str, str]]] = defaultdict(list)
        self.suspicious_admin_actions: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
        
        self.dangerous_permission_combos = [
            ["administrator", "manage_guild"],
            ["administrator", "manage_channels"],
            ["administrator", "manage_webhooks"],
            ["manage_guild", "manage_roles", "kick_members"],
            ["manage_webhooks", "manage_channels", "administrator"],
            ["ban_members", "kick_members", "manage_messages"]
        ]
        
        self.raid_thresholds = {
            "join_rate": 10,
            "channel_create_rate": 5,
            "webhook_create_rate": 3,
            "role_change_rate": 8,
            "permission_change_rate": 5
        }
        
    async def cog_load(self):
        """Initialize cog and get reference to main logging cog"""
        await self.bot.wait_until_ready()
        self.logging_cog = self.bot.get_cog("LoggingCog")
        
        asyncio.create_task(self.raid_detection_loop())
        
    def get_emoji(self, key: str) -> str:
        """Get emoji from main logging cog"""
        if self.logging_cog and hasattr(self.logging_cog, 'get_emoji'):
            return self.logging_cog.get_emoji(key)
        return ""

    async def _fetch_avatar(self, user: discord.User) -> "Optional[Any]":
        """Fetch user avatar as PIL Image for imaging templates."""
        if not hasattr(self.bot, 'imaging'):
            return None
        try:
            avatar_bytes = await user.display_avatar.with_size(128).read()
            from PIL import Image
            import io
            return Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
        except Exception:
            return None
    
    async def should_log_security_events(self) -> bool:
        """Check if security events should be logged"""
        if not self.logging_cog:
            return True
        return self.logging_cog.config.is_category_enabled("security_logs")
    
    def detect_webhook_spam(self, guild_id: int) -> Tuple[bool, int]:
        """Detect mass webhook creation"""
        current_time = datetime.now()
        
        self.webhook_creation_buffer[guild_id] = [
            t for t in self.webhook_creation_buffer[guild_id]
            if (current_time - t).total_seconds() < 60
        ]
        
        threshold = self.logging_cog.config.get("mass_webhook_threshold", 3) if self.logging_cog else 3
        
        if len(self.webhook_creation_buffer[guild_id]) >= threshold:
            return True, len(self.webhook_creation_buffer[guild_id])
        
        return False, 0
    
    def detect_bot_spam(self, guild_id: int) -> Tuple[bool, int, List[str]]:
        """Detect mass bot additions"""
        current_time = datetime.now()
        
        self.bot_add_buffer[guild_id] = [
            (t, user, bot) for (t, user, bot) in self.bot_add_buffer[guild_id]
            if (current_time - t).total_seconds() < 120
        ]
        
        if len(self.bot_add_buffer[guild_id]) >= 3:
            bots_added = [f"<@{bot.id}>" for _, _, bot in self.bot_add_buffer[guild_id][-5:]]
            return True, len(self.bot_add_buffer[guild_id]), bots_added
        
        return False, 0, []
    
    def check_dangerous_permission_combo(self, permissions: Dict[str, bool]) -> Tuple[bool, List[str]]:
        """Check if permissions contain dangerous combinations"""
        detected_combos = []
        
        for combo in self.dangerous_permission_combos:
            if all(permissions.get(perm, False) for perm in combo):
                detected_combos.append(f"{' + '.join(combo)}")
        
        return len(detected_combos) > 0, detected_combos
    
    def calculate_raid_probability(self, guild_id: int) -> Tuple[int, List[str]]:
        """Calculate raid probability score"""
        probability = 0
        factors = []
        
        if self.logging_cog and hasattr(self.logging_cog, 'join_spam_tracker'):
            joins = self.logging_cog.join_spam_tracker.get(guild_id, [])
            current_time = datetime.now()
            recent_joins = [j for j in joins if (current_time - j).total_seconds() < 60]
            
            if len(recent_joins) >= self.raid_thresholds["join_rate"]:
                probability += 40
                factors.append(f"High join rate: {len(recent_joins)}/min")
        
        channel_creations = self.webhook_creation_buffer.get(guild_id, [])
        recent_channels = [c for c in channel_creations if (datetime.now() - c).total_seconds() < 30]
        
        if len(recent_channels) >= self.raid_thresholds["channel_create_rate"]:
            probability += 25
            factors.append(f"Rapid channel creation: {len(recent_channels)}/30s")
        
        webhooks = self.webhook_creation_buffer.get(guild_id, [])
        recent_webhooks = [w for w in webhooks if (datetime.now() - w).total_seconds() < 60]
        
        if len(recent_webhooks) >= self.raid_thresholds["webhook_create_rate"]:
            probability += 20
            factors.append(f"Mass webhook creation: {len(recent_webhooks)}/min")
        
        suspicious_actions = self.suspicious_admin_actions.get(guild_id, [])
        recent_suspicious = [a for a in suspicious_actions if (datetime.now() - a["timestamp"]).total_seconds() < 300]
        
        if len(recent_suspicious) >= 3:
            probability += 15
            factors.append(f"Multiple suspicious admin actions: {len(recent_suspicious)}")
        
        probability = min(probability, 100)
        
        return probability, factors
    
    async def raid_detection_loop(self):
        """Background task to detect and alert on raids"""
        await self.bot.wait_until_ready()
        
        while not self.bot.is_closed():
            await asyncio.sleep(30)
            
            if not self.logging_cog:
                continue
            
            for guild in self.bot.guilds:
                if not await self.should_log_security_events():
                    continue
                
                probability, factors = self.calculate_raid_probability(guild.id)
                
                old_state = self.raid_detection_state.get(guild.id, {})
                self.raid_detection_state[guild.id] = {
                    "probability": probability,
                    "factors": factors,
                    "last_updated": datetime.now(),
                    "active_raid": probability > 70
                }
                
                if probability > 70 and not old_state.get("active_raid", False):
                    await self.alert_raid_detected(guild, probability, factors)
                elif probability > 50 and probability <= 70 and not old_state.get("warning_sent", False):
                    await self.alert_raid_warning(guild, probability, factors)
                    self.raid_detection_state[guild.id]["warning_sent"] = True
    
    async def alert_raid_detected(self, guild: discord.Guild, probability: int, factors: List[str]):
        """Alert when a raid is detected"""
        if not await self.should_log_security_events():
            return
        
        if not self.logging_cog:
            return
        
        title = "🚨 RAID DETECTED 🚨"
        description = f"{self.get_emoji('warning')} **HIGH PROBABILITY OF RAID ATTACK**\nProbability: {probability}%"
        
        fields = [
            ("Server", guild.name, True),
            ("Probability", f"**{probability}%**", True),
            ("Risk Level", "**CRITICAL**", True),
            ("Detection Factors", "\n".join(factors[:5]), False),
            ("Recommended Actions",
             "1. Enable raid mode: `!logs raidmode`\n"
             "2. Increase verification level\n"
             "3. Disable @everyone permissions\n"
             "4. Review recent admin actions", False)
        ]
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity="CRITICAL",
            fields=fields,
            footer="⚠️ IMMEDIATE ACTION REQUIRED ⚠️",
            risk_score=100
        )

        extra_fields = [
            ("Server", guild.name),
            ("Probability", f"{probability}%"),
            ("Factors", "; ".join(factors[:3])),
        ]

        await self.logging_cog.send_image_log(
            channel_type="security",
            template_name="logging_card",
            severity="CRITICAL",
            embed_fallback=embed,
            filename="raid_detected.png",
            event_type="raid_detected",
            content=f"RAID DETECTED — Probability {probability}%",
            extra_fields=extra_fields,
            timestamp=datetime.now(),
        )
        
        if self.logging_cog and self.logging_cog.config.get("raid_mode", False):
            self.logging_cog.config.set("raid_mode", True)
    
    async def alert_raid_warning(self, guild: discord.Guild, probability: int, factors: List[str]):
        """Alert when raid probability is elevated"""
        if not await self.should_log_security_events():
            return
        
        if not self.logging_cog:
            return
        
        title = "⚠️ Elevated Raid Risk"
        description = f"Suspicious activity detected - raid probability: {probability}%"
        
        fields = [
            ("Server", guild.name, True),
            ("Probability", f"{probability}%", True),
            ("Risk Level", "HIGH", True),
            ("Detection Factors", "\n".join(factors[:3]), False)
        ]
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity="WARNING",
            fields=fields,
            footer="Monitor server activity closely",
            risk_score=probability
        )

        extra_fields = [
            ("Server", guild.name),
            ("Probability", f"{probability}%"),
            ("Factors", "; ".join(factors[:3])),
        ]

        await self.logging_cog.send_image_log(
            channel_type="security",
            template_name="logging_card",
            severity="WARNING",
            embed_fallback=embed,
            filename="raid_warning.png",
            event_type="raid_warning",
            content=f"Elevated raid risk — {probability}% probability",
            extra_fields=extra_fields,
            timestamp=datetime.now(),
        )
    
    async def log_webhook_create(self, webhook: discord.Webhook):
        """Log webhook creation with risk analysis"""
        if not await self.should_log_security_events():
            return
        
        if not self.logging_cog:
            return
        
        self.webhook_creation_buffer[webhook.guild.id].append(datetime.now())
        
        is_mass, mass_count = self.detect_webhook_spam(webhook.guild.id)
        
        executor = None
        reason = None
        
        try:
            async for entry in webhook.guild.audit_logs(limit=5, action=discord.AuditLogAction.webhook_create):
                if entry.target.id == webhook.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    executor = entry.user
                    reason = entry.reason
                    break
        except Exception:
            pass
        
        risk_score = 0
        reasons = []
        
        if is_mass:
            risk_score += 50
            reasons.append(f"Mass webhook creation detected ({mass_count} webhooks in 60 seconds)")
        
        suspicious_names = ["exploit", "hack", "raid", "spam", "nuke", "backdoor"]
        if any(pattern in webhook.name.lower() for pattern in suspicious_names):
            risk_score += 25
            reasons.append(f"Suspicious webhook name: '{webhook.name}'")
        
        risk_score = min(risk_score, 100)
        
        title = "Webhook Created"
        description = f"{self.get_emoji('warning')} New webhook created in {webhook.channel.mention if webhook.channel else 'Unknown channel'}"
        
        fields = [
            ("Webhook Name", webhook.name, True),
            ("Webhook ID", f"`{webhook.id}`", True),
            ("Channel", webhook.channel.mention if webhook.channel else "Unknown", True)
        ]
        
        if executor:
            fields.insert(0, ("Created By", executor.mention, True))
        
        if reason:
            fields.append(("Reason", reason, False))
        
        if is_mass:
            fields.insert(1, ("⚠️ MASS CREATION", f"{mass_count} webhooks created in last minute", False))
        
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "CRITICAL" if is_mass or risk_score > 70 else "WARNING"
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity=severity,
            fields=fields,
            footer=f"Risk Score: {risk_score}/100 | Webhook ID: {webhook.id}",
            risk_score=risk_score,
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor) if executor else None

        extra_fields = [
            ("Webhook", webhook.name),
            ("Channel", f"#{webhook.channel.name}" if webhook.channel else "Unknown"),
            ("Risk Score", f"{risk_score}/100"),
        ]

        await self.logging_cog.send_image_log(
            channel_type="webhook",
            template_name="logging_card",
            severity=severity,
            embed_fallback=embed,
            filename="webhook_create.png",
            event_type="webhook_create",
            user=executor, perpetrator=executor,
            content=f"Webhook created: {webhook.name}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now())
        
        self.webhook_cache[webhook.id] = {
            "name": webhook.name,
            "channel_id": webhook.channel.id if webhook.channel else None,
            "created_at": datetime.now(),
            "creator": executor.id if executor else None,
            "risk_score": risk_score
        }
    
    async def log_bot_add(self, bot_member: discord.Member, executor: discord.User = None):
        """Log bot addition to server"""
        if not await self.should_log_security_events():
            return
        
        if not self.logging_cog:
            return
        
        self.bot_add_buffer[bot_member.guild.id].append((datetime.now(), executor, bot_member))
        
        is_mass, mass_count, bots_added = self.detect_bot_spam(bot_member.guild.id)
        
        dangerous_perms = []
        for perm, value in bot_member.guild_permissions:
            if value and perm in ["administrator", "manage_guild", "manage_channels", "manage_webhooks", "kick_members", "ban_members"]:
                dangerous_perms.append(perm)
        
        perm_dict = {perm: value for perm, value in bot_member.guild_permissions}
        has_dangerous_combo, combos = self.check_dangerous_permission_combo(perm_dict)
        
        risk_score = 0
        reasons = []
        
        if is_mass:
            risk_score += 50
            reasons.append(f"Mass bot addition detected ({mass_count} bots in 2 minutes)")
        
        if dangerous_perms:
            risk_score += 35
            reasons.append(f"Bot has dangerous permissions: {', '.join(dangerous_perms[:3])}")
        
        if has_dangerous_combo:
            risk_score += 20
            reasons.append(f"Dangerous permission combo: {', '.join(combos)}")
        
        bot_age = (datetime.now() - bot_member.created_at.replace(tzinfo=None)).days
        if bot_age < 7:
            risk_score += 15
            reasons.append(f"Bot account is only {bot_age} days old")
        
        risk_score = min(risk_score, 100)
        
        title = "🤖 Bot Added to Server"
        description = f"{self.get_emoji('add')} Bot added: {bot_member.mention}"
        
        fields = [
            ("Bot", f"{bot_member.mention}\n`{bot_member}`", True),
            ("Bot ID", f"`{bot_member.id}`", True),
            ("Bot Age", f"{bot_age} days", True)
        ]
        
        if executor:
            fields.insert(0, ("Added By", executor.mention, True))
        
        if dangerous_perms:
            fields.append(("⚠️ Dangerous Permissions", ", ".join(dangerous_perms), False))
        
        if has_dangerous_combo:
            fields.append(("⚠️ Dangerous Combo", "\n".join(combos), False))
        
        if is_mass:
            fields.insert(1, ("⚠️ MASS ADDITION", f"{mass_count} bots added recently\nBots: {', '.join(bots_added[:3])}", False))
        
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "CRITICAL" if risk_score > 70 else "WARNING" if risk_score > 30 else "INFO"
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity=severity,
            fields=fields,
            footer=f"Risk Score: {risk_score}/100 | Bot Permission Risk: {'HIGH' if risk_score > 50 else 'MEDIUM' if risk_score > 20 else 'LOW'}",
            risk_score=risk_score,
            perpetrator=executor
        )

        bot_avatar = await self._fetch_avatar(bot_member)

        extra_fields = [
            ("Bot", str(bot_member)),
            ("Bot Age", f"{bot_age} days"),
            ("Risk Score", f"{risk_score}/100"),
        ]
        if dangerous_perms:
            extra_fields.append(("Perms", ", ".join(dangerous_perms[:3])))

        await self.logging_cog.send_image_log(
            channel_type="security",
            template_name="logging_card",
            severity=severity,
            embed_fallback=embed,
            filename="bot_add.png",
            event_type="bot_add",
            user=bot_member,
            content=f"Bot added: {bot_member}",
            extra_fields=extra_fields,
            avatar_image=bot_avatar,
            timestamp=datetime.now())
    
    async def log_owner_transfer(self, guild: discord.Guild, new_owner: discord.User, old_owner: discord.User, executor: discord.User = None):
        """Log server ownership transfer"""
        if not await self.should_log_security_events():
            return
        
        if not self.logging_cog:
            return
        
        risk_score = 80
        reasons = ["Server ownership transfer - critical security event"]
        
        self.ownership_transfer_tracker[guild.id] = {
            "old_owner_id": old_owner.id,
            "new_owner_id": new_owner.id,
            "executor_id": executor.id if executor else None,
            "timestamp": datetime.now(),
            "risk_score": risk_score
        }
        
        title = "👑 SERVER OWNERSHIP TRANSFERRED"
        description = f"{self.get_emoji('warning')} **CRITICAL: Server ownership has been transferred!**"
        
        fields = [
            ("Old Owner", f"{old_owner.mention}\n`{old_owner}`", True),
            ("New Owner", f"{new_owner.mention}\n`{new_owner}`", True),
            ("Server", guild.name, True)
        ]
        
        if executor and executor.id != new_owner.id:
            fields.append(("Transferred By", f"{executor.mention}\n`{executor}`", True))
        
        fields.append(("⚠️ Security Alert", "This is a critical security event. Verify this transfer was legitimate.", False))
        fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity="CRITICAL",
            fields=fields,
            footer="⚠️ IMMEDIATE VERIFICATION REQUIRED ⚠️",
            risk_score=risk_score
        )

        extra_fields = [
            ("Old Owner", str(old_owner)),
            ("New Owner", str(new_owner)),
            ("Server", guild.name),
        ]

        await self.logging_cog.send_image_log(
            channel_type="security",
            template_name="logging_card",
            severity="CRITICAL",
            embed_fallback=embed,
            filename="owner_transfer.png",
            event_type="owner_transfer",
            user=new_owner,
            content=f"Server ownership transferred from {old_owner} to {new_owner}",
            extra_fields=extra_fields,
            timestamp=datetime.now(),
        )
    
    async def log_vanity_url_change(self, guild: discord.Guild, old_url: str, new_url: str, executor: discord.User = None):
        """Log vanity URL changes"""
        if not await self.should_log_security_events():
            return
        
        if not self.logging_cog:
            return
        
        self.vanity_url_history[guild.id].append((datetime.now(), old_url, new_url))
        
        risk_score = 40
        reasons = ["Vanity URL changed - potential impersonation risk"]
        
        title = "🔗 Vanity URL Changed"
        description = f"{self.get_emoji('settings')} Server vanity URL has been changed"
        
        fields = [
            ("Old URL", f"discord.gg/{old_url}" if old_url else "None", True),
            ("New URL", f"discord.gg/{new_url}" if new_url else "None", True),
            ("Server", guild.name, True)
        ]
        
        if executor:
            fields.insert(0, ("Changed By", executor.mention, True))
        
        fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity="WARNING",
            fields=fields,
            footer=f"Risk Score: {risk_score}/100",
            risk_score=risk_score,
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor) if executor else None

        extra_fields = [
            ("Old URL", f"discord.gg/{old_url}" if old_url else "None"),
            ("New URL", f"discord.gg/{new_url}" if new_url else "None"),
        ]

        await self.logging_cog.send_image_log(
            channel_type="security",
            template_name="logging_card",
            severity="WARNING",
            embed_fallback=embed,
            filename="vanity_url.png",
            event_type="vanity_url_change",
            user=executor, perpetrator=executor,
            content=f"Vanity URL changed: {old_url or 'None'} → {new_url or 'None'}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now(),
        )
    
    async def log_suspicious_admin_action(self, guild: discord.Guild, action: str, target: str, executor: discord.User, details: str = None):
        """Log suspicious admin actions"""
        if not await self.should_log_security_events():
            return
        
        if not self.logging_cog:
            return
        
        risk_score = 60
        reasons = [f"Suspicious admin action: {action}"]
        
        if details:
            reasons.append(details)
        
        self.suspicious_admin_actions[guild.id].append({
            "action": action,
            "target": target,
            "executor_id": executor.id,
            "timestamp": datetime.now(),
            "risk_score": risk_score
        })
        
        title = "⚠️ Suspicious Admin Action"
        description = f"{self.get_emoji('warning')} A potentially dangerous admin action was detected"
        
        fields = [
            ("Action", action, True),
            ("Target", target, True),
            ("Executor", executor.mention, True),
            ("Server", guild.name, True)
        ]
        
        if details:
            fields.append(("Details", details, False))
        
        fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity="CRITICAL",
            fields=fields,
            footer=f"Risk Score: {risk_score}/100 | Review immediately",
            risk_score=risk_score,
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor)

        extra_fields = [
            ("Action", action),
            ("Target", target),
            ("Server", guild.name),
        ]

        await self.logging_cog.send_image_log(
            channel_type="security",
            template_name="logging_card",
            severity="CRITICAL",
            embed_fallback=embed,
            filename="suspicious_admin.png",
            event_type="suspicious_admin",
            user=executor, perpetrator=executor,
            content=f"Suspicious admin action: {action} on {target}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now(),
        )
    
    @commands.Cog.listener()
    async def on_webhook_update(self, webhook: discord.Webhook):
        """Listener for webhook updates"""
        if not await self.should_log_security_events():
            return
        
        if not self.logging_cog:
            return
        
        executor = None
        
        try:
            async for entry in webhook.guild.audit_logs(limit=5, action=discord.AuditLogAction.webhook_update):
                if entry.target.id == webhook.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    executor = entry.user
                    break
        except Exception:
            pass
        
        title = "Webhook Updated"
        description = f"{self.get_emoji('settings')} Webhook was updated: {webhook.name}"
        
        fields = [
            ("Webhook", webhook.name, True),
            ("Webhook ID", f"`{webhook.id}`", True),
            ("Channel", webhook.channel.mention if webhook.channel else "Unknown", True)
        ]
        
        if executor:
            fields.insert(0, ("Updated By", executor.mention, True))
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity="WARNING",
            fields=fields,
            footer=f"Webhook ID: {webhook.id}",
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor) if executor else None

        extra_fields = [
            ("Webhook", webhook.name),
            ("Channel", f"#{webhook.channel.name}" if webhook.channel else "Unknown"),
        ]

        await self.logging_cog.send_image_log(
            channel_type="webhook",
            template_name="logging_card",
            severity="WARNING",
            embed_fallback=embed,
            filename="webhook_update.png",
            event_type="webhook_update",
            user=executor, perpetrator=executor,
            content=f"Webhook updated: {webhook.name}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now(),
        )
    
    @commands.command(name="raid-status")
    @commands.has_permissions(administrator=True)
    async def raid_status(self, ctx: commands.Context):
        """Check current raid detection status"""
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Logging system not ready")
            return
        
        probability, factors = self.calculate_raid_probability(ctx.guild.id)
        state = self.raid_detection_state.get(ctx.guild.id, {})
        
        embed = discord.Embed(
            title=f"{self.get_emoji('warning')} Raid Detection Status",
            color=0xe74c3c if probability > 70 else 0xf39c12 if probability > 50 else 0x3498db,
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Probability", value=f"{probability}%", inline=True)
        embed.add_field(name="Status", value="🚨 ACTIVE RAID" if state.get("active_raid") else "Normal", inline=True)
        embed.add_field(name="Raid Mode", value="⚠️ Enabled" if self.logging_cog.config.get("raid_mode", False) else "Disabled", inline=True)
        
        if factors:
            embed.add_field(name="Detection Factors", value="\n".join(factors[:5]), inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name="security-audit")
    @commands.has_permissions(administrator=True)
    async def security_audit(self, ctx: commands.Context):
        """Run a security audit on the server"""
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Logging system not ready")
            return
        
        embed = discord.Embed(
            title=f"{self.get_emoji('settings')} Security Audit Report",
            description=f"Security assessment for {ctx.guild.name}",
            color=0x3498db,
            timestamp=datetime.now()
        )
        
        admin_roles = [r for r in ctx.guild.roles if r.permissions.administrator and not r.is_default()]
        admin_members = [m for m in ctx.guild.members if m.guild_permissions.administrator and not m.bot]
        admin_bots = [m for m in ctx.guild.members if m.guild_permissions.administrator and m.bot]
        
        embed.add_field(name="Admin Roles", value=str(len(admin_roles)), inline=True)
        embed.add_field(name="Admin Members", value=str(len(admin_members)), inline=True)
        embed.add_field(name="Admin Bots", value=str(len(admin_bots)), inline=True)
        
        webhook_count = len(self.webhook_cache)
        embed.add_field(name="Tracked Webhooks", value=str(webhook_count), inline=True)
        
        suspicious_count = len(self.suspicious_admin_actions.get(ctx.guild.id, []))
        embed.add_field(name="Suspicious Actions", value=str(suspicious_count), inline=True)
        
        if admin_bots:
            bot_names = ", ".join([b.name for b in admin_bots[:5]])
            embed.add_field(name="⚠️ Admin Bots", value=bot_names, inline=False)
        
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    """Setup function for the cog"""
    cog = SecurityLogsCog(bot)
    await bot.add_cog(cog)
