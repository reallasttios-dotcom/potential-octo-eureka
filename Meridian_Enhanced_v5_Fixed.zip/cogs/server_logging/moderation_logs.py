import discord
from discord.ext import commands
from typing import Dict, List, Optional, Tuple, Any, Set, Union
from datetime import datetime, timedelta
from collections import defaultdict
import asyncio


class ModerationLogsCog(commands.Cog):
    """Handle bans, kicks, timeouts, and other moderation actions tracking"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logging_cog = None
        self.ban_cache: Dict[int, Dict[str, Any]] = {}
        self.kick_cache: Dict[int, Dict[str, Any]] = {}
        self.timeout_cache: Dict[int, Dict[str, Any]] = {}
        self.mass_action_buffer: Dict[int, List[Tuple[datetime, str, int]]] = defaultdict(list)
        self.mod_action_chain: Dict[int, List[Tuple[datetime, str, str]]] = defaultdict(list)
        self.action_fallbacks: Dict[int, Dict[str, Any]] = {}
        self.audit_retry_queue: List[Dict[str, Any]] = []
        
        self.suspicious_mod_patterns = {
            "ban_unban_chain": ["ban", "unban"],
            "kick_ban_chain": ["kick", "ban"],
            "mass_action": ["mass_ban", "mass_kick", "mass_timeout"]
        }
        
    async def cog_load(self):
        """Initialize cog and get reference to main logging cog"""
        await self.bot.wait_until_ready()
        self.logging_cog = self.bot.get_cog("LoggingCog")
        asyncio.create_task(self.audit_retry_loop())
        
    def get_emoji(self, key: str) -> str:
        """Get emoji from main logging cog"""
        if self.logging_cog and hasattr(self.logging_cog, 'get_emoji'):
            return self.logging_cog.get_emoji(key)
        return ""

    async def _fetch_avatar(self, user: discord.User) -> "Optional[Any]":
        """Fetch user avatar as PIL Image for imaging templates."""
        if not hasattr(self.bot, 'imaging'):
            return None
        try:
            avatar_bytes = await user.display_avatar.with_size(128).read()
            from PIL import Image
            import io
            return Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
        except Exception:
            return None
    
    async def should_log_moderation_events(self) -> bool:
        """Check if moderation events should be logged"""
        if not self.logging_cog:
            return True
        return self.logging_cog.config.is_category_enabled("moderation_logs")
    
    async def fetch_audit_log_with_retry(self, guild: discord.Guild, action: discord.AuditLogAction,
                                         target_id: int, max_retries: int = 3) -> Optional[discord.AuditLogEntry]:
        """Fetch audit log with retry mechanism"""
        for attempt in range(max_retries):
            try:
                async for entry in guild.audit_logs(limit=10, action=action):
                    if entry.target.id == target_id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 30:
                        return entry
                await asyncio.sleep(1)
            except discord.Forbidden:
                return None
            except Exception:
                if attempt == max_retries - 1:
                    self.audit_retry_queue.append({
                        "guild_id": guild.id, "action": action, "target_id": target_id, "attempts": 0, "timestamp": datetime.now()
                    })
                    return None
                await asyncio.sleep(0.5)
        return None
    
    async def audit_retry_loop(self):
        """Background task to retry failed audit log fetches"""
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            await asyncio.sleep(10)
            if not self.audit_retry_queue: continue
            to_remove = []
            for entry in self.audit_retry_queue:
                if (datetime.now() - entry["timestamp"]).total_seconds() > 300:
                    to_remove.append(entry)
                    continue
                guild = self.bot.get_guild(entry["guild_id"])
                if not guild:
                    to_remove.append(entry)
                    continue
                result = await self.fetch_audit_log_with_retry(guild, entry["action"], entry["target_id"], max_retries=1)
                if result:
                    await self.process_audit_entry(result, entry.get("callback_data"))
                    to_remove.append(entry)
                else:
                    entry["attempts"] += 1
                    if entry["attempts"] >= 5: to_remove.append(entry)
            for entry in to_remove:
                if entry in self.audit_retry_queue: self.audit_retry_queue.remove(entry)
    
    async def process_audit_entry(self, entry: discord.AuditLogEntry, callback_data: Dict = None):
        """Process a fetched audit log entry"""
        if entry.action == discord.AuditLogAction.ban:
            await self.log_ban(entry.guild, entry.target, entry.user, entry.reason, entry)
        elif entry.action == discord.AuditLogAction.unban:
            await self.log_unban(entry.target, entry.user, entry.reason, entry)
        elif entry.action == discord.AuditLogAction.kick:
            await self.log_kick(entry.guild, entry.target, entry.user, entry.reason, entry)
        elif entry.action == discord.AuditLogAction.member_timeout:
            await self.log_timeout(entry.target, entry.user, entry.reason, entry)
    
    def detect_mass_action(self, guild_id: int, action_type: str, target_id: int) -> Tuple[bool, int]:
        """Detect mass moderation actions (potential abuse)"""
        current_time = datetime.now()
        self.mass_action_buffer[guild_id] = [(t, atype, tid) for (t, atype, tid) in self.mass_action_buffer[guild_id] if (current_time - t).total_seconds() < 60]
        self.mass_action_buffer[guild_id].append((current_time, action_type, target_id))
        recent_actions = [a for a in self.mass_action_buffer[guild_id] if a[1] == action_type]
        if len(recent_actions) >= 5: return True, len(recent_actions)
        return False, 0
    
    async def log_ban(self, guild: discord.Guild, user: discord.User, moderator: Optional[discord.Member], reason: str = None, audit_entry: discord.AuditLogEntry = None):
        """Log member ban with confidence scoring"""
        if not await self.should_log_moderation_events(): return
        is_mass, mass_count = self.detect_mass_action(guild.id, "ban", user.id)
        confidence_score = 100 if audit_entry else 70 if moderator else 50
        fields = [("User", f"{user.mention}\n`{user.id}`", True)]
        if reason: fields.append(("Reason", reason, False))
        embed = await self.logging_cog.create_log_embed(
            title="Member Banned", description=f"{user.mention} was banned",
            severity="CRITICAL" if is_mass else "WARNING", fields=fields, perpetrator=moderator,
            footer=f"Confidence: {confidence_score}%"
        )
        await self.logging_cog.send_image_log(
            channel_type="moderation", template_name="moderation", severity="CRITICAL" if is_mass else "WARNING",
            embed_fallback=embed, filename="ban.png", action="ban", target=user, moderator=moderator or user,
            reason=reason or "No reason provided", timestamp=datetime.now()
        )

    async def log_unban(self, user: discord.User, moderator: Optional[discord.Member], reason: str = None, audit_entry: discord.AuditLogEntry = None):
        """Log member unban"""
        if not await self.should_log_moderation_events(): return
        confidence_score = 100 if audit_entry else 70 if moderator else 50
        embed = await self.logging_cog.create_log_embed(
            title="Member Unbanned", description=f"{user.mention} was unbanned",
            severity="INFO", fields=[("User", f"{user.mention}\n`{user.id}`", True)],
            perpetrator=moderator, footer=f"Confidence: {confidence_score}%"
        )
        await self.logging_cog.send_image_log(
            channel_type="moderation", template_name="moderation", severity="INFO",
            embed_fallback=embed, filename="unban.png", action="unban", target=user, moderator=moderator or user,
            reason=reason or "No reason provided", timestamp=datetime.now()
        )

    async def log_kick(self, guild: discord.Guild, user: discord.User, moderator: Optional[discord.Member], reason: str = None, audit_entry: discord.AuditLogEntry = None):
        """Log member kick"""
        if not await self.should_log_moderation_events(): return
        is_mass, mass_count = self.detect_mass_action(guild.id, "kick", user.id)
        confidence_score = 100 if audit_entry else 70 if moderator else 50
        embed = await self.logging_cog.create_log_embed(
            title="Member Kicked", description=f"{user.mention} was kicked",
            severity="WARNING", fields=[("User", f"{user.mention}\n`{user.id}`", True)],
            perpetrator=moderator, footer=f"Confidence: {confidence_score}%"
        )
        await self.logging_cog.send_image_log(
            channel_type="moderation", template_name="moderation", severity="WARNING",
            embed_fallback=embed, filename="kick.png", action="kick", target=user, moderator=moderator or user,
            reason=reason or "No reason provided", timestamp=datetime.now()
        )

    async def log_timeout(self, user: discord.Member, moderator: Optional[discord.Member], reason: str = None, audit_entry: discord.AuditLogEntry = None):
        """Log member timeout"""
        if not await self.should_log_moderation_events(): return
        confidence_score = 100 if audit_entry else 70 if moderator else 50
        embed = await self.logging_cog.create_log_embed(
            title="Member Timeout", description=f"{user.mention} was timed out",
            severity="WARNING", fields=[("User", f"{user.mention}\n`{user.id}`", True)],
            perpetrator=moderator, footer=f"Confidence: {confidence_score}%"
        )
        await self.logging_cog.send_image_log(
            channel_type="moderation", template_name="moderation", severity="WARNING",
            embed_fallback=embed, filename="timeout.png", action="timeout", target=user, moderator=moderator or user,
            reason=reason or "No reason provided", timestamp=datetime.now()
        )

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        audit_entry = await self.fetch_audit_log_with_retry(guild, discord.AuditLogAction.ban, user.id)
        await self.log_ban(guild, user, audit_entry.user if audit_entry else None, audit_entry.reason if audit_entry else None, audit_entry)

    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User):
        audit_entry = await self.fetch_audit_log_with_retry(guild, discord.AuditLogAction.unban, user.id)
        await self.log_unban(user, audit_entry.user if audit_entry else None, audit_entry.reason if audit_entry else None, audit_entry)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        if member.guild.me and member.guild.me.guild_permissions.view_audit_log:
            await asyncio.sleep(1)
            async for entry in member.guild.audit_logs(limit=5, action=discord.AuditLogAction.kick):
                if entry.target.id == member.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 5:
                    await self.log_kick(member.guild, member, entry.user, entry.reason, entry)
                    return

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        if before.timed_out_until != after.timed_out_until:
            if after.timed_out_until:
                audit_entry = await self.fetch_audit_log_with_retry(after.guild, discord.AuditLogAction.member_timeout, after.id)
                await self.log_timeout(after, audit_entry.user if audit_entry else None, audit_entry.reason if audit_entry else None, audit_entry)

async def setup(bot: commands.Bot):
    await bot.add_cog(ModerationLogsCog(bot))
