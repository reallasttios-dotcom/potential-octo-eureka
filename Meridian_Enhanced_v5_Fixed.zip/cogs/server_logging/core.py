import json
import asyncio
import discord
from discord.ext import commands
from typing import Dict, List, Optional, Tuple, Any, Set, Union
from datetime import datetime, timedelta
from pathlib import Path
import os

import sys
try:
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from emojihandler import EmojiManager
except ImportError:
    EmojiManager = None

class LoggingConfig:
    """Configuration manager for logging system"""
    
    def __init__(self, config_path: str = "config/logging_config.json"):
        self.config_path = config_path
        self.config = self.load_config()
        
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        default_config = {
            "enabled_categories": {
                "message_logs": True,
                "member_logs": True,
                "role_logs": True,
                "channel_logs": True,
                "moderation_logs": True,
                "security_logs": True,
                "voice_logs": True,
                "invite_logs": True,
                "poll_logs": True,
                "thread_logs": True
            },
            "channel_overrides": {},
            "min_severity": "INFO",
            "ignore_bots": True,
            "ignore_webhooks": True,
            "ignore_self": True,
            "embed_colors": {
                "INFO": 0x3498db,
                "WARNING": 0xf39c12,
                "CRITICAL": 0xe74c3c
            },
            "compact_mode": False,
            "verbose_mode": True,
            "collapse_role_changes": True,
            "merge_edit_window": 2,
            "cooldowns": {
                "message_edit": 1,
                "message_delete": 1,
                "member_join": 5,
                "member_leave": 5,
                "role_update": 2
            },
            "duplicate_suppression_window": 2,
            "burst_grouping_window": 5,
            "rate_limit_warnings": True,
            "raid_mode": False,
            "embed_mode": True,
            "timestamp_format": "relative",
            "short_ids": False,
            "compact_role_list": True,
            "expand_long_content": True,
            "clickable_user_cards": True,
            "color_coded_diffs": True,
            "use_emojis": True,
            "theme": "dark",
            "log_channels": {
                "server": None,
                "channel": None,
                "role": None,
                "member": None,
                "message": None,
                "moderation": None,
                "security": None,
                "voice": None,
                "invite": None,
                "poll": None
            },
            "export_format": "json",
            "auto_backup": True,
            "auto_rotation": "daily",
            "backup_path": "logs/backups/",
            "webhook_mirror": None,
            "use_sqlite": False,
            "db_path": "logs/logging.db",
            "auto_tag_suspicious": True,
            "auto_priority_highlights": True,
            "auto_thread_high_risk": False,
            "auto_pin_severe": True,
            "auto_role_notify": None,
            "auto_escalate_severity": True,
            "auto_collapse_noise": True,
            "ai_summary": False,
            "heatmap_enabled": False,
            "leaderboard_enabled": True,
            "anomaly_detection": True,
            "raid_probability": True,
            "mass_role_threshold": 10,
            "mass_channel_threshold": 5,
            "mass_permission_threshold": 8,
            "mass_webhook_threshold": 3,
            "rapid_join_threshold": 5,
            "rapid_join_window": 10
        }
        
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    loaded_config = json.load(f)
                    for key, value in default_config.items():
                        if key not in loaded_config:
                            loaded_config[key] = value
                    return loaded_config
            except Exception as e:
                print(f"Error loading config: {e}")
                return default_config
        return default_config
    
    def save_config(self):
        """Save configuration to file"""
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump(self.config, f, indent=4)
    
    def get(self, key: str, default=None):
        """Get config value by key"""
        keys = key.split('.')
        value = self.config
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k, default)
            else:
                return default
        return value
    
    def set(self, key: str, value: Any):
        """Set config value by key"""
        keys = key.split('.')
        config = self.config
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        config[keys[-1]] = value
        self.save_config()
    
    def is_category_enabled(self, category: str) -> bool:
        """Check if a logging category is enabled"""
        return self.config["enabled_categories"].get(category, True)
    
    def should_ignore_bot(self, user: Union[discord.User, discord.Member]) -> bool:
        """Check if a bot user should be ignored"""
        if not self.config["ignore_bots"]:
            return False
        return user.bot
    
    def should_ignore_webhook(self) -> bool:
        """Check if webhook messages should be ignored"""
        return self.config["ignore_webhooks"]
    
    def should_ignore_self(self, user_id: int, bot_user_id: int) -> bool:
        """Check if bot's own actions should be ignored"""
        if not self.config["ignore_self"]:
            return False
        return user_id == bot_user_id


class RiskScorer:
    """Risk scoring and behavior analysis system"""
    
    def __init__(self, config: LoggingConfig):
        self.config = config
        self.user_risk_scores: Dict[int, Dict[str, Any]] = {}
        self.risk_history: Dict[int, List[Dict[str, Any]]] = {}
        self.watchlist: Dict[int, Dict[str, Any]] = {}
        self.suspicious_patterns: Dict[int, List[str]] = {}
        
    def calculate_risk_score(self, action_type: str, details: Dict[str, Any], user: Optional[discord.Member] = None) -> Tuple[int, List[str]]:
        """Calculate risk score (0-100) and return reasons"""
        risk_score = 0
        reasons = []
        
        base_scores = {
            "member_join": 5,
            "role_assign_admin": 50,
            "role_assign_dangerous": 40,
            "channel_create": 15,
            "channel_delete": 20,
            "channel_create_mass": 35,
            "permission_change": 25,
            "permission_dangerous": 45,
            "webhook_create": 30,
            "webhook_create_mass": 60,
            "bot_add": 55,
            "owner_transfer": 100,
            "vanity_change": 40,
            "mass_ban": 70,
            "mass_kick": 65,
            "mass_role_assign": 45,
            "message_delete_mass": 30,
            "message_edit_mass": 20,
            "nickname_change": 5,
            "voice_join": 2,
            "voice_move": 5,
            "poll_create": 10,
            "poll_vote_mass": 30
        }
        
        risk_score += base_scores.get(action_type, 0)
        
        if user:
            account_age = (datetime.now() - user.created_at.replace(tzinfo=None)).days

            if account_age < 1:
                risk_score += 30
                reasons.append("Account created less than 24 hours ago")
            elif account_age < 7:
                risk_score += 15
                reasons.append("Account created less than 7 days ago")
            elif account_age < 30:
                risk_score += 5
                reasons.append("Account created less than 30 days ago")
            
            if not user.avatar:
                risk_score += 5
                reasons.append("No avatar set")
            
            suspicious_patterns = ["discord.gg", "free", "nitro", "steam", "gift"]
            if any(pattern in user.display_name.lower() for pattern in suspicious_patterns):
                risk_score += 15
                reasons.append("Suspicious username pattern detected")
        
        if action_type == "role_assign_admin":
            risk_score += 20
            reasons.append("Admin role assigned - high privilege escalation")
        
        if action_type == "role_assign_dangerous":
            risk_score += 15
            reasons.append("Dangerous permissions granted (Administrator, Manage Server)")
        
        if "mass" in action_type:
            risk_score += 20
            reasons.append("Mass action detected - potential raid behavior")
        
        if details.get("rapid", False):
            risk_score += 25
            reasons.append("Rapid successive actions detected")
        
        if details.get("chain", False):
            risk_score += 30
            reasons.append("Part of suspicious action chain")
        
        risk_score = min(risk_score, 100)
        
        if user and user.id:
            self.user_risk_scores[user.id] = {
                "score": risk_score,
                "last_action": action_type,
                "timestamp": datetime.now(),
                "reasons": reasons
            }
            
            if user.id not in self.risk_history:
                self.risk_history[user.id] = []
            self.risk_history[user.id].append({
                "score": risk_score,
                "action": action_type,
                "reasons": reasons,
                "timestamp": datetime.now()
            })
            
            if risk_score > 70:
                self.watchlist[user.id] = {
                    "score": risk_score,
                    "added_at": datetime.now(),
                    "reasons": reasons
                }
        
        return risk_score, reasons
    
    def get_risk_score(self, user_id: int) -> int:
        """Get current risk score for a user"""
        return self.user_risk_scores.get(user_id, {}).get("score", 0)
    
    def track_pattern(self, user_id: int, pattern: str):
        """Track suspicious behavioral patterns"""
        if user_id not in self.suspicious_patterns:
            self.suspicious_patterns[user_id] = []
        self.suspicious_patterns[user_id].append(pattern)

    def detect_chain(self, user_id: int, actions: List[str]) -> bool:
        """Detect suspicious action chains"""
        dangerous_chains = [
            ["member_join", "role_assign_admin", "channel_create_mass"],
            ["member_join", "role_assign_dangerous", "webhook_create_mass"],
            ["member_join", "message_delete_mass", "mass_kick"],
            ["role_assign_admin", "permission_dangerous", "mass_ban"]
        ]
        
        recent_actions = [h["action"] for h in self.risk_history.get(user_id, [])[-5:]]
        
        for chain in dangerous_chains:
            if all(action in recent_actions for action in chain):
                self.track_pattern(user_id, f"Suspicious chain detected: {' → '.join(chain)}")
                return True
        return False


class LoggingCog(commands.Cog):
    """Main logging system cog"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.config = LoggingConfig()
        self.risk_scorer = RiskScorer(self.config)
        self.emoji_handler: Optional[EmojiManager] = None
        self.event_cooldowns: Dict[str, Dict[int, datetime]] = {}
        self.burst_events: Dict[str, List[Dict]] = {}
        
        os.makedirs("logs", exist_ok=True)
        os.makedirs("logs/backups", exist_ok=True)
    
    async def cog_load(self):
        """Initialize cog – runs when the cog is loaded"""
        self.emoji_handler = self.bot.get_cog("EmojiManager")
        if not self.emoji_handler:
            print("Warning: EmojiManager not found! Emojis will be missing.")

    def get_emoji(self, key: str) -> str:
        """Get emoji from emoji handler"""
        if self.emoji_handler:
            return self.emoji_handler.get_ui_emoji(key)
        return ""
    
    def get_severity_emoji(self, severity: str) -> str:
        """Get emoji based on severity level"""
        emojis = {
            "INFO": self.get_emoji("info"),
            "WARNING": self.get_emoji("warning"),
            "CRITICAL": self.get_emoji("error")
        }
        return emojis.get(severity, "")
    
    def _get_log_channel(self, channel_type: str, severity: str = "INFO") -> Optional[discord.TextChannel]:
        """Resolve the target log channel after checking category/severity gates."""
        if not self.config.is_category_enabled(channel_type):
            return None

        severity_levels = {"INFO": 1, "WARNING": 2, "CRITICAL": 3}
        if severity_levels.get(severity, 1) < severity_levels.get(self.config.get("min_severity"), 1):
            return None

        channel_id = self.config.get(f"log_channels.{channel_type}")
        if not channel_id:
            return None

        return self.bot.get_channel(channel_id)

    async def send_log(self, channel_type: str, embed: discord.Embed, severity: str = "INFO"):
        """Send a log to the appropriate channel, trying imaging first with embed fallback"""
        channel = self._get_log_channel(channel_type, severity)
        if not channel:
            return

        if not self.config.get("embed_mode"):
            text = f"{embed.title}\n{embed.description}"
            for field in embed.fields:
                text += f"\n{field.name}: {field.value}"
            await channel.send(text[:2000])
            return

        if hasattr(self.bot, 'imaging'):
            try:
                sev_map = {"INFO": "info", "WARNING": "warning", "CRITICAL": "critical"}
                if severity in ("WARNING", "CRITICAL"):
                    fields_list = [(f.name, f.value) for f in embed.fields] if embed.fields else None
                    b = await self.bot.imaging.render("general",
                        card_type="alert",
                        alert_type=channel_type,
                        title=embed.title or "Log Entry",
                        description=embed.description or "",
                        fields=fields_list,
                        severity=sev_map.get(severity, "info"),
                    )
                else:
                    fields_list = [(f.name, f.value, f.inline) for f in embed.fields] if embed.fields else None
                    b = await self.bot.imaging.render("general",
                        card_type="info",
                        title=embed.title or "Log Entry",
                        description=embed.description or "",
                        fields=fields_list,
                        footer=embed.footer.text if embed.footer else None,
                    )
                f = self.bot.imaging.make_file(b, f"{channel_type}_log.png")
                await channel.send(file=f)
                return
            except Exception as exc:
                print(f"[Logging imaging] {exc}")

        await channel.send(embed=embed)

    async def send_image_log(
        self,
        channel_type: str,
        template_name: str,
        severity: str = "INFO",
        embed_fallback: Optional[discord.Embed] = None,
        filename: str = "log.png",
        **render_kwargs,
    ):
        """Render a dedicated imaging template and send it, falling back to embed."""
        channel = self._get_log_channel(channel_type, severity)
        if not channel:
            return

        if "severity" not in render_kwargs:
            render_kwargs["severity"] = severity

        if not self.config.get("embed_mode"):
            if embed_fallback:
                text = f"{embed_fallback.title}\n{embed_fallback.description}"
                for field in embed_fallback.fields:
                    text += f"\n{field.name}: {field.value}"
                await channel.send(text[:2000])
            return

        if hasattr(self.bot, 'imaging'):
            try:
                render_kwargs.setdefault("theme", self.config.get("theme", "dark"))
                return await self.bot.imaging.render_and_send(
                    ctx_or_channel=channel,
                    template_name=template_name,
                    filename=filename,
                    embed_title=embed_fallback.title if embed_fallback else f"Log: {template_name.replace('_', ' ').title()}",
                    embed_description=embed_fallback.description if embed_fallback else None,
                    embed_color=self.config.get(f"embed_colors.{severity}", 0x3498db),
                    embed_fields=[{"name": f.name, "value": f.value, "inline": f.inline} for f in embed_fallback.fields] if embed_fallback else None,
                    **render_kwargs
                )
            except Exception as exc:
                print(f"[Logging imaging/{template_name}] {exc}")

        if embed_fallback:
            await channel.send(embed=embed_fallback)

    def check_cooldown(self, event_type: str, key: str) -> bool:
        """Check if event is on cooldown"""
        cooldown_key = f"{event_type}:{key}"
        cooldown_time = self.config.get(f"cooldowns.{event_type}", 1)
        
        if cooldown_key not in self.event_cooldowns:
            self.event_cooldowns[cooldown_key] = {}
            return False
        
        last_trigger = self.event_cooldowns[cooldown_key].get(key)
        if not last_trigger:
            return False
        
        if (datetime.now() - last_trigger).total_seconds() < cooldown_time:
            return True
        
        self.event_cooldowns[cooldown_key][key] = datetime.now()
        return False
    
    def update_cooldown(self, event_type: str, key: str):
        """Update cooldown timestamp"""
        cooldown_key = f"{event_type}:{key}"
        if cooldown_key not in self.event_cooldowns:
            self.event_cooldowns[cooldown_key] = {}
        self.event_cooldowns[cooldown_key][key] = datetime.now()
    
    async def auto_generate_channels(self, guild: discord.Guild):
        """Auto-generate 10 log channels based on requirements"""
        try:
            await self.bot.wait_until_ready()
            bot_member = guild.get_member(self.bot.user.id) or await guild.fetch_member(self.bot.user.id)
            
            category_name = "📋 Logs"
            category = discord.utils.get(guild.categories, name=category_name)
            
            if not category:
                overwrites = {
                    guild.default_role: discord.PermissionOverwrite(view_channel=True, send_messages=False, connect=False),
                    bot_member: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_messages=True, manage_channels=True)
                }
                category = await guild.create_category(category_name, overwrites=overwrites)
            
            channels = {
                "server": {"name": "server-logs", "purpose": "General server events"},
                "channel": {"name": "channel-logs", "purpose": "Channel creation/deletion/updates"},
                "role": {"name": "role-logs", "purpose": "Role creation/deletion/updates"},
                "member": {"name": "member-logs", "purpose": "Member join/leave/nickname changes"},
                "message": {"name": "message-logs", "purpose": "Message edits and deletions"},
                "moderation": {"name": "moderation-logs", "purpose": "Bans, kicks, timeouts"},
                "security": {"name": "security-logs", "purpose": "Security events and alerts"},
                "voice": {"name": "voice-logs", "purpose": "Voice activity and session tracking"},
                "invite": {"name": "invite-logs", "purpose": "Invite creation and usage tracking"},
                "poll": {"name": "poll-logs", "purpose": "Poll creation and voting activity"}
            }
            
            for channel_key, channel_info in channels.items():
                channel_name = channel_info["name"]
                existing = discord.utils.get(category.channels, name=channel_name)
                
                if not existing:
                    channel_overwrites = {
                        guild.default_role: discord.PermissionOverwrite(view_channel=True, send_messages=False),
                        bot_member: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_messages=True, embed_links=True, attach_files=True)
                    }
                    channel = await guild.create_text_channel(
                        channel_name, category=category, overwrites=channel_overwrites,
                        topic=f"📋 {channel_info['purpose']} - Auto-created by logging system"
                    )
                    self.config.set(f"log_channels.{channel_key}", channel.id)
                else:
                    self.config.set(f"log_channels.{channel_key}", existing.id)
            
            self.config.save_config()
            return True
        except Exception as e:
            print(f"❌ Auto-generation error: {e}")
            return False

    @commands.group(name="logs")
    @commands.has_permissions(administrator=True)
    async def logs_group(self, ctx: commands.Context):
        """Main logging configuration command"""
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(title="📋 Logging System", description="Use `!logs <subcommand>` to manage settings", color=0x3498db)
            embed.add_field(name="Commands", value="`config`, `toggle`, `severity`, `mode`, `init`")
            await ctx.send(embed=embed)

    @logs_group.command(name="init")
    async def init_logs(self, ctx: commands.Context):
        """Initialize all 10 log channels automatically"""
        msg = await ctx.send("🔧 Initializing 10 log channels... Please wait.")
        if await self.auto_generate_channels(ctx.guild):
            await msg.edit(content="✅ Logging system initialized with 10 channels!")
        else:
            await msg.edit(content="❌ Failed to initialize log channels.")

    @logs_group.command(name="config")
    async def show_config(self, ctx: commands.Context):
        """Show current logging configuration"""
        embed = discord.Embed(title="📋 Logging Configuration", color=0x3498db)
        enabled = [cat for cat, en in self.config.config["enabled_categories"].items() if en]
        embed.add_field(name="Enabled Categories", value="\n".join(enabled) if enabled else "None")
        await ctx.send(embed=embed)

    async def create_log_embed(self, title: str, description: str, severity: str = "INFO",
                               fields: List[Tuple[str, str, bool]] = None,
                               footer: str = None, risk_score: int = 0,
                               perpetrator: Optional[Union[discord.Member, discord.User]] = None) -> discord.Embed:
        """Create a standardized log embed"""
        color = self.config.get("embed_colors", {}).get(severity, 0x3498db)
        embed = discord.Embed(title=f"{self.get_severity_emoji(severity)} {title}", description=description, color=color, timestamp=datetime.now())
        if perpetrator:
            embed.add_field(name="Executor", value=f"{perpetrator.mention} (`{perpetrator.id}`)", inline=False)
        if fields:
            for name, value, inline in fields:
                embed.add_field(name=name, value=value, inline=inline)
        footer_text = f"Severity: {severity}"
        if risk_score > 0: footer_text += f" | Risk Score: {risk_score}/100"
        if footer: footer_text += f" | {footer}"
        embed.set_footer(text=footer_text)
        return embed

async def setup(bot: commands.Bot):
    await bot.add_cog(LoggingCog(bot))
