import discord
from discord.ext import commands
import asyncio
import traceback
import importlib
import sys

async def setup(bot: commands.Bot):
    """Load logging cogs - core first, others in background"""

    try:
        if "cogs.server_logging.core" in sys.modules:
            importlib.reload(sys.modules["cogs.server_logging.core"])
        from cogs.server_logging.core import LoggingCog
        await bot.add_cog(LoggingCog(bot))
        print("✅ Loaded LoggingCog")
    except Exception as e:
        print(f"❌ Failed to load LoggingCog: {e}")
        traceback.print_exc()
        return

    async def load_remaining():
        await asyncio.sleep(2)
        logging_cog = bot.get_cog("LoggingCog")
        if not logging_cog:
            print("❌ LoggingCog not found! Cannot load subcogs.")
            return

        cogs_list = [
            ("cogs.server_logging.message_logs", "MessageLogsCog", "MessageLogsCog"),
            ("cogs.server_logging.member_logs", "MemberLogsCog", "MemberLogsCog"),
            ("cogs.server_logging.role_logs", "RoleLogsCog", "RoleLogsCog"),
            ("cogs.server_logging.channel_logs", "ChannelLogsCog", "ChannelLogsCog"),
            ("cogs.server_logging.moderation_logs", "ModerationLogsCog", "ModerationLogsCog"),
            ("cogs.server_logging.security_logs", "SecurityLogsCog", "SecurityLogsCog"),
            ("cogs.server_logging.voice_logs", "VoiceLogsCog", "VoiceLogsCog"),
            ("cogs.server_logging.intelligence", "IntelligenceCog", "IntelligenceCog"),
            ("cogs.server_logging.exporter", "ExporterCog", "ExporterCog")
        ]

        loaded_count = 0
        failed_count = 0

        for module_path, class_name, display_name in cogs_list:
            try:
                if module_path in sys.modules:
                    importlib.reload(sys.modules[module_path])
                    module = sys.modules[module_path]
                else:
                    module = importlib.import_module(module_path)
                cog_class = getattr(module, class_name)
                cog = cog_class(bot)
                cog.logging_cog = logging_cog
                await bot.add_cog(cog)
                loaded_count += 1
                print(f"✅ Loaded {display_name} (linked to LoggingCog)")
            except Exception as e:
                failed_count += 1
                print(f"❌ Failed to load {display_name}: {e}")
                traceback.print_exc()

        if failed_count > 0:
            print(f"📋 Logging system loaded: {loaded_count} succeeded, {failed_count} failed.")
        else:
            print(f"📋 Logging system fully loaded ({loaded_count} subcogs).")

    asyncio.create_task(load_remaining())
