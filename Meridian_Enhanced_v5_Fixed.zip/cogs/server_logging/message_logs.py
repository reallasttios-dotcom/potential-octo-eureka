import discord
from discord.ext import commands
from typing import Dict, List, Optional, Tuple, Any, Set, Union
from datetime import datetime, timedelta
import asyncio
from collections import defaultdict


class MessageLogsCog(commands.Cog):
    """Handle message edit and deletion tracking"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logging_cog = None
        self.message_cache: Dict[int, discord.Message] = {}
        self.edit_buffer: Dict[int, List[Tuple[datetime, str, str]]] = defaultdict(list)
        self.delete_buffer: Dict[int, List[Tuple[datetime, discord.Message]]] = defaultdict(list)
        self.rapid_edit_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.bulk_delete_cache: Dict[int, List[discord.Message]] = defaultdict(list)

    async def cog_load(self):
        await self.bot.wait_until_ready()
        self.logging_cog = self.bot.get_cog("LoggingCog")
        
    def get_emoji(self, key: str) -> str:
        if self.logging_cog and hasattr(self.logging_cog, 'get_emoji'):
            return self.logging_cog.get_emoji(key)
        return ""
    
    async def should_log_channel(self, channel: discord.TextChannel) -> bool:
        if not self.logging_cog:
            return True
        channel_overrides = self.logging_cog.config.get("channel_overrides", {})
        channel_config = channel_overrides.get(str(channel.id), {})
        if channel_config.get("message_logs") is False:
            return False
        return self.logging_cog.config.is_category_enabled("message_logs")
    
    async def get_message_snapshot(self, message: discord.Message) -> Dict[str, Any]:
        return {
            "content": message.content,
            "attachments": [a.url for a in message.attachments],
            "embeds": len(message.embeds),
            "timestamp": message.created_at,
            "channel_id": message.channel.id,
            "channel_name": message.channel.name,
            "author_id": message.author.id,
            "author_name": str(message.author),
            "author_avatar": message.author.display_avatar.url if message.author.avatar else None
        }
    
    async def format_message_content(self, content: str, max_length: int = 1000) -> str:
        if not content or content == "":
            return "*No content*"
        compact_mode = self.logging_cog and self.logging_cog.config.get("compact_mode", False)
        verbose_mode = self.logging_cog and self.logging_cog.config.get("verbose_mode", True)
        if compact_mode:
            content = content[:200] + "..." if len(content) > 200 else content
        elif verbose_mode and len(content) > max_length:
            content = f"||{content[:max_length]}...||"
        return content.replace("`", "'")

    async def _fetch_avatar(self, user: discord.User) -> "Optional[Any]":
        if not hasattr(self.bot, 'imaging'):
            return None
        try:
            avatar_bytes = await user.display_avatar.with_size(128).read()
            from PIL import Image
            import io
            return Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
        except Exception:
            return None

    async def _fetch_delete_executor(self, guild: discord.Guild, author: discord.User, channel: discord.TextChannel) -> Optional[discord.User]:
        """Look up the audit log to find who deleted a message (the perpetrator)."""
        try:
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.message_delete):
                if entry.target.id == author.id:
                    if hasattr(entry, 'extra') and hasattr(entry.extra, 'channel') and entry.extra.channel.id == channel.id:
                        if (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 15:
                            return entry.user
        except (discord.Forbidden, Exception):
            pass
        return None

    async def _fetch_bulk_delete_executor(self, guild: discord.Guild, channel: discord.TextChannel) -> Optional[discord.User]:
        """Look up audit log for bulk message deletion perpetrator."""
        try:
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.message_bulk_delete):
                if hasattr(entry, 'extra') and hasattr(entry.extra, 'channel') and entry.extra.channel.id == channel.id:
                    if (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 15:
                        return entry.user
        except (discord.Forbidden, Exception):
            pass
        return None
    
    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if not await self.should_log_channel(before.channel):
            return
        if self.logging_cog and self.logging_cog.config.should_ignore_bot(before.author):
            return
        if before.content == after.content:
            return
        if self.logging_cog:
            cooldown_key = f"message_edit:{before.author.id}"
            if self.logging_cog.check_cooldown("message_edit", cooldown_key):
                return
            self.logging_cog.update_cooldown("message_edit", cooldown_key)
        
        current_time = datetime.now()
        self.rapid_edit_tracker[before.author.id].append(current_time)
        self.rapid_edit_tracker[before.author.id] = [
            t for t in self.rapid_edit_tracker[before.author.id]
            if (current_time - t).total_seconds() < 5
        ]
        is_rapid = len(self.rapid_edit_tracker[before.author.id]) > 3
        
        merge_window = self.logging_cog.config.get("merge_edit_window", 2) if self.logging_cog else 2
        self.edit_buffer[before.id].append((current_time, before.content, after.content))
        self.edit_buffer[before.id] = [
            e for e in self.edit_buffer[before.id]
            if (current_time - e[0]).total_seconds() < merge_window
        ]
        
        await asyncio.sleep(merge_window)
        
        if len(self.edit_buffer[before.id]) > 1:
            first_edit = self.edit_buffer[before.id][0]
            last_edit = self.edit_buffer[before.id][-1]
            edit_count = len(self.edit_buffer[before.id])
            await self.log_merged_edits(before, after, first_edit[1], last_edit[2], edit_count, is_rapid)
        else:
            await self.log_message_edit(before, after, is_rapid)
        
        self.edit_buffer[before.id] = []
    
    async def log_message_edit(self, before: discord.Message, after: discord.Message, is_rapid: bool = False):
        if not self.logging_cog:
            return
        before_content = await self.format_message_content(before.content)
        after_content = await self.format_message_content(after.content)
        risk_score, reasons = self.logging_cog.risk_scorer.calculate_risk_score(
            "message_edit_mass" if is_rapid else "message_edit",
            {"rapid": is_rapid, "channel": before.channel.name},
            before.author
        )
        severity = "WARNING" if is_rapid else "INFO"
        title = "Message Edited"
        description = f"{self.get_emoji('comment')} Message edited by {before.author.mention}"
        fields = [
            ("Channel", before.channel.mention, True),
            ("Author", before.author.mention, True),
            ("Message ID", f"`{before.id}`", True),
            ("Before", f"```{before_content}```", False),
            ("After", f"```{after_content}```", False),
            ("Jump Link", f"[Click to view]({after.jump_url})", False)
        ]
        if is_rapid:
            fields.insert(0, ("⚠️ Warning", "Rapid successive edits detected!", False))
        if risk_score > 50 and reasons:
            fields.append(("Why Flagged?", "\n".join(reasons), False))
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity=severity,
            fields=fields, footer=f"User ID: {before.author.id}", risk_score=risk_score
        )

        avatar_img = await self._fetch_avatar(before.author)
        await self.logging_cog.send_image_log(
            channel_type="message", template_name="edit_tracking", severity=severity,
            embed_fallback=embed, filename="message_edit.png",
            before_content=before.content or "", after_content=after.content or "",
            user=before.author, channel=before.channel,
            avatar_image=avatar_img, timestamp=datetime.now(), jump_url=after.jump_url,
        )
    
    async def log_merged_edits(self, before: discord.Message, after: discord.Message, 
                               first_content: str, last_content: str, edit_count: int, is_rapid: bool):
        if not self.logging_cog:
            return
        first_fmt = await self.format_message_content(first_content)
        last_fmt = await self.format_message_content(last_content)
        risk_score, reasons = self.logging_cog.risk_scorer.calculate_risk_score(
            "message_edit_mass",
            {"rapid": is_rapid, "edit_count": edit_count, "channel": before.channel.name},
            before.author
        )
        severity = "WARNING"
        title = f"Multiple Message Edits ({edit_count} edits)"
        description = f"{self.get_emoji('comment')} Message edited {edit_count} times by {before.author.mention}"
        fields = [
            ("Channel", before.channel.mention, True),
            ("Author", before.author.mention, True),
            ("Message ID", f"`{before.id}`", True),
            ("First Version", f"```{first_fmt}```", False),
            ("Final Version", f"```{last_fmt}```", False),
            ("Jump Link", f"[Click to view]({after.jump_url})", False)
        ]
        if risk_score > 50 and reasons:
            fields.append(("Why Flagged?", "\n".join(reasons), False))
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity=severity, fields=fields,
            footer=f"User ID: {before.author.id} | {edit_count} edits in {self.logging_cog.config.get('merge_edit_window', 2)}s",
            risk_score=risk_score
        )

        avatar_img = await self._fetch_avatar(before.author)
        await self.logging_cog.send_image_log(
            channel_type="message", template_name="edit_tracking", severity=severity,
            embed_fallback=embed, filename="message_edit_merged.png",
            before_content=first_content or "", after_content=last_content or "",
            user=before.author, channel=before.channel,
            avatar_image=avatar_img, timestamp=datetime.now(), jump_url=after.jump_url,
        )
    
    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if not await self.should_log_channel(message.channel):
            return
        if self.logging_cog and self.logging_cog.config.should_ignore_bot(message.author):
            return
        if self.logging_cog:
            cooldown_key = f"message_delete:{message.channel.id}"
            if self.logging_cog.check_cooldown("message_delete", cooldown_key):
                return
            self.logging_cog.update_cooldown("message_delete", cooldown_key)
        
        current_time = datetime.now()
        self.delete_buffer[message.channel.id].append((current_time, message))
        self.delete_buffer[message.channel.id] = [
            d for d in self.delete_buffer[message.channel.id]
            if (current_time - d[0]).total_seconds() < 2
        ]
        
        if len(self.delete_buffer[message.channel.id]) > 3:
            await self.log_bulk_delete(message.channel, self.delete_buffer[message.channel.id])
            self.delete_buffer[message.channel.id] = []
        else:
            await self.log_message_delete(message)
    
    async def log_message_delete(self, message: discord.Message):
        if not self.logging_cog:
            return
        
        content = await self.format_message_content(message.content)

        executor = await self._fetch_delete_executor(message.guild, message.author, message.channel)
        deleted_by_other = executor is not None and executor.id != message.author.id
        
        risk_score, reasons = self.logging_cog.risk_scorer.calculate_risk_score(
            "message_delete", {"channel": message.channel.name}, message.author
        )

        severity = "WARNING" if risk_score > 30 or deleted_by_other else "INFO"
        
        title = "Message Deleted"
        if deleted_by_other:
            description = f"{self.get_emoji('unadd')} Message by {message.author.mention} was deleted by {executor.mention}"
        else:
            description = f"{self.get_emoji('unadd')} Message by {message.author.mention} was deleted"
        
        fields = [
            ("Channel", message.channel.mention, True),
            ("Author", message.author.mention, True),
            ("Message ID", f"`{message.id}`", True),
        ]

        if deleted_by_other:
            fields.insert(0, ("Deleted By", f"{executor.mention}\n`{executor}`", True))

        fields.append(("Content", f"```{content}```", False))
        
        if message.attachments:
            attachment_list = "\n".join([f"- {a.filename}" for a in message.attachments[:5]])
            if len(message.attachments) > 5:
                attachment_list += f"\n*... and {len(message.attachments) - 5} more*"
            fields.append(("Attachments", attachment_list, False))
        
        if risk_score > 50 and reasons:
            fields.append(("Why Flagged?", "\n".join(reasons), False))
        
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity=severity,
            fields=fields, footer=f"User ID: {message.author.id}", risk_score=risk_score,
            perpetrator=executor if deleted_by_other else None
        )

        avatar_img = await self._fetch_avatar(message.author)

        extra_fields = [("Channel", f"#{message.channel.name}"), ("Message ID", str(message.id))]
        if deleted_by_other:
            extra_fields.insert(0, ("Deleted By", str(executor)))
        if message.attachments:
            extra_fields.append(("Attachments", ", ".join(a.filename for a in message.attachments[:5])))

        await self.logging_cog.send_image_log(
            channel_type="message", template_name="logging_card",
            embed_fallback=embed, filename="message_delete.png",
            event_type="message_delete", user=message.author, channel=message.channel,
            content=message.content or None, extra_fields=extra_fields,
            severity=severity, perpetrator=executor,
            avatar_image=avatar_img, timestamp=datetime.now(),
        )
    
    async def log_purge_action(self, channel: discord.TextChannel, executor: discord.Member, count: int, target_user: Optional[discord.Member] = None, reason: Optional[str] = None):
        """Log a manual purge action from moderation commands."""
        if not self.logging_cog:
            return
        
        severity = "WARNING" if count < 50 else "CRITICAL"
        title = f"Manual Message Purge ({count} messages)"
        description = f"{self.get_emoji('warning')} {count} messages were purged in {channel.mention} by {executor.mention}"
        
        fields = [
            ("Channel", channel.mention, True),
            ("Purged By", executor.mention, True),
            ("Count", str(count), True)
        ]
        if target_user:
            fields.append(("Target User", target_user.mention, True))
        if reason:
            fields.append(("Reason", reason, False))
            
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity=severity,
            fields=fields, perpetrator=executor
        )
        
        extra_fields = [("Count", str(count))]
        if target_user:
            extra_fields.append(("Target", str(target_user)))
        if reason:
            extra_fields.append(("Reason", reason))
            
        await self.logging_cog.send_image_log(
            channel_type="message", template_name="logging_card", severity=severity,
            embed_fallback=embed, filename="manual_purge.png",
            event_type="message_delete", user=target_user or executor, perpetrator=executor,
            channel=channel, content=f"Purged {count} messages" + (f" from {target_user}" if target_user else ""),
            extra_fields=extra_fields, timestamp=datetime.now()
        )

    async def log_bulk_delete(self, channel: discord.TextChannel, deletions: List[Tuple[datetime, discord.Message]]):
        if not self.logging_cog:
            return
        
        delete_count = len(deletions)
        authors = defaultdict(int)
        for _, msg in deletions:
            authors[msg.author] += 1
        
        executor = await self._fetch_bulk_delete_executor(channel.guild, channel)
        
        author_summary = "\n".join([f"- {author.mention}: {count} messages" for author, count in list(authors.items())[:5]])
        if len(authors) > 5:
            author_summary += f"\n*... and {len(authors) - 5} more authors*"

        severity = "CRITICAL" if delete_count > 20 else "WARNING"
        
        title = f"Bulk Message Deletion ({delete_count} messages)"
        if executor:
            description = f"{self.get_emoji('warning')} {delete_count} messages were deleted in {channel.mention} by {executor.mention}"
        else:
            description = f"{self.get_emoji('warning')} {delete_count} messages were deleted in {channel.mention}"
        
        risk_score = min(30 + (delete_count // 10), 100)
        
        fields = [
            ("Channel", channel.mention, True),
            ("Time Window", f"Last {self.logging_cog.config.get('burst_grouping_window', 5)} seconds", True),
        ]

        if executor:
            fields.insert(0, ("Deleted By", f"{executor.mention}\n`{executor}`", True))

        fields.append(("Authors", author_summary, False))
        
        sample_messages = []
        for _, msg in deletions[:3]:
            if msg.content:
                sample_messages.append(f"**{msg.author}**: {msg.content[:100]}")
        if sample_messages:
            fields.append(("Sample Content", "\n".join(sample_messages), False))
        
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity=severity,
            fields=fields, footer=f"Total: {delete_count} messages deleted", risk_score=risk_score,
            perpetrator=executor
        )

        author_list = ", ".join(str(a) for a in list(authors.keys())[:5])
        extra_fields = [("Messages Deleted", str(delete_count)), ("Authors", author_list)]
        if executor:
            extra_fields.insert(0, ("Deleted By", str(executor)))

        await self.logging_cog.send_image_log(
            channel_type="message", template_name="logging_card",
            embed_fallback=embed, filename="bulk_delete.png",
            event_type="message_delete", channel=channel,
            content=f"{delete_count} messages bulk-deleted",
            extra_fields=extra_fields, severity_kwarg=severity, timestamp=datetime.now(),
        )
    
    @commands.Cog.listener()
    async def on_bulk_message_delete(self, messages: List[discord.Message]):
        if not messages:
            return
        channel = messages[0].channel
        if not await self.should_log_channel(channel):
            return
        
        delete_count = len(messages)
        authors = defaultdict(int)
        for msg in messages:
            if not (self.logging_cog and self.logging_cog.config.should_ignore_bot(msg.author)):
                authors[msg.author] += 1

        executor = await self._fetch_bulk_delete_executor(channel.guild, channel)

        severity = "CRITICAL"
        title = f"Bulk Message Purge ({delete_count} messages)"
        if executor:
            description = f"{self.get_emoji('warning')} {delete_count} messages were purged in {channel.mention} by {executor.mention}"
        else:
            description = f"{self.get_emoji('warning')} {delete_count} messages were purged in {channel.mention}"
        
        author_summary = "\n".join([f"- {author.mention}: {count}" for author, count in list(authors.items())[:5]])
        risk_score = min(50 + (delete_count // 5), 100)
        
        fields = [
            ("Channel", channel.mention, True),
            ("Total Messages", str(delete_count), True),
        ]
        if executor:
            fields.insert(0, ("Purged By", f"{executor.mention}\n`{executor}`", True))
        fields.append(("Affected Users", author_summary, False))
        
        if not self.logging_cog:
            return

        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity=severity,
            fields=fields, footer="⚠️ Potential raid or cleanup action", risk_score=risk_score,
            perpetrator=executor
        )

        extra_fields = [("Messages Purged", str(delete_count)), ("Affected Users", str(len(authors)))]
        if executor:
            extra_fields.insert(0, ("Purged By", str(executor)))

        await self.logging_cog.send_image_log(
            channel_type="message", template_name="logging_card",
            embed_fallback=embed, filename="bulk_purge.png",
            event_type="message_delete", channel=channel,
            content=f"{delete_count} messages purged — potential raid or cleanup",
            extra_fields=extra_fields, severity_kwarg=severity, timestamp=datetime.now(),
        )
    
    @commands.Cog.listener()
    async def on_raw_message_delete(self, payload: discord.RawMessageDeleteEvent):
        if payload.cached_message:
            return
        if not self.logging_cog:
            return
        channel = self.bot.get_channel(payload.channel_id)
        if not channel:
            return
        if not await self.should_log_channel(channel):
            return
        
        executor = None
        if hasattr(channel, 'guild') and channel.guild:
            try:
                async for entry in channel.guild.audit_logs(limit=5, action=discord.AuditLogAction.message_delete):
                    if hasattr(entry, 'extra') and hasattr(entry.extra, 'channel') and entry.extra.channel.id == channel.id:
                        if (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 15:
                            executor = entry.user
                            break
            except (discord.Forbidden, Exception):
                pass

        title = "Message Deleted (Uncached)"
        if executor:
            description = f"{self.get_emoji('unadd')} A message was deleted by {executor.mention} but content was not in cache"
        else:
            description = f"{self.get_emoji('unadd')} A message was deleted but not found in cache"
        
        fields = [
            ("Channel", channel.mention, True),
            ("Message ID", f"`{payload.message_id}`", True)
        ]
        if executor:
            fields.insert(0, ("Deleted By", f"{executor.mention}\n`{executor}`", True))
        
        embed = await self.logging_cog.create_log_embed(
            title=title, description=description, severity="INFO",
            fields=fields, footer="Message content could not be retrieved",
            perpetrator=executor
        )

        extra_fields = [("Message ID", str(payload.message_id))]
        if executor:
            extra_fields.insert(0, ("Deleted By", str(executor)))

        await self.logging_cog.send_image_log(
            channel_type="message", template_name="logging_card", severity="INFO",
            embed_fallback=embed, filename="message_delete_uncached.png",
            event_type="message_delete", channel=channel,
            content="Message deleted (content unavailable — not in cache)",
            extra_fields=extra_fields, timestamp=datetime.now(),
        )
    
    @commands.command(name="message-stats")
    @commands.has_permissions(manage_messages=True)
    async def message_stats(self, ctx: commands.Context, user: discord.User = None):
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Logging system not ready")
            return
        target = user or ctx.author
        risk_history = self.logging_cog.risk_scorer.risk_history.get(target.id, [])
        edit_actions = [h for h in risk_history if "edit" in h.get("action", "")]
        delete_actions = [h for h in risk_history if "delete" in h.get("action", "")]
        embed = discord.Embed(
            title=f"{self.get_emoji('comment')} Message Statistics for {target.display_name}",
            color=0x3498db, timestamp=datetime.now()
        )
        embed.add_field(name="Total Edits", value=str(len(edit_actions)), inline=True)
        embed.add_field(name="Total Deletions", value=str(len(delete_actions)), inline=True)
        embed.add_field(name="Risk Score", value=f"{self.logging_cog.risk_scorer.get_risk_score(target.id)}/100", inline=True)
        if edit_actions[-5:]:
            recent = "\n".join([f"- {h['timestamp'].strftime('%H:%M:%S')}" for h in edit_actions[-5:]])
            embed.add_field(name="Recent Edits", value=recent, inline=False)
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    cog = MessageLogsCog(bot)
    await bot.add_cog(cog)
