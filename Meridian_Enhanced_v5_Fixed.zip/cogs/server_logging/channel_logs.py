import discord
from discord.ext import commands
from typing import Dict, List, Optional, Tuple, Any, Set, Union
from datetime import datetime, timedelta
from collections import defaultdict
import asyncio


class ChannelLogsCog(commands.Cog):
    """Handle channel creation/deletion/edits and permission overwrite tracking"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logging_cog = None
        self.channel_snapshots: Dict[int, Dict[str, Any]] = {}
        self.channel_creation_buffer: Dict[int, List[datetime]] = defaultdict(list)
        self.channel_deletion_buffer: Dict[int, List[datetime]] = defaultdict(list)
        self.permission_overwrite_history: Dict[int, List[Tuple[datetime, str, Dict[str, bool], Dict[str, bool]]]] = defaultdict(list)
        self.dangerous_overwrites: Dict[int, List[Tuple[datetime, discord.TextChannel, discord.Role, List[str]]]] = defaultdict(list)

        self.dangerous_overwrite_perms = {
            "administrator": "Administrator",
            "manage_channels": "Manage Channels",
            "manage_webhooks": "Manage Webhooks",
            "manage_messages": "Manage Messages",
            "mention_everyone": "Mention @everyone",
            "kick_members": "Kick Members",
            "ban_members": "Ban Members",
            "manage_roles": "Manage Roles"
        }
        
    async def cog_load(self):
        """Initialize cog and get reference to main logging cog"""
        await self.bot.wait_until_ready()
        self.logging_cog = self.bot.get_cog("LoggingCog")
        
    def get_emoji(self, key: str) -> str:
        """Get emoji from main logging cog"""
        if self.logging_cog and hasattr(self.logging_cog, 'get_emoji'):
            return self.logging_cog.get_emoji(key)
        return ""

    async def _fetch_avatar(self, user: discord.User) -> "Optional[Any]":
        """Fetch user avatar as PIL Image for imaging templates."""
        if not hasattr(self.bot, 'imaging'):
            return None
        try:
            avatar_bytes = await user.display_avatar.with_size(128).read()
            from PIL import Image
            import io
            return Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
        except Exception:
            return None
    
    async def should_log_channel_events(self) -> bool:
        """Check if channel events should be logged"""
        if not self.logging_cog:
            return True
        return self.logging_cog.config.is_category_enabled("channel_logs")
    
    def get_channel_snapshot(self, channel: Union[discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel]) -> Dict[str, Any]:
        """Get snapshot of channel data"""
        snapshot = {
            "name": channel.name,
            "type": str(channel.type),
            "position": channel.position,
            "created_at": datetime.now()
        }
    
        if isinstance(channel, discord.TextChannel):
            snapshot.update({
                "topic": channel.topic,
                "slowmode_delay": channel.slowmode_delay,
                "is_nsfw": channel.is_nsfw(),
            })
        elif isinstance(channel, discord.VoiceChannel):
            snapshot.update({
                "bitrate": channel.bitrate,
                "user_limit": channel.user_limit
            })
    
        return snapshot
    
    def get_channel_permissions_snapshot(self, permissions: discord.PermissionOverwrite) -> Dict[str, bool]:
        """Get snapshot of channel permission overwrites"""
        if not permissions:
            return {}
        
        return {
            "administrator": getattr(permissions, "administrator", False),
            "manage_channels": getattr(permissions, "manage_channels", False),
            "manage_webhooks": getattr(permissions, "manage_webhooks", False),
            "manage_messages": getattr(permissions, "manage_messages", False),
            "mention_everyone": getattr(permissions, "mention_everyone", False),
            "kick_members": getattr(permissions, "kick_members", False),
            "ban_members": getattr(permissions, "ban_members", False),
            "manage_roles": getattr(permissions, "manage_roles", False),
            "view_channel": getattr(permissions, "view_channel", False),
            "send_messages": getattr(permissions, "send_messages", False),
            "read_messages": getattr(permissions, "read_messages", False)
        }
    
    def get_dangerous_overwrites(self, overwrites: Dict[str, bool]) -> List[str]:
        """Get list of dangerous permission overwrites"""
        dangerous = []
        for perm_key, perm_name in self.dangerous_overwrite_perms.items():
            if overwrites.get(perm_key, False):
                dangerous.append(perm_name)
        return dangerous
    
    def detect_mass_channel_creation(self, guild_id: int, channel_type: str) -> Tuple[bool, int]:
        """Detect mass channel creation (potential nuke)"""
        current_time = datetime.now()
        
        self.channel_creation_buffer[guild_id] = [
            t for t in self.channel_creation_buffer[guild_id]
            if (current_time - t).total_seconds() < 30
        ]
        
        self.channel_creation_buffer[guild_id].append(current_time)
        
        threshold = self.logging_cog.config.get("mass_channel_threshold", 5) if self.logging_cog else 5
        
        if len(self.channel_creation_buffer[guild_id]) >= threshold:
            return True, len(self.channel_creation_buffer[guild_id])
        
        return False, 0
    
    def detect_mass_channel_deletion(self, guild_id: int) -> Tuple[bool, int]:
        """Detect mass channel deletion (potential nuke)"""
        current_time = datetime.now()
        
        self.channel_deletion_buffer[guild_id] = [
            t for t in self.channel_deletion_buffer[guild_id]
            if (current_time - t).total_seconds() < 30
        ]
        
        self.channel_deletion_buffer[guild_id].append(current_time)
        
        threshold = self.logging_cog.config.get("mass_channel_threshold", 5) if self.logging_cog else 5
        
        if len(self.channel_deletion_buffer[guild_id]) >= threshold:
            return True, len(self.channel_deletion_buffer[guild_id])
        
        return False, 0
    
    async def log_channel_create(self, channel: Union[discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel]):
        """Log channel creation"""
        if not self.logging_cog:
            return
        if not await self.should_log_channel_events():
            return
        
        executor = None
        reason = None
        
        try:
            async for entry in channel.guild.audit_logs(limit=5, action=discord.AuditLogAction.channel_create):
                if entry.target.id == channel.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    executor = entry.user
                    reason = entry.reason
                    break
        except Exception:
            pass
        
        is_mass, mass_count = self.detect_mass_channel_creation(channel.guild.id, str(channel.type))
        
        risk_score = 0
        reasons = []
        
        if is_mass:
            risk_score += 40
            reasons.append(f"Mass channel creation detected ({mass_count} channels in 30 seconds)")
        
        if isinstance(channel, discord.TextChannel) and channel.is_nsfw():
            risk_score += 10
            reasons.append("NSFW channel created")
        
        if isinstance(channel, discord.TextChannel) and channel.topic and any(word in channel.topic.lower() for word in ["free", "giveaway", "nitro", "crypto"]):
            risk_score += 15
            reasons.append("Channel topic contains suspicious keywords")
        
        risk_score = min(risk_score, 100)
        
        channel_type_emoji = {
            "text": self.get_emoji("comment"),
            "voice": self.get_emoji("mic"),
            "category": self.get_emoji("list")
        }.get(str(channel.type), self.get_emoji("channel"))
        
        title = "Channel Created"
        description = f"{channel_type_emoji} New {channel.type} channel created: {channel.mention if isinstance(channel, discord.TextChannel) else channel.name}"
        
        fields = [
            ("Channel Name", channel.name, True),
            ("Channel ID", f"`{channel.id}`", True),
            ("Channel Type", str(channel.type).capitalize(), True)
        ]
        
        if isinstance(channel, discord.TextChannel):
            fields.append(("Topic", channel.topic or "No topic", False))
            fields.append(("NSFW", "Yes" if channel.is_nsfw() else "No", True))
            fields.append(("Slowmode", f"{channel.slowmode_delay}s" if channel.slowmode_delay else "Disabled", True))
        elif isinstance(channel, discord.VoiceChannel):
            fields.append(("Bitrate", f"{channel.bitrate // 1000}kbps", True))
            fields.append(("User Limit", str(channel.user_limit) if channel.user_limit else "Unlimited", True))
        
        if executor:
            fields.insert(0, ("Created By", executor.mention, True))
        
        if reason:
            fields.append(("Reason", reason, False))
        
        if is_mass:
            fields.insert(1, ("⚠️ Mass Creation Alert", f"{mass_count} channels created in last 30 seconds", False))
        
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "CRITICAL" if is_mass else "WARNING" if risk_score > 30 else "INFO"
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity=severity,
            fields=fields,
            footer=f"Risk Score: {risk_score}/100",
            risk_score=risk_score,
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor) if executor else None

        extra_fields = [
            ("Channel", channel.name),
            ("Type", str(channel.type).capitalize()),
            ("Risk Score", f"{risk_score}/100"),
        ]

        await self.logging_cog.send_image_log(
            channel_type="channel",
            template_name="logging_card",
            severity=severity,
            embed_fallback=embed,
            filename="channel_create.png",
            event_type="channel_create",
            user=executor, perpetrator=executor,
            content=f"New {channel.type} channel created: #{channel.name}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now())
        
        self.channel_snapshots[channel.id] = self.get_channel_snapshot(channel)
    
    async def log_channel_delete(self, channel: Union[discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel]):
        """Log channel deletion with snapshot"""
        if not self.logging_cog:
            return
        if not await self.should_log_channel_events():
            return
        
        executor = None
        reason = None
        
        try:
            async for entry in channel.guild.audit_logs(limit=5, action=discord.AuditLogAction.channel_delete):
                if entry.target.id == channel.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    executor = entry.user
                    reason = entry.reason
                    break
        except Exception:
            pass
        
        is_mass, mass_count = self.detect_mass_channel_deletion(channel.guild.id)
        
        snapshot = self.channel_snapshots.get(channel.id, {})
        
        risk_score = 0
        reasons = []
        
        if is_mass:
            risk_score += 50
            reasons.append(f"Mass channel deletion detected ({mass_count} channels in 30 seconds)")
        
        if isinstance(channel, discord.TextChannel):
            if channel.is_news():
                risk_score += 15
                reasons.append("Announcement channel deleted")
            if "admin" in channel.name.lower() or "mod" in channel.name.lower():
                risk_score += 20
                reasons.append("Important admin/moderation channel deleted")
        
        risk_score = min(risk_score, 100)
        
        title = "Channel Deleted"
        description = f"{self.get_emoji('unadd')} {channel.type} channel deleted: `{channel.name}`"
        
        fields = [
            ("Channel Name", channel.name, True),
            ("Channel ID", f"`{channel.id}`", True),
            ("Channel Type", str(channel.type).capitalize(), True)
        ]
        
        if isinstance(channel, discord.TextChannel) and snapshot.get("topic"):
            fields.append(("Previous Topic", snapshot.get("topic", "Unknown")[:500], False))
        
        if executor:
            fields.insert(0, ("Deleted By", executor.mention, True))
        
        if reason:
            fields.append(("Reason", reason, False))
        
        if is_mass:
            fields.insert(1, ("⚠️ Mass Deletion Alert", f"{mass_count} channels deleted in last 30 seconds", False))
        
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "CRITICAL" if is_mass or risk_score > 70 else "WARNING" if risk_score > 30 else "INFO"
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity=severity,
            fields=fields,
            footer=f"Risk Score: {risk_score}/100",
            risk_score=risk_score,
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor) if executor else None

        extra_fields = [
            ("Channel", channel.name),
            ("Type", str(channel.type).capitalize()),
            ("Risk Score", f"{risk_score}/100"),
        ]

        await self.logging_cog.send_image_log(
            channel_type="channel",
            template_name="logging_card",
            severity=severity,
            embed_fallback=embed,
            filename="channel_delete.png",
            event_type="channel_delete",
            user=executor, perpetrator=executor,
            content=f"{channel.type} channel deleted: #{channel.name}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now())
        
        if channel.id in self.channel_snapshots:
            del self.channel_snapshots[channel.id]
    
    async def log_channel_update(self, before: Union[discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel], 
                                 after: Union[discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel]):
        """Log channel updates"""
        if not self.logging_cog:
            return
        if not await self.should_log_channel_events():
            return
        
        changes = []
        
        if before.name != after.name:
            changes.append(f"**Name:** `{before.name}` → `{after.name}`")
        
        if before.position != after.position:
            changes.append(f"**Position:** {before.position} → {after.position}")
        
        if isinstance(before, discord.TextChannel) and isinstance(after, discord.TextChannel):
            if before.topic != after.topic:
                changes.append(f"**Topic:** {before.topic[:100] if before.topic else 'None'} → {after.topic[:100] if after.topic else 'None'}")
            
            if before.slowmode_delay != after.slowmode_delay:
                changes.append(f"**Slowmode:** {before.slowmode_delay}s → {after.slowmode_delay}s")
            
            if before.is_nsfw() != after.is_nsfw():
                changes.append(f"**NSFW:** {'Enabled' if after.is_nsfw() else 'Disabled'}")
        
        elif isinstance(before, discord.VoiceChannel) and isinstance(after, discord.VoiceChannel):
            if before.bitrate != after.bitrate:
                changes.append(f"**Bitrate:** {before.bitrate // 1000}kbps → {after.bitrate // 1000}kbps")
            
            if before.user_limit != after.user_limit:
                changes.append(f"**User Limit:** {before.user_limit if before.user_limit else 'Unlimited'} → {after.user_limit if after.user_limit else 'Unlimited'}")
        
        if not changes:
            return
        
        executor = None
        reason = None
        
        try:
            async for entry in before.guild.audit_logs(limit=5, action=discord.AuditLogAction.channel_update):
                if entry.target.id == before.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    executor = entry.user
                    reason = entry.reason
                    break
        except Exception:
            pass
        
        risk_score = 0
        reasons = []
        
        suspicious_names = ["everyone", "here", "discord", "support", "admin", "mod", "nsfw"]
        if after.name.lower() in suspicious_names:
            risk_score += 15
            reasons.append(f"Channel renamed to suspicious name: '{after.name}'")
        
        if isinstance(after, discord.TextChannel) and after.is_nsfw() and not before.is_nsfw():
            risk_score += 10
            reasons.append("Channel changed to NSFW")
        
        risk_score = min(risk_score, 100)
        
        title = "Channel Updated"
        description = f"{self.get_emoji('settings')} Channel updated: {after.mention if isinstance(after, discord.TextChannel) else after.name}"
        
        fields = [
            ("Channel", after.mention if isinstance(after, discord.TextChannel) else after.name, True),
            ("Channel ID", f"`{after.id}`", True),
            ("Changes", "\n".join(changes[:5]), False)
        ]
        
        if executor:
            fields.insert(0, ("Updated By", executor.mention, True))
        
        if reason:
            fields.append(("Reason", reason, False))
        
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "WARNING" if risk_score > 30 else "INFO"
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity=severity,
            fields=fields,
            footer=f"Risk Score: {risk_score}/100",
            risk_score=risk_score,
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor) if executor else None

        changes_text = "; ".join(c.replace("**", "").replace("`", "") for c in changes[:3])
        extra_fields = [
            ("Channel", after.name),
            ("Changes", changes_text[:80]),
        ]

        await self.logging_cog.send_image_log(
            channel_type="channel",
            template_name="logging_card",
            severity=severity,
            embed_fallback=embed,
            filename="channel_update.png",
            event_type="channel_update",
            user=executor, perpetrator=executor,
            content=f"Channel updated: #{after.name}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now())
        
        self.channel_snapshots[after.id] = self.get_channel_snapshot(after)
    
    async def log_permission_overwrite(self, channel: discord.TextChannel, target: Union[discord.Role, discord.Member],
                                       before: discord.PermissionOverwrite, after: discord.PermissionOverwrite):
        """Log permission overwrite changes"""
        if not self.logging_cog:
            return
        if not await self.should_log_channel_events():
            return
        
        before_perms = self.get_channel_permissions_snapshot(before)
        after_perms = self.get_channel_permissions_snapshot(after)
        
        changes = []
        dangerous_changes = []
        
        for perm_key, perm_name in self.dangerous_overwrite_perms.items():
            before_val = before_perms.get(perm_key, False)
            after_val = after_perms.get(perm_key, False)
            
            if before_val != after_val:
                change_text = f"{'+' if after_val else '-'} {perm_name}"
                changes.append(change_text)
                
                if after_val and not before_val:
                    dangerous_changes.append(perm_name)
        
        if not changes:
            return
        
        executor = None
        
        try:
            async for entry in channel.guild.audit_logs(limit=5, action=discord.AuditLogAction.channel_overwrite_update):
                if entry.target.id == channel.id and (datetime.now() - entry.created_at.replace(tzinfo=None)).total_seconds() < 10:
                    executor = entry.user
                    break
        except Exception:
            pass
        
        risk_score = 0
        reasons = []
        
        if dangerous_changes:
            risk_score += 40
            reasons.append(f"Dangerous permissions granted: {', '.join(dangerous_changes)}")
        
        if isinstance(target, discord.Role) and target.is_default():
            risk_score += 25
            reasons.append("Permission changes applied to @everyone role")
        
        risk_score = min(risk_score, 100)
        
        target_type = "Role" if isinstance(target, discord.Role) else "Member"
        target_name = target.mention
        
        title = "Permission Override Changed"
        description = f"{self.get_emoji('settings')} Permission override changed in {channel.mention}"
        
        fields = [
            ("Channel", channel.mention, True),
            (f"{target_type}", target_name, True),
            ("Changes", "\n".join(changes), False)
        ]
        
        if executor:
            fields.insert(0, ("Changed By", executor.mention, True))
        
        if dangerous_changes:
            fields.append(("⚠️ Dangerous Changes", ", ".join(dangerous_changes), False))
        
        if risk_score > 50 and reasons:
            fields.append(("❓ Why Flagged?", "\n".join(reasons), False))
        
        severity = "CRITICAL" if risk_score > 70 else "WARNING" if risk_score > 30 else "INFO"
        
        embed = await self.logging_cog.create_log_embed(
            title=title,
            description=description,
            severity=severity,
            fields=fields,
            footer=f"Risk Score: {risk_score}/100 | Target: {target_type}",
            risk_score=risk_score,
            perpetrator=executor
        )

        executor_avatar = await self._fetch_avatar(executor) if executor else None

        target_str = str(target) if isinstance(target, discord.Member) else target.name
        extra_fields = [
            ("Channel", f"#{channel.name}"),
            (target_type, target_str),
            ("Changes", "; ".join(changes[:3])),
        ]

        await self.logging_cog.send_image_log(
            channel_type="permission",
            template_name="logging_card",
            severity=severity,
            embed_fallback=embed,
            filename="permission_override.png",
            event_type="permission_override",
            user=executor, perpetrator=executor,
            content=f"Permission override changed in #{channel.name} for {target_str}",
            extra_fields=extra_fields,
            avatar_image=executor_avatar,
            timestamp=datetime.now())
        
        self.permission_overwrite_history[channel.id].append((datetime.now(), str(target), before_perms, after_perms))
    
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: Union[discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel]):
        """Listener for channel creation"""
        await self.log_channel_create(channel)
    
    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: Union[discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel]):
        """Listener for channel deletion"""
        await self.log_channel_delete(channel)
    
    @commands.Cog.listener()
    async def on_guild_channel_update(self, before: Union[discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel], 
                                      after: Union[discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel]):
        """Listener for channel updates"""
        await self.log_channel_update(before, after)
        
        if isinstance(before, discord.TextChannel) and isinstance(after, discord.TextChannel):
            before_overwrites = before.overwrites
            after_overwrites = after.overwrites
            
            all_targets = set(before_overwrites.keys()) | set(after_overwrites.keys())
            
            for target in all_targets:
                before_ow = before_overwrites.get(target)
                after_ow = after_overwrites.get(target)
                
                if before_ow != after_ow:
                    await self.log_permission_overwrite(after, target, before_ow, after_ow)
    
    @commands.command(name="channel-snapshot")
    @commands.has_permissions(manage_channels=True)
    async def channel_snapshot(self, ctx: commands.Context, channel: discord.TextChannel = None):
        """Take a snapshot of current channel configuration"""
        if not self.logging_cog:
            await ctx.send(f"{self.get_emoji('error')} Logging system not ready")
            return
        
        target = channel or ctx.channel
        
        embed = discord.Embed(
            title=f"{self.get_emoji('channel')} Channel Snapshot: #{target.name}",
            color=0x3498db,
            timestamp=datetime.now()
        )
        
        embed.add_field(name="Channel ID", value=f"`{target.id}`", inline=True)
        embed.add_field(name="Category", value=target.category.name if target.category else "None", inline=True)
        embed.add_field(name="Position", value=str(target.position), inline=True)
        embed.add_field(name="Topic", value=target.topic or "No topic", inline=False)
        embed.add_field(name="NSFW", value="✅ Yes" if target.is_nsfw() else "❌ No", inline=True)
        embed.add_field(name="Slowmode", value=f"{target.slowmode_delay}s" if target.slowmode_delay else "Disabled", inline=True)
        
        if target.overwrites:
            overwrite_text = []
            for target_obj, overwrite in target.overwrites.items():
                if isinstance(target_obj, discord.Role):
                    name = f"@{target_obj.name}"
                else:
                    name = target_obj.display_name
                
                if not overwrite.is_empty():
                    perms = self.get_channel_permissions_snapshot(overwrite)
                    dangerous = self.get_dangerous_overwrites(perms)
                    if dangerous:
                        overwrite_text.append(f"• {name}: {', '.join(dangerous[:2])}")
            
            if overwrite_text:
                embed.add_field(name="Permission Overwrites", value="\n".join(overwrite_text[:10]), inline=False)
        
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    """Setup function for the cog"""
    cog = ChannelLogsCog(bot)
    await bot.add_cog(cog)
