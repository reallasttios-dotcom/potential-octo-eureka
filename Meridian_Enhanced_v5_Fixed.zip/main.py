import discord
from discord.ext import commands
import os
import aiosqlite
import config  # This perfectly pulls from your new root config.py

# Get the main leveling/admin prefix, defaulting to 'lv'
MAIN_PREFIX = os.getenv('DISCORD_PREFIX', 'lv')

class MeridianBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        
        # Combined prefixes: main prefix + 'v' (verify) + 't' (tickets)
        super().__init__(
            command_prefix=commands.when_mentioned_or(MAIN_PREFIX, "v", "t"), 
            intents=intents, 
            help_command=None
        )
        self.db = None # Will hold our persistent DB connection

    async def setup_hook(self):
        # Open a persistent async database connection
        self.db = await aiosqlite.connect('mainDB.sqlite')
        self.db.row_factory = aiosqlite.Row
        await self.init_db()

        # Load all cogs safely from the cogs folder
        for filename in os.listdir("./cogs"):
            if filename.endswith(".py"):
                cog_name = filename[:-3]
                try:
                    await self.load_extension(f"cogs.{cog_name}")
                    print(f"Loaded cogs.{cog_name}")
                except Exception as e:
                    print(f"Failed cogs.{cog_name}: {e}")
        
        # Sync slash commands globally
        try:
            await self.tree.sync()
            print("✅ Slash commands synced.")
        except Exception as e:
            print(f"Failed to sync slash commands: {e}")

    async def init_db(self):
        # We run all table creations concurrently
        queries = [
            "CREATE TABLE IF NOT EXISTS levels (id TEXT PRIMARY KEY, user TEXT, guild TEXT, xp INTEGER, level INTEGER, totalXP INTEGER, streakDays INTEGER DEFAULT 0, lastMessageDate TEXT, globalMultiplier REAL DEFAULT 1.0)",
            "CREATE TABLE IF NOT EXISTS prefix (serverprefix TEXT, guild TEXT PRIMARY KEY)",
            "CREATE TABLE IF NOT EXISTS settings (guild TEXT PRIMARY KEY, levelUpMessage TEXT, customXP INTEGER, customCooldown INTEGER, globalMultiplier REAL DEFAULT 1.0)",
            "CREATE TABLE IF NOT EXISTS channel (guild TEXT PRIMARY KEY, channel TEXT)",
            "CREATE TABLE IF NOT EXISTS xp_toggle (guild TEXT PRIMARY KEY, enabled INTEGER DEFAULT 1)",
            "CREATE TABLE IF NOT EXISTS blacklistTable (guild TEXT, typeId TEXT, type TEXT, id TEXT PRIMARY KEY)"
        ]
        for query in queries:
            await self.db.execute(query)
        await self.db.commit()

    async def close(self):
        # Safely close DB on shutdown
        if self.db:
            await self.db.close()
        await super().close()

bot = MeridianBot()

@bot.event
async def on_ready():
    # Uses config.GUILD_ID from your root config.py
    guild_id = getattr(config, 'GUILD_ID', 'Unknown')
    print(f"🔱 Meridian Core Online | Logged in as {bot.user} (Guild: {guild_id})")

if __name__ == "__main__":
    # Checks config for the token
    token = getattr(config, 'DISCORD_TOKEN', None)
    
    if not token:
        raise RuntimeError("Missing DISCORD_TOKEN in config.py or .env")
    
    bot.run(token)
